#!/bin/bash
cd "$(dirname "$0")"
python3 claudcade.py
