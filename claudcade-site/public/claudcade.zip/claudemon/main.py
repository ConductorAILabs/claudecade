"""Claudémon — main game loop."""
import curses, time, random, json, os, sys

from .data     import CLAUDEMON, WORLD_MAPS, PLAYER_START, ITEMS
from .entities import ClaudemonInstance, Trainer
from .battle   import Battle, WIN, LOSE, ESCAPED, CAUGHT, ANIMATING, LEVEL_UP
from .world    import Overworld

FPS       = 30
SAVE_PATH = os.path.expanduser('~/claudemon_save.json')

# ── States ─────────────────────────────────────────────────────────────────────
TITLE, STARTER_SELECT, HOW_TO_PLAY, OVERWORLD, IN_BATTLE, PARTY_MENU, SHOP, DIALOGUE, PAUSE, GAME_OVER = range(10)

TITLE_ART = [
    r"  ___  _      _   _   _  ___  ___  __  __  ___  _  _ ",
    r" / __|| |    /_\ | | | ||   \| __||  \/  ||   \| \| |",
    r"| (__ | |__ / _ \| |_| || |) | _| | |\/| || |) | .  |",
    r" \___||____/_/ \_\\___/ |___/|___||_|  |_||___/|_|\_|",
]

STARTERS = ['Promptling', 'Dataling', 'Logixlet']

STARTER_DESC = {
    'Promptling': ('Neural', 'A clever Neural-type.\nFast and magic-oriented.\nLearns Prompt early.'),
    'Dataling':   ('Data',   'A sturdy Data-type.\nHigh Attack & Defense.\nLearns Compile early.'),
    'Logixlet':   ('Logic',  'A balanced Logic-type.\nGreat Sp.Def & Speed.\nLearns Analyze early.'),
}

def _p(scr, H, W, r, c, s, a=0):
    try:
        if 0 <= r < H-1 and 0 <= c < W:
            scr.addstr(r, c, s[:max(0, W-c)], a)
    except curses.error:
        pass


def draw_title(scr, H, W, tick):
    P = curses.color_pair
    scr.erase()
    _p(scr, H, W, 0, 0, '╔'+'═'*(W-2)+'╗', P(5)|curses.A_BOLD)
    _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        _p(scr, H, W, r, 0, '║', P(5))
        _p(scr, H, W, r, W-1, '║', P(5))

    attrs = [P(4)|curses.A_BOLD, P(1)|curses.A_BOLD, P(6)|curses.A_BOLD, P(4)|curses.A_BOLD]
    for i, (line, attr) in enumerate(zip(TITLE_ART, attrs)):
        _p(scr, H, W, 2+i, max(1,(W-len(line))//2), line, attr)

    _p(scr, H, W, 6, 1, '░'*(W-2), P(5)|curses.A_DIM)

    sub = '◈  G A T C H  T H E M  A L L  ◈'
    _p(scr, H, W, 7, max(1,(W-len(sub))//2), sub, P(6)|curses.A_BOLD)

    # Preview art from all starters cycling
    arts = [CLAUDEMON[s]['art'] for s in STARTERS]
    art  = arts[(tick // 45) % len(arts)]
    ay   = H // 2
    for i, line in enumerate(art):
        _p(scr, H, W, ay+i, (W-len(line))//2, line, P(1)|curses.A_BOLD)

    if (tick // 18) % 2 == 0:
        msg = '[ SPACE ]  NEW GAME     [ L ]  LOAD'
        _p(scr, H, W, H-4, (W-len(msg))//2, msg, P(4)|curses.A_BOLD)
    _p(scr, H, W, H-2, 2, '3 starter Claudémon to choose from · Catch them all!', P(5)|curses.A_DIM)
    _p(scr, H, W, H-3, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)
    scr.refresh()


def draw_starter_select(scr, H, W, cursor, tick):
    P = curses.color_pair
    scr.erase()
    _p(scr, H, W, 0, 0, '╔'+'═'*(W-2)+'╗', P(5)|curses.A_BOLD)
    _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        _p(scr, H, W, r, 0, '║', P(5))
        _p(scr, H, W, r, W-1, '║', P(5))
    _p(scr, H, W, 1, 1, '▓▒░'+'░'*(W-8)+'░▒▓', P(5)|curses.A_DIM)
    _p(scr, H, W, 1, 5, '  Prof. Claude:  Choose your first Claudémon!  ', P(4)|curses.A_BOLD)
    _p(scr, H, W, 2, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)

    card_w = (W - 4) // 3
    for i, name in enumerate(STARTERS):
        sel  = (i == cursor)
        cx   = 2 + i * (card_w + 1)
        col  = P(6)|curses.A_BOLD if sel else P(5)|curses.A_DIM
        tl, tr, bl, br, hz, vt = ('╔','╗','╚','╝','═','║') if sel else ('┌','┐','└','┘','─','│')
        _p(scr, H, W, 3, cx, tl+hz*(card_w-2)+tr, col)
        for r in range(1, 12):
            _p(scr, H, W, 3+r, cx, vt+' '*(card_w-2)+vt, col)
        _p(scr, H, W, 15, cx, bl+hz*(card_w-2)+br, col)

        type_name, _ = STARTER_DESC[name][:2], STARTER_DESC[name][2]
        art = CLAUDEMON[name]['art']
        for ai, aline in enumerate(art):
            _p(scr, H, W, 5+ai, cx+max(1,(card_w-len(aline))//2), aline,
               P(1)|curses.A_BOLD if sel else P(5))

        n_attr = P(6)|curses.A_BOLD if sel else P(5)|curses.A_BOLD
        _p(scr, H, W, 10, cx+max(1,(card_w-len(name))//2), name, n_attr)
        type_str = f'[{STARTER_DESC[name][0]}]'
        _p(scr, H, W, 11, cx+max(1,(card_w-len(type_str))//2), type_str, P(4)|curses.A_BOLD if sel else P(5)|curses.A_DIM)

    # Description of selected
    sel_name = STARTERS[cursor]
    _, _, desc = STARTER_DESC[sel_name]
    for i, line in enumerate(desc.split('\n')):
        _p(scr, H, W, 17+i, 4, line, P(5))

    _p(scr, H, W, H-3, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)
    if (tick // 18) % 2 == 0:
        _p(scr, H, W, H-2, (W-25)//2, '[ ←→ ]  Select   [ ENTER ]  Choose', P(4)|curses.A_BOLD)
    scr.refresh()


def draw_how_to_play(scr, H, W, tick):
    P = curses.color_pair
    scr.erase()
    _p(scr, H, W, 0, 0, '╔'+'═'*(W-2)+'╗', P(5)|curses.A_BOLD)
    _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        _p(scr, H, W, r, 0, '║', P(5))
        _p(scr, H, W, r, W-1, '║', P(5))
    _p(scr, H, W, 1, 1, '▓▒░'+'░'*(W-8)+'░▒▓', P(5)|curses.A_DIM)
    _p(scr, H, W, 1, (W-26)//2, '  H O W   T O   P L A Y  ', P(4)|curses.A_BOLD)
    _p(scr, H, W, 2, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)

    lines = [
        ('GOAL', None),
        ('', None),
        ("  Explore the world and catch all 20 Claudémon.", P(5)),
        ("  Battle wild Claudémon to weaken them,", P(5)),
        ("  then throw a Claudéball to catch them.", P(5)),
        ('', None),
        ('CONTROLS', None),
        ('', None),
        ('  WASD / Arrows   Move on the overworld', P(6)|curses.A_BOLD),
        ('  SPACE           Confirm / Advance text', P(6)|curses.A_BOLD),
        ('  M               Open party menu',        P(6)|curses.A_BOLD),
        ('  ESC             Pause',                  P(5)|curses.A_DIM),
        ('', None),
        ('IN BATTLE', None),
        ('', None),
        ('  FIGHT   — Use a move to attack', P(5)),
        ('  CATCH   — Throw a ball (wild only)', P(5)),
        ('  ITEM    — Use a potion or revive', P(5)),
        ('  RUN     — Flee the battle', P(5)),
        ('', None),
        ('  Lower the enemy HP first — easier to catch!', P(4)|curses.A_BOLD),
    ]
    for i, (text, attr) in enumerate(lines):
        y = 4 + i
        if y >= H - 4: break
        if attr is None:
            _p(scr, H, W, y, 4, text, P(4)|curses.A_BOLD)
        else:
            _p(scr, H, W, y, 2, text, attr)

    _p(scr, H, W, H-3, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)
    if (tick // 18) % 2 == 0:
        _p(scr, H, W, H-2, (W-18)//2, '[ SPACE ]  Begin!', P(2)|curses.A_BOLD)
    scr.refresh()


def draw_pause(scr, H, W):
    P = curses.color_pair
    bw = 44; bh = 10
    by = (H-bh)//2; bx = (W-bw)//2
    try:
        for r in range(bh+1):
            scr.addstr(by+r+1, bx+2, '▒'*bw, P(5)|curses.A_DIM)
        scr.addstr(by, bx, '╔'+'═'*(bw-2)+'╗', P(7)|curses.A_BOLD)
        for r in range(1, bh-1):
            scr.addstr(by+r, bx, '║'+' '*(bw-2)+'║', P(7))
        scr.addstr(by+bh-1, bx, '╚'+'═'*(bw-2)+'╝', P(7)|curses.A_BOLD)
        scr.addstr(by+1, bx+1, '▓▒░'+'░'*(bw-6)+'░▒▓', P(7)|curses.A_DIM)
        scr.addstr(by+2, bx+(bw-22)//2, '  ⏸  CLAUDÉMON  PAUSED  ', P(7)|curses.A_BOLD)
        scr.addstr(by+3, bx+1, '─'*(bw-2), P(7))
        scr.addstr(by+5, bx+5, '[ R ]  Resume', P(3)|curses.A_BOLD)
        scr.addstr(by+6, bx+5, '[ S ]  Save game', P(4)|curses.A_BOLD)
        scr.addstr(by+7, bx+5, '[ Q ]  Quit to Claudcade', P(2)|curses.A_BOLD)
    except curses.error:
        pass
    scr.refresh()


def save_game(party, items, area, px, py, pokedex):
    data = {
        'party': [c.save_dict() for c in party],
        'items': items,
        'area':  area,
        'px':    px,
        'py':    py,
        'pokedex': list(pokedex),
    }
    with open(SAVE_PATH, 'w') as f:
        json.dump(data, f, indent=2)


def load_game():
    with open(SAVE_PATH) as f:
        d = json.load(f)
    party   = [ClaudemonInstance.from_dict(c) for c in d['party']]
    items   = d['items']
    area    = d.get('area', 'startup')
    px, py  = d.get('px', 5), d.get('py', 8)
    pokedex = set(d.get('pokedex', []))
    return party, items, area, px, py, pokedex


def main(scr):
    curses.cbreak(); curses.noecho(); scr.keypad(True)
    scr.nodelay(True); curses.curs_set(0)
    curses.start_color(); curses.use_default_colors()
    curses.init_pair(1, curses.COLOR_CYAN,    -1)
    curses.init_pair(2, curses.COLOR_RED,     -1)
    curses.init_pair(3, curses.COLOR_GREEN,   -1)
    curses.init_pair(4, curses.COLOR_YELLOW,  -1)
    curses.init_pair(5, curses.COLOR_WHITE,   -1)
    curses.init_pair(6, curses.COLOR_MAGENTA, -1)
    curses.init_pair(7, curses.COLOR_BLACK, curses.COLOR_WHITE)
    curses.init_pair(8, curses.COLOR_BLUE,    -1)

    state          = TITLE
    party: list[ClaudemonInstance] = []
    items: dict    = {'Claudéball': 5, 'Potion': 3}
    pokedex: set   = set()
    world: Overworld | None = None
    battle: Battle | None   = None
    npc_data       = None
    starter_cursor = 0
    tick           = 0
    nxt            = time.perf_counter()
    has_save       = os.path.exists(SAVE_PATH)
    dialogue_lines : list[str] = []
    dialogue_idx   = 0
    after_dialogue = None

    def start_world(area, px, py):
        nonlocal world
        world = Overworld(party, items, area, px, py)

    while True:
        now = time.perf_counter()
        if now < nxt:
            time.sleep(max(0.0, nxt - now - 0.001))
            continue
        nxt += 1/FPS; tick += 1

        H, W = scr.getmaxyx()
        keys = set()
        while True:
            k = scr.getch()
            if k == -1: break
            keys.add(k)

        UP    = any(k in keys for k in (curses.KEY_UP,    ord('w'), ord('k')))
        DOWN  = any(k in keys for k in (curses.KEY_DOWN,  ord('s'), ord('j')))
        LEFT  = any(k in keys for k in (curses.KEY_LEFT,  ord('a')))
        RIGHT = any(k in keys for k in (curses.KEY_RIGHT, ord('d')))
        OK    = any(k in keys for k in (ord('\n'), 10, 13, ord(' '), ord('l')))
        ESC   = 27 in keys

        # ── TITLE ──────────────────────────────────────────────────────────────
        if state == TITLE:
            draw_title(scr, H, W, tick)
            if ord(' ') in keys:
                state = STARTER_SELECT
            elif ord('l') in keys and has_save:
                try:
                    party, items, area, px, py, pokedex = load_game()
                    start_world(area, px, py)
                    state = OVERWORLD
                except Exception:
                    pass

        # ── STARTER SELECT ────────────────────────────────────────────────────
        elif state == STARTER_SELECT:
            draw_starter_select(scr, H, W, starter_cursor, tick)
            if LEFT:  starter_cursor = (starter_cursor - 1) % 3
            if RIGHT: starter_cursor = (starter_cursor + 1) % 3
            if UP:    starter_cursor = (starter_cursor - 1) % 3
            if DOWN:  starter_cursor = (starter_cursor + 1) % 3
            if OK:
                chosen = STARTERS[starter_cursor]
                starter = ClaudemonInstance(chosen, 5)
                party   = [starter]
                pokedex.add(chosen)
                # Intro dialogue
                dialogue_lines = [
                    'Prof. Claude: Welcome, Trainer!',
                    f'You chose {chosen}!',
                    'Your journey begins in Startup Town.',
                    'Catch Claudémon, explore the world.',
                    'Good luck!',
                ]
                dialogue_idx   = 0
                after_dialogue = lambda: start_world(*PLAYER_START) or None
                state = DIALOGUE

        # ── HOW TO PLAY ───────────────────────────────────────────────────────
        elif state == HOW_TO_PLAY:
            draw_how_to_play(scr, H, W, tick)
            if OK:
                state = OVERWORLD

        # ── DIALOGUE ─────────────────────────────────────────────────────────
        elif state == DIALOGUE:
            scr.erase()
            P = curses.color_pair
            _p(scr, H, W, 0, 0, '╔'+'═'*(W-2)+'╗', P(5)|curses.A_BOLD)
            _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', P(5)|curses.A_BOLD)
            for r in range(1, H-1):
                _p(scr, H, W, r, 0, '║', P(5))
                _p(scr, H, W, r, W-1, '║', P(5))
            if dialogue_idx < len(dialogue_lines):
                _p(scr, H, W, H//2, 3, dialogue_lines[dialogue_idx], P(5)|curses.A_BOLD)
            if (tick // 18) % 2 == 0:
                _p(scr, H, W, H-3, (W-18)//2, '[ SPACE ] Continue', P(5)|curses.A_DIM)
            scr.refresh()
            if OK:
                dialogue_idx += 1
                if dialogue_idx >= len(dialogue_lines):
                    if after_dialogue:
                        after_dialogue()
                        after_dialogue = None
                    state = HOW_TO_PLAY if not world else OVERWORLD

        # ── OVERWORLD ─────────────────────────────────────────────────────────
        elif state == OVERWORLD:
            world.draw(scr, H, W, tick)
            for k in keys:
                world.handle_key(k)
            if ord('m') in keys:
                state = PARTY_MENU

            res = world.result; world.result = None
            if res:
                if res[0] == 'battle':
                    enemy = res[1]
                    pokedex.add(enemy.name)
                    battle = Battle(party, wild=enemy, items=items)
                    state  = IN_BATTLE
                elif res[0] == 'npc':
                    npc = res[1]
                    if npc.get('role') == 'professor':
                        dialogue_lines = [
                            'Prof. Claude: How is your journey?',
                            'This world is full of Claudémon.',
                            'Catch them, train them, become the best!',
                        ]
                        dialogue_idx   = 0
                        after_dialogue = None
                        state = DIALOGUE

            if ESC:
                state = PAUSE

        # ── BATTLE ────────────────────────────────────────────────────────────
        elif state == IN_BATTLE:
            battle.draw(scr, H, W, tick)
            for k in keys:
                battle.handle_key(k)

            if battle.result and battle.state not in (ANIMATING, LEVEL_UP):
                if battle.result == 'win':
                    world.msg = 'You won!'
                    world.msg_timer = 90
                    state = OVERWORLD
                elif battle.result == 'lose':
                    world.msg = 'You blacked out...'
                    world.msg_timer = 90
                    # Heal lead Claudémon to 1 HP
                    for c in party:
                        if c.alive: c.hp = max(1, c.max_hp // 4)
                    state = OVERWORLD
                elif battle.result == 'escaped':
                    state = OVERWORLD
                elif battle.result == 'caught':
                    caught = battle.caught_name
                    pokedex.add(caught)
                    new_mon = battle.wild
                    if len(party) < 6:
                        party.append(new_mon)
                    world.msg = f'{new_mon.name} was added to your party!'
                    world.msg_timer = 90
                    state = OVERWORLD

        # ── PARTY MENU ────────────────────────────────────────────────────────
        elif state == PARTY_MENU:
            scr.erase()
            P = curses.color_pair
            _p(scr, H, W, 0, 0, '╔'+'═'*(W-2)+'╗', P(5)|curses.A_BOLD)
            _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', P(5)|curses.A_BOLD)
            for r in range(1, H-1):
                _p(scr, H, W, r, 0, '║', P(5))
                _p(scr, H, W, r, W-1, '║', P(5))
            _p(scr, H, W, 1, (W-14)//2, '  PARTY MENU  ', P(6)|curses.A_BOLD)
            _p(scr, H, W, 2, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)

            # Claudédex count
            total = len(CLAUDEMON)
            _p(scr, H, W, 3, 2, f'CLAUDÉDEX: {len(pokedex)}/{total} seen', P(4)|curses.A_BOLD)
            # Items
            _p(scr, H, W, 4, 2, 'ITEMS:', P(5)|curses.A_BOLD)
            ix = 9
            for nm, cnt in items.items():
                _p(scr, H, W, 4, ix, f'{nm} ×{cnt}', P(5)|curses.A_DIM)
                ix += len(nm) + 5
            # Party members
            _p(scr, H, W, 6, 2, 'PARTY:', P(5)|curses.A_BOLD)
            for i, c in enumerate(party):
                row = 7 + i * 3
                alive_attr = P(1)|curses.A_BOLD if c.alive else P(5)|curses.A_DIM
                _p(scr, H, W, row,   3, f'{c.name} Lv.{c.level} ({c.type1})', alive_attr)
                hp_bar = '█' * int(12 * c.hp / c.max_hp) + '░' * (12 - int(12 * c.hp / c.max_hp))
                hp_cp  = P(3) if c.hp > c.max_hp//2 else (P(4) if c.hp > c.max_hp//4 else P(2))
                _p(scr, H, W, row+1, 3, f'HP {hp_bar} {c.hp}/{c.max_hp}', hp_cp)
                moves_str = '  '.join(c.moves[:4])
                _p(scr, H, W, row+2, 5, moves_str[:W-8], P(5)|curses.A_DIM)

            _p(scr, H, W, H-3, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)
            _p(scr, H, W, H-2, 2, 'Q / ESC — Close', P(5)|curses.A_DIM)
            scr.refresh()
            if ESC or ord('q') in keys or ord('m') in keys:
                state = OVERWORLD

        # ── PAUSE ─────────────────────────────────────────────────────────────
        elif state == PAUSE:
            if world: world.draw(scr, H, W, tick)
            draw_pause(scr, H, W)
            if ord('r') in keys or ord('R') in keys: state = OVERWORLD
            if ord('s') in keys or ord('S') in keys:
                if world:
                    save_game(party, items, world.area, world.px, world.py, pokedex)
                    has_save = True
            if ord('q') in keys or ord('Q') in keys: break
            if ESC: state = OVERWORLD


def run():
    try:
        curses.wrapper(main)
    except Exception:
        import traceback
        curses.endwin()
        traceback.print_exc()
        sys.exit(1)
    print('\n  [ back in Claudcade ]\n')
