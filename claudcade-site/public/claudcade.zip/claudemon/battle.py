"""Claudémon battle system."""
import curses, random
from .data   import MOVES, ITEMS, CLAUDEMON
from .entities import ClaudemonInstance, Trainer

# States
ACT_MENU, ACT_FIGHT, ACT_CATCH, ACT_ITEM, ACT_RUN, \
ANIMATING, LEVEL_UP, WIN, LOSE, ESCAPED, CAUGHT = range(11)

def _p(scr, H, W, r, c, s, a=0):
    try:
        if 0 <= r < H-1 and 0 <= c < W:
            scr.addstr(r, c, s[:max(0, W-c)], a)
    except curses.error:
        pass

def _bar(cur, mx, w=16):
    filled = max(0, int(w * cur / mx)) if mx else 0
    empty  = w - filled
    if cur / mx > 0.5: col = '█'
    elif cur / mx > 0.25: col = '▓'
    else: col = '▒'
    return col * filled + '░' * empty

class Battle:
    def __init__(self, player_party: list[ClaudemonInstance],
                 wild: ClaudemonInstance | None = None,
                 trainer: 'Trainer | None' = None,
                 items: dict | None = None):
        self.party    = player_party
        self.wild     = wild
        self.trainer  = trainer
        self.items    = items or {}
        self.is_wild  = wild is not None

        # Find first alive party member
        self.p_idx    = next((i for i, c in enumerate(self.party) if c.alive), 0)
        self.player   = self.party[self.p_idx]
        self.enemy    = wild if wild else (trainer.active if trainer else None)

        self.state    = ACT_MENU
        self.cursor   = 0
        self.log: list[str] = []
        self.log_idx  = 0
        self.pending_msgs: list[str] = []
        self.level_up_msgs: list[str] = []
        self.caught_name  = ''
        self.result   = None  # 'win','lose','escaped','caught'

    @property
    def active_enemy(self):
        return self.wild or (self.trainer.active if self.trainer else None)

    def _menu_opts(self):
        opts = ['FIGHT']
        if self.is_wild: opts.append('CATCH')
        opts.append('ITEM')
        if self.is_wild: opts.append('RUN')
        return opts

    def handle_key(self, key):
        UP    = key in (curses.KEY_UP,   ord('w'), ord('k'))
        DOWN  = key in (curses.KEY_DOWN,  ord('s'), ord('j'))
        LEFT  = key in (curses.KEY_LEFT,  ord('a'))
        RIGHT = key in (curses.KEY_RIGHT, ord('d'))
        OK    = key in (ord('\n'), ord(' '), 10, 13, ord('l'))
        BACK  = key in (27, ord('q'), curses.KEY_BACKSPACE)

        # Drain pending messages first
        if self.state == ANIMATING:
            if OK or DOWN:
                if self.pending_msgs:
                    msg = self.pending_msgs.pop(0)
                    self.log.append(msg)
                    if not self.pending_msgs:
                        self._after_animation()
            return

        if self.state == LEVEL_UP:
            if OK:
                if self.level_up_msgs:
                    self.log.append(self.level_up_msgs.pop(0))
                if not self.level_up_msgs:
                    self._check_end()
            return

        if self.state == ACT_MENU:
            opts = self._menu_opts()
            if UP:   self.cursor = (self.cursor - 1) % len(opts)
            if DOWN: self.cursor = (self.cursor + 1) % len(opts)
            if OK:
                ch = opts[self.cursor]
                if ch == 'FIGHT':
                    self.state  = ACT_FIGHT
                    self.cursor = 0
                elif ch == 'CATCH':
                    self.state  = ACT_CATCH
                    self.cursor = 0
                elif ch == 'ITEM':
                    self.state  = ACT_ITEM
                    self.cursor = 0
                elif ch == 'RUN':
                    self._try_run()

        elif self.state == ACT_FIGHT:
            moves = self.player.moves
            if UP:   self.cursor = (self.cursor - 1) % max(1, len(moves))
            if DOWN: self.cursor = (self.cursor + 1) % max(1, len(moves))
            if BACK: self.state = ACT_MENU; self.cursor = 0; return
            if OK and moves:
                mv = moves[self.cursor]
                if self.player.pp.get(mv, 0) <= 0:
                    self.log.append(f'No PP left for {mv}!')
                    return
                self._do_player_attack(mv)

        elif self.state == ACT_CATCH:
            balls = [(n, c) for n, c in self.items.items()
                     if c > 0 and ITEMS.get(n, {}).get('type') == 'ball']
            if UP:   self.cursor = (self.cursor - 1) % max(1, len(balls))
            if DOWN: self.cursor = (self.cursor + 1) % max(1, len(balls))
            if BACK: self.state = ACT_MENU; self.cursor = 0; return
            if OK and balls:
                ball_name, _ = balls[self.cursor]
                self._throw_ball(ball_name)

        elif self.state == ACT_ITEM:
            heals = [(n, c) for n, c in self.items.items()
                     if c > 0 and ITEMS.get(n, {}).get('type') in ('heal', 'revive')]
            if UP:   self.cursor = (self.cursor - 1) % max(1, len(heals))
            if DOWN: self.cursor = (self.cursor + 1) % max(1, len(heals))
            if BACK: self.state = ACT_MENU; self.cursor = 0; return
            if OK and heals:
                item_name, _ = heals[self.cursor]
                self._use_item(item_name)

    # ── Actions ────────────────────────────────────────────────────────────────

    def _do_player_attack(self, move_name: str):
        mv = MOVES[move_name]
        self.player.pp[move_name] -= 1
        enemy = self.active_enemy
        msgs = [f'{self.player.name} used {move_name}!']
        if mv.get('power', 0) > 0:
            dmg, mult = self.player.deal_damage(move_name, enemy)
            msgs.append(f'  Dealt {dmg} damage!')
            if mult >= 2.0:   msgs.append("  It's super effective!!")
            elif mult <= 0.5: msgs.append("  Not very effective...")
            elif mult == 0.0: msgs.append("  It had no effect.")
        else:
            stat_msg = self.player.apply_stat_move(move_name, enemy)
            if stat_msg: msgs.append(f'  {stat_msg}')

        # Enemy turn (if alive)
        if enemy and enemy.alive:
            e_move = random.choice([m for m in enemy.moves if enemy.pp.get(m, 0) > 0] or enemy.moves[:1])
            enemy.pp[e_move] = max(0, enemy.pp.get(e_move, 1) - 1)
            msgs.append(f'{enemy.name} used {e_move}!')
            e_mv = MOVES[e_move]
            if e_mv.get('power', 0) > 0:
                dmg, mult = enemy.deal_damage(e_move, self.player)
                msgs.append(f'  Dealt {dmg} damage to {self.player.name}!')
                if mult >= 2.0:   msgs.append("  It's super effective!!")
                elif mult <= 0.5: msgs.append("  Not very effective...")
            else:
                stat_msg = enemy.apply_stat_move(e_move, self.player)
                if stat_msg: msgs.append(f'  {stat_msg}')

        self.pending_msgs = msgs
        self.state = ANIMATING

    def _throw_ball(self, ball_name: str):
        self.items[ball_name] -= 1
        if self.items[ball_name] == 0:
            del self.items[ball_name]
        enemy = self.active_enemy
        d     = ITEMS[ball_name]
        chance = enemy.catch_chance(d['catch_mult'])
        msgs  = [f'You threw a {ball_name}!']

        if random.random() < chance:
            msgs.append(f'  Gotcha! {enemy.name} was caught!')
            self.caught_name = enemy.name
            self.pending_msgs = msgs
            self.result = 'caught'
            self.state  = ANIMATING
        else:
            msgs.append(f'  Oh no! {enemy.name} broke free!')
            # Enemy attacks back
            if enemy.alive and enemy.moves:
                e_move = random.choice(enemy.moves)
                msgs.append(f'{enemy.name} used {e_move}!')
                e_mv = MOVES[e_move]
                if e_mv.get('power', 0) > 0:
                    dmg, _ = enemy.deal_damage(e_move, self.player)
                    msgs.append(f'  Dealt {dmg} damage!')
            self.pending_msgs = msgs
            self.state = ANIMATING

    def _use_item(self, item_name: str):
        self.items[item_name] -= 1
        if self.items[item_name] == 0:
            del self.items[item_name]
        d  = ITEMS[item_name]
        msgs = [f'Used {item_name}!']
        if d['type'] == 'heal':
            amt = min(d['power'], self.player.max_hp - self.player.hp)
            self.player.heal(d['power'])
            msgs.append(f"  {self.player.name} recovered {amt} HP!")
        elif d['type'] == 'revive':
            fainted = [c for c in self.party if not c.alive]
            if fainted:
                fainted[0].hp = fainted[0].max_hp // 2
                msgs.append(f"  {fainted[0].name} was revived!")
        self.pending_msgs = msgs
        self.state = ANIMATING

    def _try_run(self):
        p_spd = self.player.eff_spd()
        e_spd = self.active_enemy.eff_spd() if self.active_enemy else 0
        odds  = (p_spd * 128 // max(1, e_spd)) + 30
        if random.randint(0, 255) < odds:
            self.pending_msgs = ['Got away safely!']
            self.result = 'escaped'
            self.state  = ANIMATING
        else:
            self.pending_msgs = ["Can't escape!", f'{self.active_enemy.name} blocks the way!']
            self.state = ANIMATING

    def _after_animation(self):
        if self.result:
            return
        # Check if enemy fainted
        enemy = self.active_enemy
        if enemy and not enemy.alive:
            msgs = [f'{enemy.name} fainted!']
            exp_msgs = self.player.gain_exp(enemy.data['base_exp'], enemy.level)
            msgs.extend(exp_msgs)
            # Trainer: send next
            if self.trainer:
                nxt = self.trainer.active
                if nxt:
                    msgs.append(f'{self.trainer.name} sent out {nxt.name}!')
                else:
                    msgs.append(f'{self.trainer.name} is out of Claudémon!')
                    self.result = 'win'
            else:
                self.result = 'win'
            self.level_up_msgs = msgs
            self.state = LEVEL_UP
            return
        # Check if player fainted
        if not self.player.alive:
            nxt = next((c for c in self.party if c.alive and c is not self.player), None)
            if nxt:
                self.player = nxt
                self.pending_msgs = [f'{self.player.name}!', 'Go!', f'Come on, {self.player.name}!']
                self.state = ANIMATING
            else:
                self.pending_msgs = ['All your Claudémon fainted...']
                self.result = 'lose'
                self.state  = ANIMATING
            return
        self.state  = ACT_MENU
        self.cursor = 0

    def _check_end(self):
        if self.result:
            return
        if not self.active_enemy or not self.active_enemy.alive:
            self.result = 'win'
        elif not any(c.alive for c in self.party):
            self.result = 'lose'
        else:
            self.state  = ACT_MENU
            self.cursor = 0

    # ── Drawing ────────────────────────────────────────────────────────────────

    def draw(self, scr, H, W, tick):
        P = curses.color_pair
        scr.erase()

        PINK = P(6)|curses.A_BOLD
        DIM  = P(5)|curses.A_DIM
        BOLD = P(5)|curses.A_BOLD

        # Outer border
        _p(scr, H, W, 0, 0, '╔'+'═'*(W-2)+'╗', BOLD)
        _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', BOLD)
        for r in range(1, H-1):
            _p(scr, H, W, r, 0, '║', P(5))
            _p(scr, H, W, r, W-1, '║', P(5))

        # Header
        _p(scr, H, W, 1, 1, '▓▒░'+'░'*(W-8)+'░▒▓', DIM)
        t = '★  C L A U D É M O N  ★'
        _p(scr, H, W, 1, (W-len(t))//2, t, PINK)
        _p(scr, H, W, 2, 0, '╠'+'═'*(W-2)+'╣', BOLD)

        enemy = self.active_enemy
        mid   = W // 2

        # ── Enemy side (right) ────────────────────────────────────────────────
        if enemy:
            ename = f'{enemy.name}  Lv.{enemy.level}'
            _p(scr, H, W, 3, mid+2, ename, BOLD)
            hp_bar = _bar(enemy.hp, enemy.max_hp, 18)
            hp_col = P(3) if enemy.hp > enemy.max_hp//2 else (P(4) if enemy.hp > enemy.max_hp//4 else P(2))
            _p(scr, H, W, 4, mid+2, 'HP', P(3)|curses.A_BOLD)
            _p(scr, H, W, 4, mid+5, hp_bar, hp_col|curses.A_BOLD)
            _p(scr, H, W, 5, mid+2, f'   {enemy.hp}/{enemy.max_hp}', DIM)
            _p(scr, H, W, 5, mid+14, f'[{enemy.type1}]', P(4)|curses.A_BOLD if enemy.type1 else DIM)
            # Enemy art
            art = enemy.art if enemy.alive else ['  * * * * *  ', '   F A I N T  ', '  * * * * *  ']
            art_row = 7
            for i, line in enumerate(art):
                art_col = mid + max(2, (mid - len(line)) // 2)
                _p(scr, H, W, art_row+i, art_col, line, P(2)|curses.A_BOLD)

        # ── Vertical divider ──────────────────────────────────────────────────
        div_y_start = 3
        for r in range(div_y_start, H-7):
            _p(scr, H, W, r, mid, '│', DIM)

        # ── Player side (left) ────────────────────────────────────────────────
        p = self.player
        pname = f'{p.name}  Lv.{p.level}'
        _p(scr, H, W, 3, 2, pname, BOLD)
        hp_bar = _bar(p.hp, p.max_hp, 18)
        hp_col = P(3) if p.hp > p.max_hp//2 else (P(4) if p.hp > p.max_hp//4 else P(2))
        _p(scr, H, W, 4, 2, 'HP', P(3)|curses.A_BOLD)
        _p(scr, H, W, 4, 5, hp_bar, hp_col|curses.A_BOLD)
        _p(scr, H, W, 5, 2, f'   {p.hp}/{p.max_hp}', DIM)
        exp_bar = _bar(p.exp, max(1, p._exp_to_next()), 16)
        _p(scr, H, W, 6, 2, 'EX', P(8)|curses.A_BOLD)
        _p(scr, H, W, 6, 5, exp_bar, P(8))
        # Player art (bottom-left)
        art = p.art if p.alive else ['  * * * * *  ', '   F A I N T  ', '  * * * * *  ']
        art_start = 8
        for i, line in enumerate(art):
            _p(scr, H, W, art_start+i, 4, line, P(1)|curses.A_BOLD)

        # ── Message / battle log ──────────────────────────────────────────────
        log_y = H - 7
        _p(scr, H, W, log_y, 0, '╠'+'═'*(W-2)+'╣', BOLD)

        # Show last 2 log lines
        visible = self.log[-2:] if len(self.log) >= 2 else self.log
        for i, line in enumerate(visible):
            _p(scr, H, W, log_y+1+i, 2, line[:W-4], P(5))

        # Pending messages hint
        if self.state == ANIMATING and self.pending_msgs:
            _p(scr, H, W, log_y+1, 2, self.pending_msgs[0][:W-4], BOLD)
            if len(self.pending_msgs) > 1:
                if (tick // 10) % 2 == 0:
                    _p(scr, H, W, log_y+2, W-6, '▼', DIM)

        if self.state == LEVEL_UP and self.level_up_msgs:
            _p(scr, H, W, log_y+1, 2, self.level_up_msgs[0][:W-4], P(4)|curses.A_BOLD)

        # ── Action menu ───────────────────────────────────────────────────────
        menu_y = H - 4
        _p(scr, H, W, menu_y, 0, '╠'+'═'*(W-2)+'╣', BOLD)

        if self.state == ACT_MENU:
            opts = self._menu_opts()
            for i, opt in enumerate(opts):
                attr = P(7)|curses.A_BOLD if i == self.cursor else DIM
                _p(scr, H, W, menu_y+1, 4 + i*12, f'{"▸ " if i==self.cursor else "  "}{opt}', attr)

        elif self.state == ACT_FIGHT:
            for i, mv in enumerate(p.moves):
                pp_left = p.pp.get(mv, 0)
                pp_max  = MOVES[mv]['pp']
                mv_type = MOVES[mv]['type']
                row = menu_y+1 + (i // 2)
                col = 4 + (i % 2) * (W//2 - 4)
                attr = PINK if i == self.cursor else DIM
                _p(scr, H, W, row, col,
                   f'{"▸" if i==self.cursor else " "} {mv:<14} {mv_type:<7} {pp_left}/{pp_max}', attr)

        elif self.state == ACT_CATCH:
            balls = [(n, c) for n, c in self.items.items()
                     if c > 0 and ITEMS.get(n, {}).get('type') == 'ball']
            if not balls:
                _p(scr, H, W, menu_y+1, 4, 'No balls! Buy some at a shop.', P(2)|curses.A_BOLD)
            else:
                for i, (bn, cnt) in enumerate(balls[:4]):
                    attr = PINK if i == self.cursor else DIM
                    _p(scr, H, W, menu_y+1+i//2, 4+(i%2)*20, f'{"▸" if i==self.cursor else " "} {bn} x{cnt}', attr)

        elif self.state == ACT_ITEM:
            heals = [(n, c) for n, c in self.items.items()
                     if c > 0 and ITEMS.get(n, {}).get('type') in ('heal','revive')]
            if not heals:
                _p(scr, H, W, menu_y+1, 4, 'No usable items.', P(2)|curses.A_BOLD)
            else:
                for i, (nm, cnt) in enumerate(heals[:4]):
                    attr = PINK if i == self.cursor else DIM
                    _p(scr, H, W, menu_y+1+i//2, 4+(i%2)*20, f'{"▸" if i==self.cursor else " "} {nm} x{cnt}', attr)

        scr.refresh()
