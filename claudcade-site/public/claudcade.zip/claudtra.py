#!/usr/bin/env python3
"""Claudtra — Side-Scrolling Action · ESC to quit"""
from __future__ import annotations

import curses, time, random
from typing import TypedDict
from claudcade_engine import Renderer, setup_colors
try:
    from claudcade_scores import player_label, submit_async
except ImportError:
    def player_label(): return "Anonymous"
    def submit_async(*a, **kw): pass


# ── TypedDicts ────────────────────────────────────────────────────────────────

class BulletDict(TypedDict, total=False):
    """A bullet in the world (player or enemy).

    Required fields: wx, y, vx, owner.
    Optional: dead (set when hit, before culling).
    """
    wx:    float   # world-x position (scrolling coordinate)
    y:     float   # world-y position
    vx:    float   # horizontal velocity (positive = rightward)
    owner: str     # 'player' | 'enemy'
    dead:  bool


class PlatformDict(TypedDict):
    """A platform in the scrolling world."""
    x: float   # left edge (world-x)
    y: float   # top edge (world-y)
    w: float   # width


# ── STATES ────────────────────────────────────────────────────────────────────
INTRO, PLAY, GAME_OVER, PAUSE, HOW_TO_PLAY = range(5)

CONTROLS = [
    'A / D           Move left / right',
    'SPACE           Jump',
    'J / Click       Shoot',
    'S               Crouch',
    'ESC             Pause / Resume',
    'Q               Quit to Claudcade',
]

def draw_pause(scr, H, W):
    Renderer(scr, H, W).pause_overlay('Claudtra', CONTROLS)

def draw_how_to_play(scr, H, W, tick):
    P = curses.color_pair; scr.erase()
    p = lambda r,c,s,a=0: _p(scr,H,W,r,c,s,a)
    BW = min(70, W-4)
    lm = (W - BW) // 2

    p(0, lm, '╔' + '═'*(BW-2) + '╗', P(5)|curses.A_BOLD)
    p(H-1, lm, '╚' + '═'*(BW-2) + '╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        p(r, lm, '║', P(5)|curses.A_BOLD)
        p(r, lm+BW-1, '║', P(5)|curses.A_BOLD)

    title = 'H O W   T O   P L A Y'
    hdr = '▓▒░' + title.center(BW-8) + '░▒▓'
    p(1, lm+1, hdr, P(4)|curses.A_BOLD)
    p(2, lm, '╠' + '═'*(BW-2) + '╣', P(5)|curses.A_BOLD)

    row = 4
    def ln(text='', color=5, bold=False):
        nonlocal row
        attr = P(color) | (curses.A_BOLD if bold else 0)
        p(row, lm+2, text[:BW-4], attr)
        row += 1

    ln('GOAL', 4, True)
    ln('────', 5)
    ln('Run, jump, and shoot your way through endless waves of grunts and', 5)
    ln('heavies. Survive as long as possible.', 5)
    ln()
    ln('CONTROLS', 4, True)
    ln('────────', 5)
    ln('A / D            Move left / right', 5)
    ln('SPACE            Jump', 5)
    ln('J / Click        Shoot', 5)
    ln('S                Crouch', 5)
    ln('ESC              Pause', 5)
    ln()
    ln('TIPS', 4, True)
    ln('────', 5)
    ln('• Crouch to dodge enemy fire', 5)
    ln('• Jump over fast enemies', 5)
    ln('• Heavy enemies take multiple hits', 5)

    if (tick//15)%2==0:
        msg = 'PRESS SPACE TO START'
        p(H-3, lm + (BW-len(msg))//2, msg, P(4)|curses.A_BOLD)
    scr.refresh()

# ── CONFIG ────────────────────────────────────────────────────────────────────
FPS       = 30
SW, SH    = 7, 5
WALK      = 1.3        # was 2.0 — 2 cols/tick at 30fps was ~60 cols/sec, too fast
JV0       = 6.0        # was 9.0 — floaty Mario-style arc instead of snappy rocket
GRAV      = 0.8        # was 1.5 — slower fall gives the player time to read and react
B_SPD     = 4.0        # was 7.0 — bullets were invisible at 7; now clearly visible
EB_SPD    = 1.6        # was 2.5 — enemy bullets are now clearly dodgeable
E_SPD     = 0.35       # was 0.55 — grunts approach more slowly; world is readable
SHOOT_CD  = 10
LIVES     = 3
INVULN    = 90         # was 60 — 3 full seconds of grace instead of 2
GUN_ROW   = 3.0   # world-y height of gun (used for bullet spawning)

# ── TITLE ART ─────────────────────────────────────────────────────────────────
TITLE_ART = [
    r"  ___  _      _   _   _  ___  _____ ___    _   ",
    r" / __|| |    /_\ | | | ||   \|_   _| _ \  /_\  ",
    r"| (__ | |_  / _ \| |_| || |) | | | |   / / _ \ ",
    r" \___||___|/_/ \_|\___/ |___/  |_| |_|_\/_/ \_\ ",
]

# ── SPRITES ───────────────────────────────────────────────────────────────────
def frm(*rows, w=SW, h=SH):
    out = [(r + ' '*w)[:w] for r in rows]
    while len(out) < h: out.append(' '*w)
    return out[:h]

PSP = {  # player faces right
    'run':   [frm(' _O_  ',' \\|/->','  |   ',' / \\  ','      '),
              frm(' _O_  ',' /|\\->','  |   ','/   \\ ','      ')],
    'jump':  [frm(' _O_  ',' /|\\->','  |   ','  |   ','      ')],
    'shoot': [frm(' _O_  ',' \\|/=>','  |   ',' / \\  ','      ')],
    'crouch':[frm('      ',' _O_->','(/|\\) ','      ','      ')],
    'hurt':  [frm(' >O<  ',' /|\\ ','  |   ',' / \\  ','      ')],
    'dead':  [frm('      ','      ','(x.x) ','~~~~~~','      ')],
    'idle':  [frm(' _O_  ',' \\|/  ','  |   ',' / \\  ','      '),
              frm(' _O_  ',' /|\\  ','  |   ',' / \\  ','      ')],
}
def _flip(frames):
    t = {'/':'\\','\\':'/','>':'<','<':'>','(':')',')':'('}
    return [[''.join(t.get(c,c) for c in reversed(r)) for r in fr] for fr in frames]
PSP_L = {k: _flip(v) for k,v in PSP.items()}

GRUNT = {
    'walk': [frm('  O   ','<-/|  ','   |  ','  /|  ','      '),
             frm('  O   ','<-\\|  ','   |  ','  |\\  ','      ')],
    'shoot':[frm('  O   ','<~\\|  ','   |  ','  /|  ','      ')],
    'hurt': [frm(' >O<  ',' \\|\\ ','   |  ','  / \\ ','      ')],
    'dead': [frm('      ','      ','(x.x) ','~~~~~~','      ')],
}
HEAVY = {
    'idle': [frm('  O   ','<[||] ','  ||  ','_/  \\ ','      '),
             frm('  O   ','<[|.] ','  ||  ','_/  \\ ','      ')],
    'shoot':[frm('  O   ','<[!!] ','  ||  ','_/  \\ ','      ')],
    'hurt': [frm(' >O<  ','[/|\\] ','  ||  ','_/  \\ ','      ')],
    'dead': [frm('      ','      ','(x.x) ','~~~~~~','      ')],
}

def get_frame(sp, state, af):
    frames = sp.get(state, sp.get('idle', list(sp.values())[0]))
    return frames[af % len(frames)]

# ── PLAYER ────────────────────────────────────────────────────────────────────
class Player:
    def __init__(self):
        self.wx = 5.0; self.y = 0.0; self.vy = 0.0
        self.grounded = True; self.facing = 1
        self.state = 'idle'; self.af = 0; self.at = 0
        self.lives = LIVES; self.invuln = 0
        self.shoot_cd = 0; self.dead_timer = 0

    def set(self, s):
        if self.state == s: return
        self.state = s; self.af = 0; self.at = 0

    def tick_anim(self):
        self.at += 1
        spd = 5 if self.state == 'run' else 7
        if self.at >= spd:
            self.at = 0
            sp = PSP if self.facing==1 else PSP_L
            frames = sp.get(self.state, sp['idle'])
            self.af = (self.af+1) % len(frames)

    def frame(self):
        sp = PSP if self.facing==1 else PSP_L
        return get_frame(sp, self.state, self.af)

    def get_hit(self):
        if self.invuln > 0: return False
        self.lives -= 1; self.invuln = INVULN
        if self.lives <= 0: self.set('dead'); self.dead_timer = 80
        else:               self.set('hurt')
        return True

    def update(self, keys, mshoot, world):
        if self.state == 'dead':
            self.dead_timer -= 1; self.tick_anim(); return
        if self.invuln > 0: self.invuln -= 1
        if self.state == 'hurt' and self.invuln < INVULN-12: self.set('idle')
        if self.shoot_cd > 0: self.shoot_cd -= 1

        vx = 0
        if ord('a') in keys or curses.KEY_LEFT  in keys: vx = -WALK; self.facing = -1
        if ord('d') in keys or curses.KEY_RIGHT in keys: vx =  WALK; self.facing =  1
        if self.state not in ('hurt',):
            self.wx = max(0, self.wx + vx)

        if not self.grounded:
            self.vy -= GRAV

        new_y = self.y + self.vy

        # platforms first (so fast falls don't skip through them to ground)
        if self.vy <= 0:
            for pl in world.platforms:
                if pl['x'] - 1 <= self.wx <= pl['x'] + pl['w'] + 1:
                    if self.y >= pl['y'] >= new_y:
                        new_y = pl['y']; self.vy = 0; self.grounded = True
                        if self.state == 'jump': self.set('idle')
                        break

        # ground
        if new_y <= 0:
            new_y = 0; self.vy = 0; self.grounded = True
            if self.state == 'jump': self.set('idle')

        self.y = new_y

        # platform edge: still supported?
        if self.grounded and self.y > 0:
            on_pl = any(pl['x'] - 0.5 <= self.wx <= pl['x']+pl['w']+0.5
                        and abs(pl['y']-self.y) < 0.5
                        for pl in world.platforms)
            if not on_pl: self.grounded = False

        if (ord('w') in keys or ord(' ') in keys or curses.KEY_UP in keys) and self.grounded:
            self.vy = JV0; self.grounded = False

        crouch = (ord('s') in keys or curses.KEY_DOWN in keys) and self.grounded
        shoot  = (ord('j') in keys or ord('f') in keys or mshoot) and self.shoot_cd == 0
        if shoot and self.state not in ('hurt',):
            bx = self.wx + (4 if self.facing==1 else -2)
            by = self.y + GUN_ROW
            world.bullets.append({'wx': bx, 'y': by,
                                   'vx': B_SPD * self.facing, 'owner': 'player'})
            self.shoot_cd = SHOOT_CD
            if self.grounded: self.set('shoot')

        if self.state not in ('hurt', 'shoot', 'dead'):
            if not self.grounded:        self.set('jump')
            elif crouch:                 self.set('crouch')
            elif vx != 0:                self.set('run')
            else:                        self.set('idle')
        if self.state == 'shoot' and self.shoot_cd == 0: self.set('idle')

        self.tick_anim()

# ── ENEMY ─────────────────────────────────────────────────────────────────────
class Enemy:
    def __init__(self, wx, etype='grunt'):
        self.wx = float(wx); self.y = 0.0
        self.etype = etype
        self.hp = 1 if etype == 'grunt' else 4
        self.state = 'walk' if etype == 'grunt' else 'idle'
        self.af = 0; self.at = 0
        self.shoot_cd = random.randint(60, 140) if etype == 'heavy' else random.randint(40, 100)
        self.alive = True

    def frame(self):
        sp = GRUNT if self.etype == 'grunt' else HEAVY
        return get_frame(sp, self.state, self.af)

    def tick_anim(self):
        self.at += 1
        if self.at >= 8:
            self.at = 0
            sp = GRUNT if self.etype == 'grunt' else HEAVY
            frames = sp.get(self.state, list(sp.values())[0])
            self.af = (self.af + 1) % len(frames)

    def take_hit(self):
        self.hp -= 1
        if self.hp <= 0:
            self.alive = False; self.state = 'dead'; return True
        self.state = 'hurt'; self.af = 0; self.at = 0
        return False

    def update(self, player, world):
        if not self.alive: return
        if self.state == 'dead': return
        if self.state == 'hurt':
            self.tick_anim()
            if self.at == 0 and self.af >= 1:
                self.state = 'walk' if self.etype == 'grunt' else 'idle'
            return

        dx = player.wx - self.wx
        self.shoot_cd -= 1

        if self.etype == 'grunt':
            if abs(dx) > 5:
                self.wx += E_SPD * (1 if dx > 0 else -1)
            if self.shoot_cd <= 0 and abs(dx) < 55:
                self.shoot_cd = random.randint(50, 110)
                vx = EB_SPD * (1 if dx > 0 else -1)
                world.bullets.append({'wx': self.wx, 'y': self.y + GUN_ROW,
                                       'vx': vx, 'owner': 'enemy'})
                self.state = 'shoot'
            elif self.state == 'shoot': self.state = 'walk'
        else:  # heavy
            if self.shoot_cd <= 0 and abs(dx) < 60:
                self.shoot_cd = random.randint(70, 130)  # was (28,60) — fires ~1/sec, brutal
                vx = EB_SPD * 1.4 * (1 if dx > 0 else -1)
                world.bullets.append({'wx': self.wx, 'y': self.y + GUN_ROW,
                                       'vx': vx, 'owner': 'enemy'})
                self.state = 'shoot'
            elif self.state == 'shoot': self.state = 'idle'

        self.tick_anim()

# ── WORLD ─────────────────────────────────────────────────────────────────────
class World:
    def __init__(self):
        self.cam_x = 0.0
        self.player = Player()
        self.enemies = []; self.bullets = []; self.platforms = []
        self.score = 0; self.wave = 1; self._gen_to = 0
        self._generate(0, 250)

    def _generate(self, start, end):
        x = max(start, self._gen_to, 90)  # no enemies in first 90 units
        while x < end:
            if random.random() < 0.3:
                w = random.randint(7, 16)
                y = float(random.randint(3, 8))
                self.platforms.append({'x': float(x), 'y': y, 'w': float(w)})
                x += w + random.randint(6, 16)
            else:
                x += random.randint(10, 20)
            if x > 90 and random.random() < 0.45:
                et = 'heavy' if random.random() < 0.2 else 'grunt'
                self.enemies.append(Enemy(float(x + random.randint(5, 28)), et))
        self._gen_to = end

    def _check_hits(self):
        p = self.player
        for b in self.bullets:
            if b.get('dead'): continue
            if b['owner'] == 'player':
                for e in self.enemies:
                    if not e.alive or e.state == 'dead': continue
                    if abs(b['wx'] - e.wx - 3) < 6 and abs(b['y'] - (e.y + GUN_ROW)) < 4:
                        b['dead'] = True
                        if e.take_hit():
                            self.score += 300 if e.etype == 'heavy' else 100
                        break
            else:  # enemy bullet
                if p.invuln > 0 or p.state == 'dead': continue
                if abs(b['wx'] - p.wx - 3) < 5 and abs(b['y'] - (p.y + GUN_ROW)) < 4:
                    b['dead'] = True; p.get_hit()
        # contact damage
        if p.invuln == 0 and p.state not in ('dead', 'hurt'):
            for e in self.enemies:
                if e.alive and e.etype == 'grunt':
                    if abs(e.wx - p.wx) < 5 and abs(e.y - p.y) < 3:
                        p.get_hit(); break

    def update(self, keys, mshoot):
        p = self.player
        p.update(keys, mshoot, self)
        self.cam_x = max(0.0, p.wx - 22)

        if self.cam_x + 180 > self._gen_to:
            self._generate(self._gen_to, int(self.cam_x + 260))

        for e in self.enemies: e.update(p, self)
        for b in self.bullets:  b['wx'] += b['vx']

        lo, hi = self.cam_x - 10, self.cam_x + 95
        self.bullets   = [b for b in self.bullets   if not b.get('dead') and lo < b['wx'] < hi]
        self.enemies   = [e for e in self.enemies   if e.wx > self.cam_x - 15]
        self.platforms = [pl for pl in self.platforms if pl['x'] + pl['w'] > self.cam_x - 10]
        self._check_hits()
        self.wave = 1 + int(p.wx) // 200

# ── RENDERING ─────────────────────────────────────────────────────────────────
def _p(scr, H, W, r, c, s, a=0):
    try:
        if 0 <= r < H-1 and 0 <= c < W: scr.addstr(r, c, s[:W-c], a)
    except: pass

def draw_intro(scr, H, W, tick):
    P = curses.color_pair; scr.erase()
    p = lambda r,c,s,a=0: _p(scr,H,W,r,c,s,a)
    p(0,0,'╔'+'═'*(W-2)+'╗',P(5))
    p(H-1,0,'╚'+'═'*(W-2)+'╝',P(5))
    for r in range(1,H-1): p(r,0,'║',P(5)); p(r,W-1,'║',P(5))
    sr = max(1,(H-len(TITLE_ART)-6)//2)
    for i,line in enumerate(TITLE_ART):
        p(sr+i, max(1,(W-len(line))//2), line, P(1 if i<2 else 4)|curses.A_BOLD)
    p(sr+len(TITLE_ART)+1,(W-30)//2,'─── SIDE-SCROLLING ACTION ───',P(5))
    ty = H-9
    for i,row in enumerate(PSP['idle'][(tick//14)%2]):
        p(ty+i,3,row,P(1)|curses.A_BOLD)
    for i,row in enumerate(GRUNT['walk'][(tick//14)%2]):
        p(ty+i,W-SW-3,row,P(2)|curses.A_BOLD)
    if (tick//15)%2==0:
        msg = '★  PRESS SPACE TO START  ★'
        p(H-3,(W-len(msg))//2,msg,P(4)|curses.A_BOLD)
    p(H-2,(W-46)//2,'A/D:Move   SPACE:Jump   J or CLICK:Shoot   S:Crouch',P(5))
    scr.refresh()

def draw_game(scr, world, H, W, tick):
    P = curses.color_pair; scr.erase()
    p = lambda r,c,s,a=0: _p(scr,H,W,r,c,s,a)
    pl  = world.player
    cam = world.cam_x
    AT  = 3
    GR  = H - 5   # ground row — adapts to terminal height

    def sr(world_y):           # sprite TOP row for entity at world_y
        return GR - SH - int(world_y)

    def sc(world_x):           # screen col
        return int(world_x - cam) + 1

    def brow(bullet_y):        # screen row for bullet
        return GR - int(bullet_y) - 1

    # ── borders / HUD (shaded header) ──
    p(0,0,'╔'+'═'*(W-2)+'╗',P(5)|curses.A_BOLD)
    p(2,0,'╠'+'═'*(W-2)+'╣',P(5)|curses.A_BOLD)
    p(1,0,'║',P(5)|curses.A_BOLD); p(1,W-1,'║',P(5)|curses.A_BOLD)
    p(1,1,'▓▒░',P(5)|curses.A_DIM); p(1,W-4,'░▒▓',P(5)|curses.A_DIM)
    p(1,5,'★ Claudtra ★',P(3)|curses.A_BOLD)
    hearts = ('♥ '*pl.lives + '♡ '*(LIVES-pl.lives)).strip()
    p(1,19,hearts,P(2)|curses.A_BOLD)
    sc_str = f'SCORE:{world.score:06d}'
    p(1,(W-len(sc_str))//2,sc_str,P(4)|curses.A_BOLD)
    wd = f'WAVE {world.wave}   DIST {int(pl.wx):04d}'
    p(1,W-len(wd)-4,wd,P(3))

    # ── arena borders ──
    for r in range(AT, GR): p(r,0,'║',P(5)); p(r,W-1,'║',P(5))

    # ── sky: subtle stars ──
    for sr_,sc_ in [(AT+1,8),(AT+1,24),(AT+1,40),(AT+1,56),(AT+1,70),
                    (AT+3,15),(AT+3,33),(AT+3,49),(AT+3,65),
                    (AT+5,5),(AT+5,20),(AT+5,44),(AT+5,62)]:
        if AT <= sr_ < GR-6 and 1 <= sc_ < W-1: p(sr_,sc_,'·',P(5)|curses.A_DIM)

    # ── distant mountains: one clean row ──
    mrow = GR - 6
    if AT < mrow < GR:
        moff = int(cam * 0.12) % 6
        pat = ('/\\ '* 30)[moff:moff+W-2]
        p(mrow, 1, pat, P(5)|curses.A_DIM)

    # ── ground ──
    p(GR,   0, '╠'+'═'*(W-2)+'╣', P(5))
    if GR+1 < H-1: p(GR+1, 0, '║'+'▓'*(W-2)+'║', P(5)|curses.A_DIM)

    # ── platforms ──
    for pl_ in world.platforms:
        c0 = sc(pl_['x']); pr = GR - int(pl_['y'])
        pw = int(pl_['w'])
        if -pw < c0 < W and AT < pr < GR:
            seg = '╔'+'═'*pw+'╗'
            vis = seg[max(0, 1-c0):]
            p(pr,   max(1,c0), vis[:W-max(1,c0)], P(5)|curses.A_BOLD)
            vis2 = ('║'+'░'*pw+'║')[max(0, 1-c0):]
            p(pr+1, max(1,c0), vis2[:W-max(1,c0)], P(5)|curses.A_DIM)

    # ── enemies ──
    for e in world.enemies:
        c0 = sc(e.wx)
        if -SW < c0 < W:
            fr  = e.frame()
            top = sr(e.y)
            cp  = P(2)|curses.A_BOLD
            if e.state == 'hurt': cp = P(6)|curses.A_BOLD|curses.A_REVERSE
            if e.state == 'dead': cp = P(5)
            for i, row in enumerate(fr):
                r = top+i
                if AT <= r < GR: p(r, max(1,c0), row, cp)

    # ── player ──
    blink = pl.invuln > 0 and (tick//3)%2 == 0
    if not blink:
        c0  = sc(pl.wx)
        top = sr(pl.y)
        fr  = pl.frame()
        cp  = P(1)|curses.A_BOLD
        if pl.state == 'dead': cp = P(5)
        if pl.state == 'hurt': cp = P(6)|curses.A_BOLD|curses.A_REVERSE
        for i, row in enumerate(fr):
            r = top+i
            if AT <= r < GR: p(r, max(1,c0), row, cp)

    # ── bullets ──
    for b in world.bullets:
        c0 = sc(b['wx']); br = brow(b['y'])
        if 1 <= c0 < W-2 and AT <= br < GR:
            sprite = '=>' if b['owner']=='player' else '·~'
            cp = P(4)|curses.A_BOLD if b['owner']=='player' else P(2)
            p(br, c0, sprite, cp)

    # ── overlays ──
    if pl.state == 'dead' and pl.dead_timer > 35:
        msg = '  GAME OVER  ' if pl.lives<=0 else '  GET READY  '
        mr = AT + (GR-AT)//2
        mw = len(msg)+2; mc = (W-mw)//2
        p(mr-1,mc,'╔'+'═'*(mw-2)+'╗',P(7))
        p(mr,  mc,'║'+msg+'║',         P(7)|curses.A_BOLD)
        p(mr+1,mc,'╚'+'═'*(mw-2)+'╝',P(7))

    # ── footer ──
    p(H-4,0,'╠'+'═'*(W-2)+'╣',P(5))
    p(H-3,0,'║',P(5)); p(H-3,W-1,'║',P(5))
    ctrl = 'A/D:Move   SPC:Jump   J/Click:Shoot   S:Crouch   ESC:Quit'
    p(H-3,1,ctrl.center(W-2),P(5))
    p(H-2,0,'╚'+'═'*(W-2)+'╝',P(5))
    scr.refresh()

def draw_gameover(scr, H, W, score, tick, sub_result=None):
    P = curses.color_pair; scr.erase()
    p = lambda r,c,s,a=0: _p(scr,H,W,r,c,s,a)
    p(0,0,'╔'+'═'*(W-2)+'╗',P(5)|curses.A_BOLD)
    p(H-1,0,'╚'+'═'*(W-2)+'╝',P(5)|curses.A_BOLD)
    for r in range(1,H-1): p(r,0,'║',P(5)); p(r,W-1,'║',P(5))
    mr = H//2
    p(mr-1,(W-21)//2,'  G A M E   O V E R  ',P(2)|curses.A_BOLD)
    p(mr+1,(W-22)//2,f'  FINAL SCORE: {score:06d}  ',P(4)|curses.A_BOLD)
    pl = player_label()
    p(mr+2,(W-len(pl)-4)//2, f'  {pl}  ', P(1)|curses.A_BOLD)
    if sub_result and sub_result[0]:
        rank = sub_result[0].get('rank')
        if rank:
            rm = f'Global rank: #{rank}'
            p(mr+3,(W-len(rm)-4)//2, f'  {rm}  ', P(3)|curses.A_BOLD)
    elif sub_result and sub_result[0] is None:
        p(mr+3,(W-22)//2,'  Submitting score...  ',P(5)|curses.A_DIM)
    if (tick//15)%2==0:
        msg = '[ SPACE = play again     ESC = quit ]'
        p(mr+5,(W-len(msg))//2,msg,P(5))
    scr.refresh()

# ── MAIN ──────────────────────────────────────────────────────────────────────
def main(scr):
    curses.cbreak(); curses.noecho(); scr.keypad(True)
    scr.nodelay(True); curses.curs_set(0)
    setup_colors()
    try: curses.mousemask(curses.ALL_MOUSE_EVENTS)
    except: pass

    state = INTRO; world = None; tick = 0; _sub = [None]
    nxt = time.perf_counter()

    while True:
        now = time.perf_counter()
        if now < nxt: time.sleep(max(0, nxt-now-.001)); continue
        nxt += 1/FPS; tick += 1

        H, W = scr.getmaxyx()
        keys = set(); mshoot = False
        while True:
            k = scr.getch()
            if k == -1: break
            if k == curses.KEY_MOUSE:
                try:
                    _,_,_,_,bst = curses.getmouse()
                    if bst & (curses.BUTTON1_PRESSED | curses.BUTTON1_CLICKED):
                        mshoot = True
                except: pass
            else: keys.add(k)

        if 27 in keys:
            if   state == PLAY:  state = PAUSE
            elif state == PAUSE: state = PLAY
            else: break

        if state == INTRO:
            draw_intro(scr, H, W, tick)
            if ord(' ') in keys: state = HOW_TO_PLAY; tick = 0

        elif state == HOW_TO_PLAY:
            draw_how_to_play(scr, H, W, tick)
            if ord(' ') in keys: world = World(); state = PLAY; tick = 0

        elif state == PLAY:
            world.update(keys, mshoot)
            draw_game(scr, world, H, W, tick)
            p = world.player
            if p.state == 'dead' and p.dead_timer <= 0:
                if p.lives <= 0:
                    state = GAME_OVER; tick = 0; _sub = [None]
                    submit_async('claudtra', world.score, f'Dist {int(p.wx)}', _sub)
                else:
                    p.wx += 12; p.y = 0; p.vy = 0
                    p.grounded = True; p.invuln = INVULN*2; p.state = 'idle'

        elif state == GAME_OVER:
            draw_gameover(scr, H, W, world.score, tick, _sub)
            if ord(' ') in keys: world = World(); state = PLAY; tick = 0; _sub = [None]

        elif state == PAUSE:
            draw_game(scr, world, H, W, tick)
            draw_pause(scr, H, W)
            if ord('r') in keys or ord('R') in keys: state = PLAY
            if ord('q') in keys or ord('Q') in keys: break

def _run():
    import sys
    try:
        curses.wrapper(main)
    except Exception as e:
        try: curses.endwin()
        except: pass
        print(f'\n[Claudtra crashed] {e}', file=sys.stderr)
        import traceback; traceback.print_exc(file=sys.stderr)

_run()
print('\n  [ back in Claude — type anything to chat ]\n')
