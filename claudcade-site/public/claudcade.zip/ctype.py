#!/usr/bin/env python3
"""C-TYPE: Space Shooter · ESC to quit"""
from __future__ import annotations

import curses, time, random, math
from claudcade_engine import Renderer, setup_colors, make_stars, StarDict
try:
    from claudcade_scores import player_label, submit_async
except ImportError:
    def player_label(): return "Anonymous"
    def submit_async(*a, **kw): pass

# ── STATES ────────────────────────────────────────────────────────────────────
INTRO, PLAY, GAME_OVER, PAUSE, HOW_TO_PLAY = range(5)

CONTROLS = [
    'WASD / Arrows   Move',
    'J / Click       Shoot',
    'Hold J          Charge beam',
    'ESC             Pause / Resume',
    'Q               Quit to Claudcade',
]

def draw_pause(scr, H, W):
    Renderer(scr, H, W).pause_overlay('C-TYPE', CONTROLS)

def draw_how_to_play(scr, H, W, tick):
    P = curses.color_pair; scr.erase()
    p = lambda r,c,s,a=0: _p(scr,H,W,r,c,s,a)
    BW = min(70, W-4)
    lm = (W - BW) // 2

    p(0, lm, '╔' + '═'*(BW-2) + '╗', P(5)|curses.A_BOLD)
    p(H-1, lm, '╚' + '═'*(BW-2) + '╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        p(r, lm, '║', P(5)|curses.A_BOLD)
        p(r, lm+BW-1, '║', P(5)|curses.A_BOLD)

    title = 'H O W   T O   P L A Y'
    hdr = '▓▒░' + title.center(BW-8) + '░▒▓'
    p(1, lm+1, hdr, P(4)|curses.A_BOLD)
    p(2, lm, '╠' + '═'*(BW-2) + '╣', P(5)|curses.A_BOLD)

    row = 4
    def ln(text='', color=5, bold=False):
        nonlocal row
        attr = P(color) | (curses.A_BOLD if bold else 0)
        p(row, lm+2, text[:BW-4], attr)
        row += 1

    ln('GOAL', 4, True)
    ln('────', 5)
    ln('Shoot down every wave of enemies. Survive boss waves every 6 levels.', 5)
    ln('Earn the highest score.', 5)
    ln()
    ln('CONTROLS', 4, True)
    ln('────────', 5)
    ln('WASD / Arrows    Move', 5)
    ln('J / Click        Shoot', 5)
    ln('Hold J           Charge beam (release to fire)', 5)
    ln('ESC              Pause', 5)
    ln()
    ln('TIPS', 4, True)
    ln('────', 5)
    ln('• Hold J to charge a powerful beam', 5)
    ln('• Power-ups restore a shot type', 5)
    ln('• Boss appears every 6 waves', 5)

    if (tick//15)%2==0:
        msg = 'PRESS SPACE TO START'
        p(H-3, lm + (BW-len(msg))//2, msg, P(4)|curses.A_BOLD)
    scr.refresh()

# ── CONFIG ────────────────────────────────────────────────────────────────────
FPS        = 30
AT         = 3          # arena top row
P_SPD      = 2.0        # player speed (rows/cols per tick)
PB_SPD     = 5.0        # player bullet speed  (was 9.0 — slowed to be visible)
EB_SPD     = 1.4        # enemy bullet speed   (was 2.8 — halved so players can dodge)
SHOOT_CD   = 7
CHARGE_MAX = 50
LIVES      = 3
INVULN     = 90         # invincibility frames after hit (was 55 — more breathing room)
PSW, PSH   = 7, 3       # player sprite dims

# ── TITLE ─────────────────────────────────────────────────────────────────────
TITLE_ART = [
    r"   ___       _____   __  __ ____  _____",
    r"  / __|___  |_   _| |  \/  |  _ \| ____|",
    r" | |____|__|   | |   | |\/| | |_) |  _|  ",
    r"  \___|____|   |_|   |_|  |_|____/|_____|",
]

# ── SPRITES ───────────────────────────────────────────────────────────────────
PSHIPS = [
    [' /~\\ ', '>===)>', ' \\_/ '],   # power 0
    [' /=\\ ', '>==>*>', ' \\=/ '],   # power 1
    ['\\>-=> ', '=>===>', '/>==> '],   # power 2
]

def get_ship(power, charged):
    sp = PSHIPS[min(power, len(PSHIPS)-1)]
    if charged:
        return ['*'+s[1:] for s in sp]
    return sp

ESP = {
    'grunt':  ['<==>'],
    'sine':   ['<~~>'],
    'diver':  [' /V\\ ', '< o >'],
    'heavy':  ['[####]', '<=##=>'],
    'turret': [' /T\\ ', '[===]'],
}

BOSS_FRAMES = [
    [
        '  /=======\\  ',
        ' /  [###]  \\ ',
        '<===[ * ]===<',
        ' \\  [###]  / ',
        '  \\=======/  ',
    ],
    [
        '  /=======\\  ',
        ' /  [!!!]  \\ ',
        '<===[***]===<',
        ' \\  [!!!]  / ',
        '  \\=======/  ',
    ],
]

# ── EXPLOSION ─────────────────────────────────────────────────────────────────
class Explosion:
    FRAMES = [['***','*#*','***'], ['·+·','+o+','·+·'], ['   ',' · ','   ']]
    def __init__(self, x, y):
        self.x=x; self.y=y; self.f=0; self.t=0
    @property
    def done(self): return self.f >= len(self.FRAMES)
    def tick(self):
        self.t += 1
        if self.t >= 4: self.t=0; self.f+=1

# ── POWERUP ───────────────────────────────────────────────────────────────────
class Powerup:
    TYPES = [('P','power',4),('S','speed',3),('♥','life',2)]
    def __init__(self, x, y):
        w = random.choices(self.TYPES, weights=[4,3,2])[0]
        self.x=float(x); self.y=float(y); self.char=w[0]; self.kind=w[1]
    def update(self): self.x -= 0.8
    @property
    def gone(self): return self.x < 0

# ── PLAYER ────────────────────────────────────────────────────────────────────
class Player:
    def __init__(self, H, W):
        self.GR = H-5
        self.W  = W
        self.x  = float(8)
        self.y  = float(self.GR - AT) // 2 + AT
        self.lives   = LIVES
        self.power   = 0
        self.speed   = P_SPD
        self.invuln  = 0
        self.shoot_cd= 0
        self.charge  = 0
        self.beam    = None   # active beam: {'len', 'y', 'ttl'}
        self.shield  = 0

    def sprites(self): return get_ship(self.power, self.charge >= CHARGE_MAX)

    def get_hit(self):
        if self.invuln > 0 or self.shield > 0:
            if self.shield > 0: self.shield -= 1
            return False
        self.lives = max(0, self.lives - 1); self.invuln = INVULN
        self.power = max(0, min(2, self.power - 1))
        return True

    def update(self, keys, game):
        if self.invuln > 0: self.invuln -= 1
        if self.shoot_cd > 0: self.shoot_cd -= 1

        spd = self.speed
        if ord('w') in keys or curses.KEY_UP    in keys: self.y -= spd
        if ord('s') in keys or curses.KEY_DOWN  in keys: self.y += spd
        if ord('a') in keys or curses.KEY_LEFT  in keys: self.x -= spd
        if ord('d') in keys or curses.KEY_RIGHT in keys: self.x += spd

        GR = self.GR
        self.x = max(2.0,   min(self.W // 3, self.x))
        self.y = max(float(AT+1), min(float(GR - PSH - 1), self.y))

        fire_key = ord('j') in keys or ord('f') in keys
        if fire_key:
            self.charge = min(self.charge+1, CHARGE_MAX)
            # Rapid-fire while holding; stops when charge fills (switches to beam mode)
            if self.charge < CHARGE_MAX and self.shoot_cd == 0:
                game.pbullets.append({'x': self.x+PSW, 'y': self.y+1, 'vx': PB_SPD, 'vy': 0})
                if self.power >= 1:
                    game.pbullets.append({'x': self.x+PSW, 'y': self.y,   'vx': PB_SPD, 'vy':-0.3})
                    game.pbullets.append({'x': self.x+PSW, 'y': self.y+2, 'vx': PB_SPD, 'vy': 0.3})
                self.shoot_cd = SHOOT_CD
        else:
            if self.charge >= 15:
                # Threshold of 15 — easy to trigger, avoids hair-trigger taps
                self.beam = {'x': self.x+PSW, 'y': int(self.y), 'ttl': 18,
                             'rows': 3, 'power': self.charge}
                beam_len = max(1, self.W - int(self.x) - PSW)
                game.pbullets.append({'x': self.x+PSW, 'y': self.y+1,
                                       'vx': PB_SPD*2, 'vy': 0, 'beam': True,
                                       'len': beam_len})
            self.charge = 0

# ── ENEMY ─────────────────────────────────────────────────────────────────────
class Enemy:
    def __init__(self, x, y, etype, speed=1.0):
        self.x  = float(x); self.y_start = float(y); self.y = float(y)
        self.etype = etype
        self.hp = {'grunt':1,'sine':1,'diver':2,'heavy':4,'turret':3}[etype]
        self.age = 0
        self.speed = speed
        self.shoot_cd = random.randint(40, 120)
        self.alive = True
        rows = ESP[etype]; self.h = len(rows); self.w = len(rows[0])

    def sprites(self): return ESP[self.etype]

    def take_hit(self, dmg=1):
        self.hp -= dmg
        if self.hp <= 0: self.alive = False; return True
        return False

    def update(self, player, game):
        if not self.alive: return
        self.age += 1
        spd = self.speed

        if self.etype == 'grunt':
            self.x -= spd
        elif self.etype == 'sine':
            self.x -= spd * 0.75
            self.y = self.y_start + math.sin(self.age * 0.12) * 6
        elif self.etype == 'diver':
            self.x -= spd * 0.6
            dy = player.y - self.y
            self.y += max(-0.8, min(0.8, dy * 0.04))
        elif self.etype == 'heavy':
            self.x -= spd * 0.5
        elif self.etype == 'turret':
            self.x -= spd * 0.3

        self.shoot_cd -= 1
        if self.shoot_cd <= 0 and abs(self.x - player.x) < 65:
            self.shoot_cd = random.randint(50, 130)
            dx = player.x - self.x; dy = player.y - self.y
            dist = max(1, math.hypot(dx, dy))
            vx = EB_SPD * dx / dist; vy = EB_SPD * dy / dist
            game.ebullets.append({'x': self.x-1, 'y': self.y+self.h//2,
                                   'vx': vx, 'vy': vy})

# ── BOSS ──────────────────────────────────────────────────────────────────────
class Boss:
    def __init__(self, H, W):
        self.x   = float(W - 14)
        self.y   = float(H//2 - 2)
        self.hp  = 40; self.max_hp = 40
        self.alive = True; self.age = 0
        self.phase = 0; self.frame = 0; self.ft = 0
        self.shoot_cd = 20; self.H=H; self.W=W; self.h=5; self.w=13

    def sprites(self):
        return BOSS_FRAMES[self.frame % len(BOSS_FRAMES)]

    def take_hit(self, dmg=1):
        self.hp -= dmg
        if self.hp <= 0: self.alive=False; return True
        if self.hp < self.max_hp//2: self.phase=1
        return False

    def update(self, player, game):
        if not self.alive: return
        self.age += 1
        self.ft += 1
        if self.ft >= 12: self.ft=0; self.frame+=1

        self.y = (self.H//2 - 2) + math.sin(self.age * 0.03) * (self.H//6)
        self.y = max(float(AT+1), min(float(self.H-5-self.h), self.y))
        if self.phase == 1:  # phase 2: advance toward center to pressure the player
            self.x = max(float(self.W//2), self.x - 0.3)

        self.shoot_cd -= 1
        if self.shoot_cd <= 0:
            shots = 3 if self.phase==0 else 5
            self.shoot_cd = 28 if self.phase==0 else 18  # was 15/8 — much more survivable
            cx = self.x; cy = self.y + self.h//2
            for i in range(shots):
                angle = math.pi + (i - shots//2) * 0.25
                vx = EB_SPD * 1.2 * math.cos(angle)
                vy = EB_SPD * 1.2 * math.sin(angle)
                game.ebullets.append({'x':cx,'y':cy,'vx':vx,'vy':vy})

# ── GAME ──────────────────────────────────────────────────────────────────────
class Game:
    def __init__(self, H, W):
        self.H=H; self.W=W; self.GR=H-5
        self.player    = Player(H, W)
        self.enemies   = []
        self.pbullets  = []
        self.ebullets  = []
        self.explosions= []
        self.powerups  = []
        self.stars     = make_stars(H, W)
        self.score     = 0
        self.wave      = 0
        self.wave_cd   = 80   # ticks until first wave
        self.pending   = []   # enemies waiting to spawn: (delay, etype, x, y)
        self.boss      = None
        self.boss_mode = False
        self.msg       = ''; self.msg_t = 0

    def show(self, m, d=90): self.msg=m; self.msg_t=d

    def _spawn_wave(self):
        self.wave += 1
        self.show(f'  WAVE {self.wave}  ', 50)
        W=self.W; H=self.H; GR=self.GR
        cx = W - 2
        arena_h = GR - AT - 2
        center  = AT + 1 + arena_h // 2

        if self.wave % 6 == 0:
            # Boss wave
            self.boss = Boss(H, W)
            self.boss_mode = True
            self.show('  ★ BOSS INCOMING ★  ', 70)
            return

        pattern = (self.wave-1) % 5
        count   = 3 + self.wave // 2
        spd_mul = 1.0 + self.wave * 0.04   # was 0.08 — gentler scaling so wave 5 = 1.2x

        if pattern == 0:   # vertical spread, straight fliers
            ys = [AT+1 + arena_h*i//(count+1) for i in range(1, count+1)]
            for i,y in enumerate(ys):
                self.pending.append((i*20, 'grunt', cx, float(y), spd_mul))
        elif pattern == 1:  # sine wave
            for i in range(count):
                y = center + (i-count//2)*3
                self.pending.append((i*15, 'sine', cx, float(y), spd_mul))
        elif pattern == 2:  # divers
            for i in range(min(count, 5)):
                y = AT+2 + arena_h*i//(max(count,1)+1)
                self.pending.append((i*12, 'diver', cx, float(y), spd_mul))
        elif pattern == 3:  # mixed grunt + 1 heavy
            for i in range(count-1):
                y = float(random.randint(AT+2, GR-3))
                self.pending.append((i*18, 'grunt', cx, y, spd_mul))
            self.pending.append((count*18, 'heavy', cx, float(center), spd_mul*0.8))
        elif pattern == 4:  # turrets + grunts
            for i in range(2):
                y = AT+2 + arena_h*(i+1)//3
                self.pending.append((i*25, 'turret', cx, float(y), spd_mul*0.5))
            for i in range(count-2):
                y = float(random.randint(AT+2, GR-3))
                self.pending.append((i*12+10, 'grunt', cx, y, spd_mul))

    def _check_hits(self):
        p = self.player
        W = self.W
        for b in list(self.pbullets):
            if b.get('dead'): continue
            beam = b.get('beam', False)
            dmg  = max(1, int(b.get('len', 1) // 15)) if beam else 1

            targets = ([self.boss] if self.boss and self.boss.alive else []) + self.enemies
            for e in targets:
                ex = e.x; ey = e.y; ew = e.w; eh = e.h
                if beam:
                    hit = (ex <= W and abs(b['y'] - (ey + eh//2)) <= eh//2 + 1)
                else:
                    hit = (ex - 2 <= b['x'] <= ex + ew + 1 and
                           ey - 1 <= b['y'] <= ey + eh + 1)
                if hit:
                    if not beam: b['dead'] = True
                    killed = e.take_hit(dmg if beam else 1)
                    if killed:
                        self.explosions.append(Explosion(int(e.x), int(e.y+eh//2)))
                        sc = {'grunt':100,'sine':150,'diver':200,'heavy':400,'turret':300}
                        if hasattr(e,'max_hp'):  # boss
                            self.score += 5000; self.boss_mode=False; self.boss=None
                            self.show('  BOSS DESTROYED!  ', 90)
                        else:
                            self.score += sc.get(e.etype,100)
                            if random.random() < 0.12:
                                self.powerups.append(Powerup(e.x, e.y))
                    if not beam: break

        if p.invuln == 0:
            for b in list(self.ebullets):
                if b.get('dead'): continue
                if (abs(b['x'] - p.x - PSW//2) < 4 and
                    abs(b['y'] - p.y - PSH//2) < 3):
                    b['dead'] = True
                    if p.get_hit(): self.explosions.append(Explosion(int(p.x+2), int(p.y+1)))
            if self.boss and self.boss.alive:
                if (self.boss.x <= p.x+PSW and p.x <= self.boss.x+self.boss.w and
                    self.boss.y <= p.y+PSH and p.y <= self.boss.y+self.boss.h):
                    p.get_hit()

        for pu in list(self.powerups):
            if abs(pu.x - p.x - PSW//2) < 5 and abs(pu.y - p.y - 1) < 3:
                if pu.kind == 'power':  p.power = min(2, p.power+1)
                elif pu.kind == 'speed': p.speed = min(3.5, p.speed+0.5)
                elif pu.kind == 'life':  p.lives += 1
                self.score += 500
                pu.x = -1  # mark collected

    def update(self, keys, mshoot):
        p = self.player
        effective_keys = keys | {ord('j')} if mshoot else keys
        p.update(effective_keys, self)

        for s in self.stars:
            s['x'] -= s['spd']
            if s['x'] < 1: s['x'] = float(self.W-2)

        new_pending = []
        for item in self.pending:
            delay,et,ex,ey,spd = item
            if delay <= 0:
                self.enemies.append(Enemy(ex,ey,et,spd))
            else:
                new_pending.append((delay-1,et,ex,ey,spd))
        self.pending = new_pending

        active = [e for e in self.enemies if e.alive]
        if not self.boss_mode:
            self.wave_cd -= 1
            if self.wave_cd <= 0 and len(active)==0 and len(self.pending)==0:
                self.wave_cd = 120
                self._spawn_wave()

        for e in self.enemies: e.update(p, self)
        if self.boss: self.boss.update(p, self)
        for b in self.pbullets: b['x'] += b['vx']; b['y'] += b.get('vy',0)
        for b in self.ebullets: b['x'] += b['vx']; b['y'] += b.get('vy',0)
        for ex in self.explosions: ex.tick()
        for pu in self.powerups: pu.update()

        self._check_hits()

        if p.beam:
            p.beam['ttl'] -= 1
            if p.beam['ttl'] <= 0: p.beam = None

        self.pbullets  = [b for b in self.pbullets  if not b.get('dead') and b['x'] < self.W]
        self.ebullets  = [b for b in self.ebullets  if not b.get('dead')
                          and 0 < b['x'] < self.W and AT < b['y'] < self.GR]
        self.enemies   = [e for e in self.enemies   if e.alive and e.x > -10]
        self.explosions= [ex for ex in self.explosions if not ex.done]
        self.powerups  = [pu for pu in self.powerups  if not pu.gone]
        if self.msg_t > 0: self.msg_t -= 1

# ── RENDERER ──────────────────────────────────────────────────────────────────
def _p(scr, H, W, r, c, s, a=0):
    try:
        if 0 <= r < H-1 and 0 <= c < W: scr.addstr(r, c, s[:W-c], a)
    except: pass

def draw_intro(scr, H, W, tick):
    P = curses.color_pair; scr.erase()
    p = lambda r,c,s,a=0: _p(scr,H,W,r,c,s,a)
    p(0,0,'╔'+'═'*(W-2)+'╗',P(5)); p(H-1,0,'╚'+'═'*(W-2)+'╝',P(5))
    for r in range(1,H-1): p(r,0,'║',P(5)); p(r,W-1,'║',P(5))

    for col in range(3, W-2, 7):
        r = AT + (col * 3 + tick//3) % max(1,(H-8))
        if AT<=r<H-4: p(r,col,'·',P(5)|curses.A_DIM)

    sr = max(1,(H-len(TITLE_ART)-5)//2)
    for i,line in enumerate(TITLE_ART):
        p(sr+i, max(1,(W-len(line))//2), line, P(4 if i%2==0 else 1)|curses.A_BOLD)

    ship = PSHIPS[1]
    sy = H//2+2
    sx = (tick//2) % (W-PSW-4) + 2
    for i,row in enumerate(ship):
        p(sy+i, sx, row, P(1)|curses.A_BOLD)

    if (tick//15)%2==0:
        msg='★  PRESS SPACE TO START  ★'
        p(H-3,(W-len(msg))//2,msg,P(4)|curses.A_BOLD)
    p(H-2,(W-42)//2,'W/A/S/D: Move    J or Click: Shoot (hold=beam)',P(5))
    scr.refresh()

def draw_game(scr, game, H, W, tick):
    P = curses.color_pair; scr.erase()
    p = lambda r,c,s,a=0: _p(scr,H,W,r,c,s,a)
    pl = game.player
    GR = game.GR

    # ── borders ──
    p(0,0,'╔'+'═'*(W-2)+'╗',P(5)|curses.A_BOLD)
    p(2,0,'╠'+'═'*(W-2)+'╣',P(5)|curses.A_BOLD)
    for r in range(AT,GR): p(r,0,'║',P(5)); p(r,W-1,'║',P(5))
    p(GR,0,'╠'+'═'*(W-2)+'╣',P(5)|curses.A_BOLD)
    p(H-1,0,'╚'+'═'*(W-2)+'╝',P(5)|curses.A_BOLD)

    # ── HUD (shaded header) ──
    p(1,0,'║',P(5)|curses.A_BOLD); p(1,W-1,'║',P(5)|curses.A_BOLD)
    p(1,1,'▓▒░',P(5)|curses.A_DIM); p(1,W-4,'░▒▓',P(5)|curses.A_DIM)
    p(1,5,'★ C-TYPE ★',P(4)|curses.A_BOLD)
    hearts = ('♥ '*pl.lives).strip()
    p(1,17,hearts,P(2)|curses.A_BOLD)
    sc_s = f'SCORE:{game.score:07d}'
    p(1,(W-len(sc_s))//2,sc_s,P(4)|curses.A_BOLD)
    pwr = f'PWR:{"▮"*(pl.power+1)}{"▯"*(2-pl.power)}  WAVE:{game.wave}'
    if game.boss_mode: pwr += '  ★BOSS★'
    p(1,W-len(pwr)-4,pwr,P(3))

    # ── stars ──
    for s in game.stars:
        r=int(s['y']); c=int(s['x'])
        if AT<=r<GR and 1<=c<W-1:
            cp = P(s['cp'])
            if s['cp']==1: cp |= curses.A_BOLD
            p(r,c,s['ch'],cp|curses.A_DIM)

    # ── boss HP bar ──
    if game.boss and game.boss.alive:
        bw = W - 6
        filled = int(bw * game.boss.hp / game.boss.max_hp)
        p(AT,2,'BOSS:',P(2)|curses.A_BOLD)
        p(AT,8,'█'*filled,P(2)|curses.A_BOLD)
        p(AT,8+filled,'░'*(bw-filled),P(5))

    # ── powerups ──
    for pu in game.powerups:
        r=int(pu.y); c=int(pu.x)
        if AT<=r<GR and 1<=c<W-1:
            cp = P(4) if pu.kind=='power' else (P(3) if pu.kind=='speed' else P(2))
            blink = (tick//5)%2==0
            if blink: p(r,c,f'[{pu.char}]',cp|curses.A_BOLD)

    # ── enemies ──
    for e in game.enemies:
        if not e.alive: continue
        rows = e.sprites()
        er=int(e.y); ec=int(e.x)
        cp = P(2)|curses.A_BOLD
        if e.etype == 'heavy':  cp = P(3)|curses.A_BOLD
        if e.etype == 'turret': cp = P(4)|curses.A_BOLD
        for i,row in enumerate(rows):
            r=er+i
            if AT<=r<GR and ec<W: p(r,max(1,ec),row,cp)

    # ── boss ──
    if game.boss and game.boss.alive:
        rows=game.boss.sprites()
        br=int(game.boss.y); bc=int(game.boss.x)
        cp=P(2)|curses.A_BOLD if game.boss.phase==0 else P(6)|curses.A_BOLD
        for i,row in enumerate(rows):
            r=br+i
            if AT<=r<GR and bc<W: p(r,max(1,bc),row,cp)

    # ── player beam (behind ship) ──
    if pl.beam and pl.beam['ttl'] > 0:
        by = pl.beam['y']; bx = int(pl.beam['x'])
        intensity = pl.beam['ttl'] / 18
        bcp = P(4)|curses.A_BOLD if intensity > 0.5 else P(5)
        beam_char = '═' if intensity > 0.5 else '─'
        for dx in range(0, W - bx - 1):
            for dy in range(-1, 2):
                r = by+dy; c = bx+dx
                if AT<=r<GR and 1<=c<W-1:
                    p(r, c, beam_char if dy!=0 else '═', bcp)

    # ── player ship ──
    blink = pl.invuln>0 and (tick//3)%2==0
    if not blink:
        rows = pl.sprites()
        pr=int(pl.y); pc=int(pl.x)
        cp = P(1)|curses.A_BOLD
        if pl.charge >= CHARGE_MAX: cp = P(4)|curses.A_BOLD
        for i,row in enumerate(rows):
            r=pr+i
            if AT<=r<GR: p(r,max(1,pc),row,cp)

    # Charge bar above the ship: only visible when charging
    if pl.charge > 10 and not blink:
        bar = '▓'*int(PSW * pl.charge / CHARGE_MAX)
        p(int(pl.y)-1, int(pl.x), bar, P(4)|curses.A_BOLD)

    # ── player bullets ──
    for b in game.pbullets:
        bc=int(b['x']); br=int(b['y'])
        if AT<=br<GR and 1<=bc<W-1:
            if b.get('beam'):
                blen=b.get('len',1)
                for dx in range(0, min(blen, W-bc-1)):
                    p(br,bc+dx,'═',P(4)|curses.A_BOLD)
            else:
                p(br,bc,'=>',P(4)|curses.A_BOLD)

    # ── enemy bullets ──
    for b in game.ebullets:
        bc=int(b['x']); br=int(b['y'])
        if AT<=br<GR and 1<=bc<W-1:
            p(br,bc,'·~',P(2))

    # ── explosions ──
    for ex in game.explosions:
        fr=Explosion.FRAMES[min(ex.f,len(Explosion.FRAMES)-1)]
        for i,row in enumerate(fr):
            r=ex.y-1+i; c=ex.x-1
            if AT<=r<GR and 1<=c<W-2: p(r,c,row,P(4)|curses.A_BOLD)

    # ── message ──
    if game.msg_t > 0:
        msg=game.msg; mw=len(msg)+2; mc=(W-mw)//2; mr=AT+(GR-AT)//2
        p(mr-1,mc,'╔'+'═'*(mw-2)+'╗',P(7))
        p(mr,  mc,'║'+msg+'║',         P(7)|curses.A_BOLD)
        p(mr+1,mc,'╚'+'═'*(mw-2)+'╝',P(7))

    # ── footer ──
    for r in range(GR+1,H-1): p(r,0,'║',P(5)); p(r,W-1,'║',P(5))
    p(H-3,0,'║',P(5)); p(H-3,W-1,'║',P(5))
    ctrl='WASD:Move   J/Click:Shoot   Hold J:Charge beam   ESC:Pause   Q:Quit'
    p(H-3,1,ctrl.center(W-2),P(5))
    p(H-2,0,'╚'+'═'*(W-2)+'╝',P(5))
    scr.refresh()

def draw_gameover(scr, H, W, score, wave, tick, sub_result=None):
    P=curses.color_pair; scr.erase()
    p=lambda r,c,s,a=0: _p(scr,H,W,r,c,s,a)
    p(0,0,'╔'+'═'*(W-2)+'╗',P(5)|curses.A_BOLD)
    p(H-1,0,'╚'+'═'*(W-2)+'╝',P(5)|curses.A_BOLD)
    for r in range(1,H-1): p(r,0,'║',P(5)); p(r,W-1,'║',P(5))
    mr=H//2
    p(mr-2,(W-21)//2,'  G A M E   O V E R  ',P(2)|curses.A_BOLD)
    p(mr,  (W-24)//2,f'  SCORE: {score:07d}   WAVE {wave}  ',P(4)|curses.A_BOLD)
    pl = player_label()
    p(mr+1,(W-len(pl)-4)//2, f'  {pl}  ', P(1)|curses.A_BOLD)
    if sub_result and sub_result[0]:
        rank = sub_result[0].get('rank')
        if rank:
            rm = f'Global rank: #{rank}'
            p(mr+2,(W-len(rm)-4)//2, f'  {rm}  ', P(3)|curses.A_BOLD)
    elif sub_result and sub_result[0] is None:
        p(mr+2,(W-18)//2,'  Submitting score...  ',P(5)|curses.A_DIM)
    if (tick//15)%2==0:
        msg='[ SPACE = play again     ESC = quit ]'
        p(mr+4,(W-len(msg))//2,msg,P(5))
    scr.refresh()

# ── MAIN ──────────────────────────────────────────────────────────────────────
def main(scr):
    curses.cbreak(); curses.noecho(); scr.keypad(True)
    scr.nodelay(True); curses.curs_set(0)
    setup_colors()
    try: curses.mousemask(curses.ALL_MOUSE_EVENTS)
    except: pass

    state=INTRO; game=None; tick=0; _sub=[None]
    H,W=scr.getmaxyx()
    nxt=time.perf_counter()

    while True:
        now=time.perf_counter()
        if now<nxt: time.sleep(max(0,nxt-now-.001)); continue
        nxt+=1/FPS; tick+=1

        H,W=scr.getmaxyx()
        keys=set(); mshoot=False
        while True:
            k=scr.getch()
            if k==-1: break
            if k==curses.KEY_MOUSE:
                try:
                    _,_,_,_,bst=curses.getmouse()
                    if bst&(curses.BUTTON1_PRESSED|curses.BUTTON1_CLICKED): mshoot=True
                except: pass
            else: keys.add(k)

        if 27 in keys:
            if   state==PLAY:  state=PAUSE
            elif state==PAUSE: state=PLAY
            else: break

        if state==INTRO:
            draw_intro(scr,H,W,tick)
            if ord(' ') in keys:
                state=HOW_TO_PLAY; tick=0

        elif state==HOW_TO_PLAY:
            draw_how_to_play(scr,H,W,tick)
            if ord(' ') in keys:
                H,W=scr.getmaxyx()
                game=Game(H,W); state=PLAY; tick=0
                game.show('  WAVE 1  ',50)

        elif state==PLAY:
            game.update(keys,mshoot)
            draw_game(scr,game,H,W,tick)
            p=game.player
            if p.lives<=0 and p.invuln==0:
                state=GAME_OVER; tick=0
                _sub=[None]
                submit_async('ctype',game.score,f'Wave {game.wave}',_sub)

        elif state==GAME_OVER:
            draw_gameover(scr,H,W,game.score,game.wave,tick,_sub)
            if ord(' ') in keys:
                H,W=scr.getmaxyx()
                game=Game(H,W); state=PLAY; tick=0; _sub=[None]

        elif state==PAUSE:
            draw_game(scr,game,H,W,tick)
            draw_pause(scr,H,W)
            if ord('r') in keys or ord('R') in keys: state=PLAY
            if ord('q') in keys or ord('Q') in keys: break

def _run():
    import sys
    try:
        curses.wrapper(main)
    except Exception as e:
        try: curses.endwin()
        except: pass
        print(f'\n[C-TYPE crashed] {e}', file=sys.stderr)
        import traceback; traceback.print_exc(file=sys.stderr)

_run()
print('\n  [ back in Claude — type anything to chat ]\n')
