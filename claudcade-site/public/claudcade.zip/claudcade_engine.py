"""
Claudcade Engine
────────────────
A minimal terminal game engine built on Python's curses library.
No dependencies. Any terminal. macOS, Linux, WSL.

Usage:
    from claudcade_engine import Engine, Scene, Input, Renderer, Entity
    from claudcade_engine import CYAN, RED, GREEN, YELLOW, WHITE, MAGENTA

    class MyScene(Scene):
        def update(self, inp, tick): ...
        def draw(self, r, tick): ...

    Engine("My Game", fps=30).scene("main", MyScene()).run("main")
"""

from __future__ import annotations

import curses
import time
import random
import math
from typing import TypedDict

# ── Shared TypedDicts ──────────────────────────────────────────────────────────

class StarDict(TypedDict):
    """A single parallax star. Used by make_stars() / scroll_stars() / Renderer.stars()."""
    x:   float
    y:   float
    spd: float
    ch:  str
    cp:  int   # curses color-pair integer


class ExplosionParticleDict(TypedDict):
    """An explosion frame particle tracked inside Particles._active."""
    col: int
    row: int
    f:   int
    t:   int


class SparkParticleDict(TypedDict):
    """A spark particle tracked inside Particles._active (type == 'spark')."""
    col:   int
    row:   int
    f:     int
    t:     int
    char:  str
    color: int
    life:  int
    type:  str   # always 'spark'


# ── Color constants ────────────────────────────────────────────────────────────
CYAN      = 1   # player / info
RED       = 2   # enemies / danger
GREEN     = 3   # HP / nature / positive
YELLOW    = 4   # gold / towns / fire
WHITE     = 5   # borders / neutral
MAGENTA   = 6   # magic / special
HIGHLIGHT = 7   # black text on white bg — selected menu items
BLUE      = 8   # water / MP


# ── Input ──────────────────────────────────────────────────────────────────────
class Input:
    """
    Keyboard and mouse state for the current frame.

    Built-in aliases cover the most common game bindings so you rarely
    need to check raw key codes:

        inp.up / inp.down / inp.left / inp.right   — WASD or arrow keys
        inp.fire                                    — J, F, or mouse click
        inp.jump                                    — SPACE
        inp.confirm                                 — ENTER or SPACE
        inp.pause                                   — ESC
        inp.pressed(ord('x'))                       — any specific key
    """

    def __init__(self) -> None:
        self.keys: set[int] = set()
        self.mouse_click: bool = False

    def pressed(self, *keys: int) -> bool:
        return any(k in self.keys for k in keys)

    @property
    def up(self)      -> bool: return self.pressed(curses.KEY_UP,    ord('w'))
    @property
    def down(self)    -> bool: return self.pressed(curses.KEY_DOWN,  ord('s'))
    @property
    def left(self)    -> bool: return self.pressed(curses.KEY_LEFT,  ord('a'))
    @property
    def right(self)   -> bool: return self.pressed(curses.KEY_RIGHT, ord('d'))
    @property
    def fire(self)    -> bool: return self.pressed(ord('j'), ord('f')) or self.mouse_click
    @property
    def jump(self)    -> bool: return self.pressed(ord(' '))
    @property
    def confirm(self) -> bool: return self.pressed(ord('\n'), 10, 13, ord(' '))
    @property
    def pause(self)   -> bool: return self.pressed(27)

    @classmethod
    def _poll(cls, scr: curses.window) -> "Input":
        inp = cls()
        while True:
            k = scr.getch()
            if k == -1:
                break
            if k == curses.KEY_MOUSE:
                try:
                    _, _, _, _, bst = curses.getmouse()
                    if bst & (curses.BUTTON1_PRESSED | curses.BUTTON1_CLICKED):
                        inp.mouse_click = True
                except Exception:
                    pass
            else:
                inp.keys.add(k)
        return inp


# ── Renderer ───────────────────────────────────────────────────────────────────
class Renderer:
    """
    All drawing operations for one frame.

    Coordinates are (row, col) — row 0 is the top of the terminal.
    Every method is bounds-safe; drawing outside the terminal silently
    does nothing.

    Color arguments accept the module-level constants:
        CYAN, RED, GREEN, YELLOW, WHITE, MAGENTA, HIGHLIGHT, BLUE
    or raw integers 1-8.
    """

    def __init__(self, scr, H: int, W: int):
        self._scr = scr
        self.H = H
        self.W = W

    # ── Primitives ─────────────────────────────────────────────────────────────

    def text(self, row: int, col: int, s: str,
             color: int = WHITE, bold: bool = False,
             dim: bool = False, reverse: bool = False):
        """Draw a string at (row, col)."""
        attr = curses.color_pair(color)
        if bold:    attr |= curses.A_BOLD
        if dim:     attr |= curses.A_DIM
        if reverse: attr |= curses.A_REVERSE
        try:
            if 0 <= row < self.H - 1 and 0 <= col < self.W:
                self._scr.addstr(row, col, s[:max(0, self.W - col)], attr)
        except curses.error:
            pass

    def center(self, row: int, s: str, color: int = WHITE, bold: bool = False):
        """Draw a string centered horizontally on the given row."""
        self.text(row, max(0, (self.W - len(s)) // 2), s, color, bold)

    def box(self, row: int, col: int, h: int, w: int,
            color: int = WHITE, title: str = ""):
        """Draw a double-line border box, optionally with a centered title."""
        self.text(row,       col, '╔' + '═' * (w - 2) + '╗', color, bold=True)
        self.text(row + h-1, col, '╚' + '═' * (w - 2) + '╝', color, bold=True)
        for r in range(1, h - 1):
            self.text(row + r, col,         '║', color)
            self.text(row + r, col + w - 1, '║', color)
        if title:
            t = f' {title} '
            self.text(row, col + (w - len(t)) // 2, t, color, bold=True)

    def bar(self, row: int, col: int,
            value: float, maximum: float, width: int,
            fill_color: int = GREEN, empty_color: int = WHITE):
        """
        Draw a filled progress bar (HP, MP, charge, etc.).

            ████████████░░░░░░
        """
        ratio  = max(0.0, min(1.0, value / maximum if maximum > 0 else 0.0))
        filled = int(width * ratio)
        self.text(row, col,          '█' * filled,           fill_color, bold=True)
        self.text(row, col + filled, '░' * (width - filled), empty_color)

    def sprite(self, row: int, col: int, lines: list[str],
               color: int = WHITE, bold: bool = True):
        """Draw a multi-line ASCII sprite."""
        for i, line in enumerate(lines):
            self.text(row + i, col, line, color, bold)

    # ── High-level UI ──────────────────────────────────────────────────────────

    def header(self, game_name: str,
               left: str = "", right: str = "", color: int = YELLOW):
        """
        Draw the standard Claudcade HUD header occupying rows 0-2.

        Row 0: top border  ╔══════╗
        Row 1: shaded HUD  ║▓▒░ ★ GAME ★  [left info]       [right info] ░▒▓║
        Row 2: divider     ╠══════╣

        Always call this first in draw() if you want the standard look.
        """
        self.text(0, 0, '╔' + '═' * (self.W - 2) + '╗', WHITE, bold=True)
        self.text(1, 0, '║', WHITE, bold=True)
        self.text(1, self.W - 1, '║', WHITE, bold=True)
        self.text(1, 1, '▓▒░', WHITE, dim=True)
        self.text(1, self.W - 4, '░▒▓', WHITE, dim=True)
        self.text(1, 5, f'★ {game_name} ★', color, bold=True)
        if left:
            self.text(1, 5 + len(game_name) + 5, left, RED, bold=True)
        if right:
            self.text(1, self.W - len(right) - 4, right, GREEN)
        self.text(2, 0, '╠' + '═' * (self.W - 2) + '╣', WHITE, bold=True)

    def footer(self, controls: str):
        """
        Draw a controls hint in the bottom two rows.

        Row H-2: divider  ╠══════╣
        Row H-1: border   ╚══════╝  (drawn by outer border)
        """
        self.text(self.H - 3, 0, '╠' + '═' * (self.W - 2) + '╣', WHITE, bold=True)
        self.text(self.H - 2, 1, controls.center(self.W - 2)[:self.W - 2], WHITE)

    def outer_border(self):
        """Draw the full outer border (top + bottom + sides)."""
        self.text(0, 0, '╔' + '═' * (self.W - 2) + '╗', WHITE, bold=True)
        self.text(self.H - 1, 0, '╚' + '═' * (self.W - 2) + '╝', WHITE, bold=True)
        for r in range(1, self.H - 1):
            self.text(r, 0, '║', WHITE)
            self.text(r, self.W - 1, '║', WHITE)

    def pause_overlay(self, game_name: str, controls: list[str]):
        """
        Draw the standard pause menu as a floating overlay.
        Call after drawing the game scene so the game shows behind it.

        controls: list of strings like "WASD  Move", "J  Shoot"
        """
        bw  = max(46, max((len(c) for c in controls), default=0) + 14)
        bh  = len(controls) + 9
        by  = (self.H - bh) // 2
        bx  = (self.W - bw) // 2
        # drop shadow
        for r in range(bh + 1):
            try:
                self._scr.addstr(by + r + 1, bx + 2,
                                 '▒' * bw, curses.color_pair(WHITE) | curses.A_DIM)
            except curses.error:
                pass
        self.box(by, bx, bh, bw, color=HIGHLIGHT)
        shade = '▓▒░' + '░' * (bw - 6) + '░▒▓'
        try:
            self._scr.addstr(by + 1,      bx + 1, shade, curses.color_pair(HIGHLIGHT) | curses.A_DIM)
            self._scr.addstr(by + bh - 2, bx + 1, shade, curses.color_pair(HIGHLIGHT) | curses.A_DIM)
        except curses.error:
            pass
        title = f'  ⏸   {game_name}   PAUSED   ⏸  '
        try:
            self._scr.addstr(by + 2, bx + (bw - len(title)) // 2,
                             title, curses.color_pair(HIGHLIGHT) | curses.A_BOLD)
            self._scr.addstr(by + 3, bx + 1, '─' * (bw - 2), curses.color_pair(HIGHLIGHT))
            self._scr.addstr(by + 4, bx + 3, 'CONTROLS', curses.color_pair(HIGHLIGHT) | curses.A_BOLD)
        except curses.error:
            pass
        for i, ctrl in enumerate(controls):
            parts = ctrl.split(None, 1)
            key  = parts[0]
            rest = parts[1] if len(parts) > 1 else ''
            try:
                self._scr.addstr(by + 5 + i, bx + 5, key,
                                 curses.color_pair(HIGHLIGHT) | curses.A_BOLD)
                self._scr.addstr(by + 5 + i, bx + 5 + 16, rest,
                                 curses.color_pair(HIGHLIGHT))
            except curses.error:
                pass
        r = by + 5 + len(controls)
        try:
            self._scr.addstr(r,     bx + 1, '─' * (bw - 2), curses.color_pair(HIGHLIGHT))
            self._scr.addstr(r + 1, bx + 5, '[ R ]  Resume',
                             curses.color_pair(GREEN) | curses.A_BOLD)
            self._scr.addstr(r + 2, bx + 5, '[ Q ]  Quit',
                             curses.color_pair(RED) | curses.A_BOLD)
        except curses.error:
            pass

    def gameover_screen(self, title: str = "GAME  OVER",
                        score_line: str = "", player_label: str = "",
                        rank: int | None = None, tick: int = 0,
                        prompt: str = "[ SPACE ] Play again   [ ESC ] Quit"):
        """
        Draw a standard game-over screen with optional score, player
        number, and global rank.
        """
        self.outer_border()
        mr = self.H // 2
        self.center(mr - 2, f'  {title}  ', RED, bold=True)
        if score_line:
            self.center(mr,     f'  {score_line}  ', YELLOW, bold=True)
        if player_label:
            self.center(mr + 1, f'  {player_label}  ', CYAN, bold=True)
        if rank is not None:
            self.center(mr + 2, f'  Global rank: #{rank}  ', GREEN, bold=True)
        elif player_label:
            self.text(mr + 2, max(0, (self.W - 23) // 2),
                      '  Submitting score...  ', WHITE, dim=True)
        if (tick // 15) % 2 == 0:
            self.center(mr + 4, prompt, WHITE)

    def menu(self, row: int, col: int,
             options: list[str], cursor: int,
             color_selected: int = HIGHLIGHT,
             color_normal: int = WHITE,
             width: int = 20):
        """
        Draw a vertical menu list with a cursor.

            > Option A
              Option B
              Option C
        """
        for i, opt in enumerate(options):
            label = (f'> {opt}' if i == cursor else f'  {opt}').ljust(width)[:width]
            self.text(row + i, col, label,
                      color_selected if i == cursor else color_normal,
                      bold=(i == cursor))

    def stars(self, star_list: list[StarDict]):
        """
        Draw a pre-generated parallax star field.
        Each star is a StarDict with keys: x, y, ch, cp (color pair int).
        Use make_stars() to generate the list.
        """
        for s in star_list:
            r, c = int(s['y']), int(s['x'])
            if 0 < r < self.H - 1 and 0 < c < self.W - 1:
                self.text(r, c, s['ch'], s['cp'], dim=True)


# ── Scene ──────────────────────────────────────────────────────────────────────
class Scene:
    """
    Base class for a game screen (intro, gameplay, pause, game over, etc.).

    Subclass this and implement:
        on_enter(self)              — called once when this scene becomes active
        update(self, inp, tick)     — game logic; return scene name to switch, or None
        draw(self, r, tick)         — render everything using r (a Renderer)

    Access the engine via self.engine.
    Access terminal size via self.engine.H and self.engine.W.
    """

    engine: "Engine"

    def on_enter(self): pass

    def update(self, inp: Input, tick: int) -> str | None:
        return None

    def draw(self, r: Renderer, tick: int): pass


# ── Engine ─────────────────────────────────────────────────────────────────────
class Engine:
    """
    The main game engine.

    Example:
        engine = (
            Engine("Snake", fps=15)
            .scene("menu",     MenuScene())
            .scene("game",     GameScene())
            .scene("gameover", GameOverScene())
        )
        engine.run("menu")
    """

    def __init__(self, title: str, fps: int = 30):
        self.title    = title
        self.fps      = fps
        self.H        = 0
        self.W        = 0
        self._scenes: dict[str, Scene] = {}
        self._current = ""
        self._scr     = None
        self._tick    = 0

    def scene(self, name: str, s: Scene) -> "Engine":
        """Register a scene. Returns self for chaining."""
        s.engine = self
        self._scenes[name] = s
        return self

    def switch(self, name: str):
        """Switch to a named scene immediately."""
        if name in self._scenes:
            self._current = name
            self._scenes[name].on_enter()

    def run(self, initial: str):
        """Start the game loop. Blocks until the game exits."""
        curses.wrapper(self._loop, initial)

    def _loop(self, scr, initial: str):
        self._scr = scr
        _init_curses(scr)
        self._tick = 0
        self.switch(initial)
        nxt = time.perf_counter()

        while True:
            now = time.perf_counter()
            if now < nxt:
                time.sleep(max(0.0, nxt - now - 0.001))
                continue
            nxt += 1.0 / self.fps
            self._tick += 1
            self.H, self.W = scr.getmaxyx()

            inp = Input._poll(scr)
            current = self._scenes.get(self._current)
            if current is None:
                break

            next_scene = current.update(inp, self._tick)
            if next_scene == "quit" or (inp.pause and self._current == ""):
                break
            if next_scene and next_scene != self._current:
                self.switch(next_scene)

            scr.erase()
            self._scenes[self._current].draw(
                Renderer(scr, self.H, self.W), self._tick
            )
            scr.refresh()


# ── Entity ─────────────────────────────────────────────────────────────────────
class Entity:
    """
    Base class for anything that moves and can be drawn.

    Override update() and draw(). Use collides() for AABB hit detection.
    """

    def __init__(self, x: float, y: float):
        self.x     = x
        self.y     = y
        self.vx    = 0.0
        self.vy    = 0.0
        self.alive = True

    def rect(self) -> tuple[float, float, float, float]:
        """Return (x, y, width, height) for collision. Override me."""
        return (self.x, self.y, 1.0, 1.0)

    def collides(self, other: "Entity") -> bool:
        """Axis-aligned bounding box collision check."""
        ax, ay, aw, ah = self.rect()
        bx, by, bw, bh = other.rect()
        return ax < bx + bw and ax + aw > bx and ay < by + bh and ay + ah > by

    def update(self, inp: Input, tick: int): pass
    def draw(self, r: Renderer): pass


class PhysicsEntity(Entity):
    """
    Entity with gravity, velocity, and floor collision.

    Set gravity on the class or instance. Call apply_physics(floor_y)
    each frame after handling input.
    """

    gravity: float = 1.5

    def __init__(self, x: float, y: float):
        super().__init__(x, y)
        self.grounded = False

    def apply_physics(self, floor_y: float):
        """Apply gravity, move, and resolve floor collision."""
        self.vy += self.gravity
        self.y  += self.vy
        self.x  += self.vx
        if self.y >= floor_y:
            self.y        = floor_y
            self.vy       = 0.0
            self.grounded = True
        else:
            self.grounded = False


# ── AnimSprite ─────────────────────────────────────────────────────────────────
class AnimSprite:
    """
    Frame-cycling sprite with named states.

        states = {
            'idle': [ ['( o )', '|=|', '/ \\'] ],          # 1 frame
            'run':  [ ['(_o_)', '/|\\', '/ \\'],            # 2 frames
                      ['(_o_)', '\\|/', '/ \\'] ],
        }
        sprite = AnimSprite(states, ticks_per_frame=6)
        sprite.set_state('run')
        sprite.tick()
        r.sprite(row, col, sprite.current())
    """

    def __init__(self, states: dict[str, list[list[str]]], ticks_per_frame: int = 8):
        self.states          = states
        self.ticks_per_frame = ticks_per_frame
        self.state           = next(iter(states))
        self._frame          = 0
        self._timer          = 0

    def set_state(self, state: str):
        if state != self.state and state in self.states:
            self.state  = state
            self._frame = 0
            self._timer = 0

    def tick(self):
        self._timer += 1
        if self._timer >= self.ticks_per_frame:
            self._timer  = 0
            frames       = self.states.get(self.state, [[]])
            self._frame  = (self._frame + 1) % max(1, len(frames))

    def current(self) -> list[str]:
        frames = self.states.get(self.state, [[' ']])
        return frames[self._frame % len(frames)]


# ── Camera ─────────────────────────────────────────────────────────────────────
class Camera:
    """
    Smooth-follow camera for scrolling worlds.

        cam = Camera()
        cam.follow(player.x, player.y)          # call each frame
        sx, sy = cam.world_to_screen(entity.x, entity.y, W, H)
    """

    def __init__(self):
        self.x = 0.0
        self.y = 0.0

    def follow(self, tx: float, ty: float, lerp: float = 0.1):
        """Lerp toward (tx, ty). lerp=1.0 is instant, 0.05 is very smooth."""
        self.x += (tx - self.x) * lerp
        self.y += (ty - self.y) * lerp

    def world_to_screen(self, wx: float, wy: float, W: int, H: int) -> tuple[int, int]:
        """Convert a world position to terminal (row, col)."""
        col = int(wx - self.x + W // 4)
        row = int(H - wy - 1)
        return row, col


# ── Particles ──────────────────────────────────────────────────────────────────
class Particles:
    """
    Simple explosion / spark particle system.

        particles = Particles()
        particles.explode(col, row)     # trigger an explosion
        particles.update()              # call each frame
        particles.draw(r)               # draw active particles
    """

    _EXPLOSION = [
        ['***', '*#*', '***'],
        ['·+·', '+o+', '·+·'],
        ['   ', ' · ', '   '],
    ]

    def __init__(self) -> None:
        # Each entry is either an ExplosionParticleDict or a SparkParticleDict.
        # The list is typed as their union so field access is type-safe.
        self._active: list[ExplosionParticleDict | SparkParticleDict] = []

    def explode(self, col: int, row: int) -> None:
        self._active.append(ExplosionParticleDict(col=col, row=row, f=0, t=0))

    def spark(self, col: int, row: int, char: str = '*', color: int = YELLOW, life: int = 6) -> None:
        self._active.append(SparkParticleDict(
            col=col, row=row, f=0, t=0,
            char=char, color=color, life=life, type='spark',
        ))

    def update(self) -> None:
        for p in self._active:
            p['t'] += 1
            if p.get('type') == 'spark':
                if p['t'] >= p['life']:  # type: ignore[typeddict-item]  # SparkParticleDict only
                    p['f'] = len(self._EXPLOSION)
            elif p['t'] >= 4:
                p['t'] = 0
                p['f'] += 1
        self._active = [p for p in self._active if p['f'] < len(self._EXPLOSION)]

    def draw(self, r: Renderer) -> None:
        for p in self._active:
            if p.get('type') == 'spark':
                # SparkParticleDict has 'char' and 'color'; mypy can't narrow through .get()
                r.text(p['row'], p['col'], p['char'], p['color'], bold=True)  # type: ignore[typeddict-item]
            else:
                frame = self._EXPLOSION[p['f']]
                r.sprite(p['row'] - 1, p['col'] - 1, frame, YELLOW, bold=True)


# ── Utilities ──────────────────────────────────────────────────────────────────
def make_stars(H: int, W: int, count: int = 80) -> list[StarDict]:
    """
    Generate a parallax star field.
    Pass the returned list to Renderer.stars() each frame,
    and call scroll_stars() to animate it.

        stars = make_stars(H, W)
    """
    result: list[StarDict] = []
    for _ in range(count):
        spd  = random.choice([0.25, 0.5, 1.0, 1.8])
        ch   = '·' if spd < 1.0 else ('+' if spd < 1.5 else '*')
        cp   = CYAN if spd >= 1.5 else (GREEN if spd >= 1.0 else WHITE)
        result.append({
            'x':   float(random.randint(1, max(1, W - 2))),
            'y':   float(random.randint(1, max(1, H - 5))),
            'spd': spd,
            'ch':  ch,
            'cp':  cp,
        })
    return result


def scroll_stars(stars: list[StarDict], W: int) -> None:
    """Scroll stars left. Call once per frame."""
    for s in stars:
        s['x'] -= s['spd']
        if s['x'] < 1:
            s['x'] = float(W - 2)


def distance(ax: float, ay: float, bx: float, by: float) -> float:
    return math.hypot(bx - ax, by - ay)


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


# ── Curses setup ───────────────────────────────────────────────────────────────
def setup_colors() -> None:
    """
    Initialize the standard Claudcade color pairs.

    Call this once inside a curses.wrapper() callback, before drawing anything.
    All game files share the same 8 color pairs — this is the single source of
    truth used by ctype.py, claudtra.py, fight.py, and claudcade.py.

    Color pair numbers match the module constants:
        CYAN=1  RED=2  GREEN=3  YELLOW=4  WHITE=5  MAGENTA=6  HIGHLIGHT=7  BLUE=8
    """
    curses.start_color()
    curses.use_default_colors()
    curses.init_pair(CYAN,      curses.COLOR_CYAN,    -1)
    curses.init_pair(RED,       curses.COLOR_RED,     -1)
    curses.init_pair(GREEN,     curses.COLOR_GREEN,   -1)
    curses.init_pair(YELLOW,    curses.COLOR_YELLOW,  -1)
    curses.init_pair(WHITE,     curses.COLOR_WHITE,   -1)
    curses.init_pair(MAGENTA,   curses.COLOR_MAGENTA, -1)
    curses.init_pair(HIGHLIGHT, curses.COLOR_BLACK, curses.COLOR_WHITE)
    curses.init_pair(BLUE,      curses.COLOR_BLUE,    -1)


def _init_curses(scr) -> None:  # scr: curses._CursesWindow, but curses stubs vary
    curses.cbreak()
    curses.noecho()
    scr.keypad(True)
    scr.nodelay(True)
    curses.curs_set(0)
    setup_colors()
    try:
        curses.mousemask(curses.ALL_MOUSE_EVENTS)
    except Exception:
        pass
