#!/usr/bin/env python3
"""Claudcade — The Claude Terminal Arcade Launcher"""
import curses, time, random, subprocess, os, sys
from claudcade_engine import setup_colors

# ── TITLE ART (CLAUDECADE in block font) ───────────────────────────────────────
TITLE = [
    " ██████╗██╗      █████╗ ██╗   ██╗██████╗ ███████╗ ██████╗ █████╗ ██████╗ ███████╗",
    "██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝",
    "██║     ██║     ███████║██║   ██║██║  ██║█████╗  ██║     ███████║██║  ██║█████╗  ",
    "██║     ██║     ██╔══██║██║   ██║██║  ██║██╔══╝  ██║     ██╔══██║██║  ██║██╔══╝  ",
    "╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝███████╗╚██████╗██║  ██║██████╔╝███████╗",
    " ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═════╝ ╚══════╝",
]

# Game block-font titles (for right panel display)
GAME_TITLES = {
    'ctype': [
        " ██████╗       ████████╗██╗   ██╗██████╗ ███████╗",
        "██╔════╝       ╚══██╔══╝╚██╗ ██╔╝██╔══██╗██╔════╝",
        "██║     ██████╗   ██║    ╚████╔╝ ██████╔╝█████╗  ",
        "██║     ╚═════╝   ██║     ╚██╔╝  ██╔═══╝ ██╔══╝  ",
        "╚██████╗          ██║      ██║   ██║     ███████╗",
        " ╚═════╝          ╚═╝      ╚═╝   ╚═╝     ╚══════╝",
    ],
    'claudtra': [
        " ██████╗██╗      █████╗ ██╗   ██╗██████╗ ████████╗██████╗  █████╗ ",
        "██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗",
        "██║     ██║     ███████║██║   ██║██║  ██║   ██║   ██████╔╝███████║",
        "██║     ██║     ██╔══██║██║   ██║██║  ██║   ██║   ██╔══██╗██╔══██║",
        "╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝   ██║   ██║  ██║██║  ██║",
        " ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝",
    ],
    'fight': [
        " ██████╗██╗      █████╗ ██╗   ██╗██████╗ ███████╗    ███████╗██╗ ██████╗ ██╗  ██╗████████╗███████╗██████╗ ",
        "██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗██╔════╝    ██╔════╝██║██╔════╝ ██║  ██║╚══██╔══╝██╔════╝██╔══██╗",
        "██║     ██║     ███████║██║   ██║██║  ██║█████╗      █████╗  ██║██║  ███╗███████║   ██║   █████╗  ██████╔╝",
        "██║     ██║     ██╔══██║██║   ██║██║  ██║██╔══╝      ██╔══╝  ██║██║   ██║██╔══██║   ██║   ██╔══╝  ██╔══██╗",
        "╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝███████╗    ██║     ██║╚██████╔╝██║  ██║   ██║   ███████╗██║  ██║",
        " ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝    ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝",
    ],
    'finalclaudesy': [
        "███████╗██╗███╗   ██╗ █████╗ ██╗          ██████╗██╗      █████╗ ██╗   ██╗██████╗ ███████╗███████╗██╗   ██╗",
        "██╔════╝██║████╗  ██║██╔══██╗██║         ██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗██╔════╝██╔════╝╚██╗ ██╔╝",
        "█████╗  ██║██╔██╗ ██║███████║██║         ██║     ██║     ███████║██║   ██║██║  ██║█████╗  ███████╗ ╚████╔╝ ",
        "██╔══╝  ██║██║╚██╗██║██╔══██║██║         ██║     ██║     ██╔══██║██║   ██║██║  ██║██╔══╝  ╚════██║  ╚██╔╝  ",
        "██║     ██║██║ ╚████║██║  ██║███████╗    ╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝███████╗███████║   ██║   ",
        "╚═╝     ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝     ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝   ╚═╝   ",
    ],
    'superclaudio': [
        "███████╗██╗   ██╗██████╗ ███████╗██████╗      ██████╗██╗      █████╗ ██╗   ██╗██████╗ ██╗ ██████╗ ",
        "██╔════╝██║   ██║██╔══██╗██╔════╝██╔══██╗    ██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗██║██╔═══██╗",
        "███████╗██║   ██║██████╔╝█████╗  ██████╔╝    ██║     ██║     ███████║██║   ██║██║  ██║██║██║   ██║",
        "╚════██║██║   ██║██╔═══╝ ██╔══╝  ██╔══██╗    ██║     ██║     ██╔══██║██║   ██║██║  ██║██║██║   ██║",
        "███████║╚██████╔╝██║     ███████╗██║  ██║    ╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝██║╚██████╔╝",
        "╚══════╝ ╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═╝     ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝ ╚═════╝ ",
    ],
    'claudturismo': [
        " ██████╗██╗      █████╗ ██╗   ██╗██████╗ ███████╗    ████████╗██╗   ██╗██████╗ ██╗███████╗███╗   ███╗ ██████╗ ",
        "██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗██╔════╝    ╚══██╔══╝██║   ██║██╔══██╗██║██╔════╝████╗ ████║██╔═══██╗",
        "██║     ██║     ███████║██║   ██║██║  ██║█████╗         ██║   ██║   ██║██████╔╝██║███████╗██╔████╔██║██║   ██║",
        "██║     ██║     ██╔══██║██║   ██║██║  ██║██╔══╝         ██║   ██║   ██║██╔══██╗██║╚════██║██║╚██╔╝██║██║   ██║",
        "╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝███████╗       ██║   ╚██████╔╝██║  ██║██║███████║██║ ╚═╝ ██║╚██████╔╝",
        " ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝       ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝ ",
    ],
    'claudemon': [
        " ██████╗██╗      █████╗ ██╗   ██╗██████╗ ███████╗███╗   ███╗ ██████╗ ███╗   ██╗",
        "██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗██╔════╝████╗ ████║██╔═══██╗████╗  ██║",
        "██║     ██║     ███████║██║   ██║██║  ██║█████╗  ██╔████╔██║██║   ██║██╔██╗ ██║",
        "██║     ██║     ██╔══██║██║   ██║██║  ██║██╔══╝  ██║╚██╔╝██║██║   ██║██║╚██╗██║",
        "╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝███████╗██║ ╚═╝ ██║╚██████╔╝██║ ╚████║",
        " ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝",
    ],
}

# ── GAME CATALOGUE ─────────────────────────────────────────────────────────────
# Each game has 'frames' (list of frame-art for animation) instead of static 'art'.
# Animation cycles every ~6 ticks via frames[(tick // 6) % len(frames)].

GAMES = [
    {
        'name':     'C-TYPE',
        'subtitle': 'SPACE SHOOTER',
        'script':   'ctype.py',
        'genre':    'SHMUP',
        'color':    1,
        'title_key': 'ctype',
        'desc': [
            'Dodge waves · Charge beam · Get power-ups',
            'Boss every 6th wave · Parallax starfield',
            '5 enemy types · Escalating difficulty',
            'Score system with local leaderboard',
        ],
        'controls': [
            'WASD / Arrows  Move',
            'J / SPACE      Fire',
            'Hold J         Charge beam',
            'ESC            Pause / Quit',
        ],
        # Animation: ship firing bullets at enemies that approach from right
        'frames': [
            ["  ▲          ◆ ",
             "═►·   ·   ·  ◇ ",
             "  ▼          ◆ "],
            ["  ▲       ·  ◆ ",
             "═► ·   ·     ◇ ",
             "  ▼          ◆ "],
            ["  ▲    ·     · ",
             "═►  ·     ·  ✦ ",
             "  ▼          · "],
            ["  ▲ ·  ·  ·  · ",
             "═►       ·   ✦ ",
             "  ▼ ·     ·  · "],
        ],
    },
    {
        'name':     'CLAUDTRA',
        'subtitle': 'RUN & GUN',
        'script':   'claudtra.py',
        'genre':    'ACTION',
        'color':    3,
        'title_key': 'claudtra',
        'desc': [
            'Side-scrolling action platformer',
            'Grunt and heavy enemies · Multi-life system',
            'Jump, crouch, shoot through waves',
            'Score system with local leaderboard',
        ],
        'controls': [
            'A / D          Move left / right',
            'SPACE          Jump',
            'J              Shoot',
            'S              Crouch · ESC  Pause',
        ],
        # Animation: running character firing right
        'frames': [
            ["  ╭─╮          ",
             "  │·│═►  · · ◆ ",
             "  ╰┬╯          ",
             " ╱ ╲           "],
            ["  ╭─╮    ·     ",
             "  │·│═► · ·  ◆ ",
             "  ╰┬╯          ",
             " ╲╱            "],
            ["  ╭─╮  ·       ",
             "  │·│═►·    · ◆",
             "  ╰┬╯          ",
             " ╱╲            "],
            ["  ╭─╮·         ",
             "  │·│═►  ·· · ✦",
             "  ╰┬╯          ",
             " ╲ ╱           "],
        ],
    },
    {
        'name':     'CLAUDE FIGHTER',
        'subtitle': '1V1 FIGHTING',
        'script':   'fight.py',
        'genre':    'FIGHTING',
        'color':    2,
        'title_key': 'fight',
        'desc': [
            '5 unique fighters with distinct styles',
            'Punch, kick, block, jump mechanics',
            'Best of 3 rounds vs AI opponent',
            'Score system with local leaderboard',
        ],
        'controls': [
            'A / D          Move',
            'SPACE          Jump',
            'J              Punch',
            'K  Kick · L  Block · S  Crouch',
        ],
        # Animation: two fighters trading punches
        'frames': [
            ["  ◯       ◯  ",
             " ╱│╲     ╱│╲ ",
             "  ╱╲     ╱╲  "],
            ["  ◯       ◯  ",
             " ╱│═►   ◀═│╲ ",
             "  ╱╲     ╱╲  "],
            ["  ◯  ✦   ✦◯  ",
             " ╱│════ ════│╲",
             "  ╱╲     ╱╲  "],
            ["  ◯       ◯  ",
             "╲╱│       │╲╱",
             "  ╱╲     ╱╲  "],
        ],
    },
    {
        'name':     'SUPER CLAUDIO',
        'subtitle': 'PLATFORMER',
        'script':   None,
        'genre':    'PLATFORM',
        'color':    4,
        'title_key': 'superclaudio',
        'coming_soon': True,
        'desc': [
            'Save the princess. Jump, stomp, collect.',
            '4 worlds · Power-ups · Hidden levels',
            'Classic platforming action',
            'COMING SOON · In development',
        ],
        'controls': [
            'A / D          Move',
            'W / SPACE      Jump',
            'J              Fire / Run',
            'ESC            Pause',
        ],
        # Animation: jumping character collecting coins
        'frames': [
            ["    ★         ",
             "   ◯  ◆  ◆    ",
             "  ╱│╲         ",
             "  ╱ ╲ ▓▓▓▓▓▓▓ "],
            ["    ★ ◆       ",
             "   ◯     ◆    ",
             "  ╱│╲         ",
             "  ╱ ╲ ▓▓▓▓▓▓▓ "],
            ["    ◯ ◆       ",
             "   ╱│╲   ◆    ",
             "    ▼         ",
             "  ╱ ╲ ▓▓▓▓▓▓▓ "],
            ["    ★         ",
             "   ◯     ✦    ",
             "  ╱│╲         ",
             "  ╱ ╲ ▓▓▓▓▓▓▓ "],
        ],
    },
    {
        'name':     'CLAUDTURISMO',
        'subtitle': 'RACING',
        'script':   None,
        'genre':    'RACING',
        'color':    1,
        'title_key': 'claudturismo',
        'coming_soon': True,
        'desc': [
            'Pseudo-3D racing · 3 laps, real curves',
            '8 tracks · 5 cars · Time attack mode',
            'Drift physics · Boost system',
            'COMING SOON · In development',
        ],
        'controls': [
            'W / UP         Accelerate',
            'S / DOWN       Brake',
            'A / D          Steer',
            'SPACE          Boost',
        ],
        # Animation: car driving with road scrolling
        'frames': [
            ["   ╱─────╲   ",
             "  ╱  ◉═◉  ╲  ",
             "  ▔▔▔▔▔▔▔▔▔  ",
             "  ║│ │ │ │║  "],
            ["   ╱─────╲   ",
             "  ╱  ◉═◉  ╲  ",
             "  ▔▔▔▔▔▔▔▔▔  ",
             "  │║ │ │ │║  "],
            ["   ╱─────╲   ",
             "  ╱  ◉═◉  ╲  ",
             "  ▔▔▔▔▔▔▔▔▔  ",
             "  │ ║│ │ │║  "],
            ["   ╱─────╲   ",
             "  ╱  ◉═◉  ╲  ",
             "  ▔▔▔▔▔▔▔▔▔  ",
             "  │ │║ │ │║  "],
        ],
    },
    {
        'name':     'CLAUDEMON',
        'subtitle': 'CREATURE RPG',
        'script':   None,
        'genre':    'CRTR-RPG',
        'color':    3,
        'title_key': 'claudemon',
        'coming_soon': True,
        'desc': [
            'Catch all 20 creatures · Turn-based battles',
            'Type matchups · Evolution · Trading',
            '6 gym leaders · Elite Four · Champion',
            'COMING SOON · In development',
        ],
        'controls': [
            'WASD / Arrows  Move',
            'SPACE          Confirm',
            'M              Menu',
            'B              Bag / Items',
        ],
        # Animation: creature wiggling with sparkles
        'frames': [
            ["   ╭───╮     ",
             "   │◉ ◉│  ✦  ",
             "   ╰─◡─╯     ",
             "    ╱╲       "],
            ["    ╭───╮    ",
             "    │◉ ◉│ ✧  ",
             "    ╰─◡─╯    ",
             "     ╱╲      "],
            ["   ╭───╮     ",
             " ✦ │● ●│     ",
             "   ╰─◠─╯     ",
             "    ╱╲       "],
            ["    ╭───╮    ",
             "  ✧ │◉ ◉│    ",
             "    ╰─◡─╯    ",
             "     ╱╲      "],
        ],
    },
    {
        'name':     'FINAL CLAUDESY',
        'subtitle': 'EPIC JRPG',
        'script':   'finalclaudesy.py',
        'genre':    'RPG',
        'color':    6,
        'title_key': 'finalclaudesy',
        'desc': [
            '3 heroes · 3 regions · 20+ spells',
            'Turn-based combat · Equipment system',
            'Towns, dungeons, NPCs, full story',
            '~3 hours of content · Multiple endings',
        ],
        'controls': [
            'WASD / Arrows  Move or select',
            'SPACE / Enter  Confirm action',
            'M              Open party menu',
            'Q / ESC        Cancel / Back',
        ],
        # Animation: hero swinging sword
        'frames': [
            ["    ◯        ",
             "   ╱│╲═►     ",
             "    │  ◆     ",
             "   ╱ ╲       "],
            ["    ◯        ",
             "   ╱│         ",
             "    │═►◆     ",
             "   ╱ ╲       "],
            ["    ◯        ",
             "   ╱│         ",
             "    │  ✦◆    ",
             "   ╱ ╲═►     "],
            ["    ◯        ",
             "  ◀═│╲       ",
             "    │   ◆    ",
             "   ╱ ╲       "],
        ],
    },
]

# ── DRAWING HELPERS ────────────────────────────────────────────────────────────
def _p(scr, H, W, r, c, s, a=0):
    try:
        if 0 <= r < H-1 and 0 <= c < W:
            scr.addstr(r, c, s[:max(0, W-c)], a)
    except curses.error:
        pass

# ── MAIN SCREEN ────────────────────────────────────────────────────────────────
def draw_main(scr, H, W, tick, cursor):
    P = curses.color_pair
    scr.erase()

    # ── Animated background stars ──────────────────────────────────────────
    random.seed(999)
    for _ in range(40):
        r = random.randint(1, H-2)
        c = random.randint(1, W-2)
        ch = random.choice(['·', '·', '·', '+', '*'])
        if (tick // 8 + r * 3 + c) % 11 == 0:
            _p(scr, H, W, r, c, ch, P(5)|curses.A_DIM)
    random.seed()

    # ── Outer border ────────────────────────────────────────────────────────
    _p(scr, H, W, 0,   0, '╔'+'═'*(W-2)+'╗', P(5)|curses.A_BOLD)
    _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        _p(scr, H, W, r, 0,   '║', P(5))
        _p(scr, H, W, r, W-1, '║', P(5))

    # ── Header block (shaded depth) ─────────────────────────────────────────
    shade_full = '▓▒░' + '░'*(W-8) + '░▒▓'
    _p(scr, H, W, 1, 1, shade_full[:W-2], P(5)|curses.A_DIM)

    # Title art — gradient from blue → cyan → magenta → pink (top to bottom)
    # Standard 8-color palette: BLUE(8), CYAN(1), MAGENTA(6) approximate the gradient
    title_colors = [
        P(8)|curses.A_BOLD,  # bright blue
        P(8)|curses.A_BOLD,  # bright blue
        P(1)|curses.A_BOLD,  # cyan (transition)
        P(6),                # magenta (transition)
        P(6)|curses.A_BOLD,  # bright pink/magenta
        P(6)|curses.A_BOLD,  # bright pink/magenta
    ]
    for i, line in enumerate(TITLE):
        tx = max(1, (W - len(line)) // 2)
        _p(scr, H, W, 2+i, tx, line, title_colors[i % len(title_colors)])

    # Compute layout based on actual title height
    TITLE_END = 2 + len(TITLE)  # title rows: 2..TITLE_END-1
    sub = '◈   T H E   C L A U D E   T E R M I N A L   A R C A D E   ◈'
    _p(scr, H, W, TITLE_END, max(1, (W-len(sub))//2), sub, P(6)|curses.A_BOLD)

    _p(scr, H, W, TITLE_END+1, 1, shade_full[:W-2], P(5)|curses.A_DIM)

    # ── Section divider ─────────────────────────────────────────────────────
    DIV = TITLE_END + 2
    _p(scr, H, W, DIV, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)

    # ── Vertical panel split ─────────────────────────────────────────────────
    LIST_W  = 30
    SPLIT   = LIST_W + 1
    DET_X   = SPLIT + 1
    DET_W   = W - DET_X - 1
    PANEL_Y = DIV + 1

    for r in range(PANEL_Y, H-3):
        _p(scr, H, W, r, SPLIT, '║', P(5))
    _p(scr, H, W, DIV,  SPLIT, '╦', P(5)|curses.A_BOLD)
    _p(scr, H, W, H-3,  SPLIT, '╩', P(5)|curses.A_BOLD)

    # ── Game list (left panel) ───────────────────────────────────────────────
    _p(scr, H, W, PANEL_Y,   2, 'GAMES',  P(5)|curses.A_BOLD)
    _p(scr, H, W, PANEL_Y,  22, 'GENRE',  P(5)|curses.A_DIM)
    _p(scr, H, W, PANEL_Y+1, 2, '─'*(LIST_W-2), P(5)|curses.A_DIM)

    # One row per game so all 7 fit comfortably in a standard 24-row terminal.
    # Every game uses its assigned color — coming-soon games are still in
    # color, just marked with a star prefix in the genre column.
    for i, g in enumerate(GAMES):
        gy = PANEL_Y + 2 + i
        if gy >= H-4: break
        sel = (i == cursor)
        cs  = g.get('coming_soon')
        prefix = '▶ ' if sel else '  '
        gcp = g['color']
        name_a  = (P(gcp)|curses.A_BOLD|curses.A_REVERSE) if sel else (P(gcp)|curses.A_BOLD)
        genre_a = P(7) if sel else (P(5)|curses.A_DIM)
        _p(scr, H, W, gy,   2, prefix + g['name'][:17], name_a)
        # Coming-soon games get a small ✦ marker in the genre column to flag them.
        genre_text = f'[{g["genre"]:7}]'
        if cs:
            _p(scr, H, W, gy, 19, '✦', P(gcp)|curses.A_BOLD)
        _p(scr, H, W, gy,  21, genre_text, genre_a)

    # ── Game detail (right panel) ────────────────────────────────────────────
    g   = GAMES[cursor]
    gcp = g['color']

    # Block-font game title — centered horizontally in the detail panel.
    title_key = g.get('title_key', g['name'].lower().replace(' ', ''))
    if title_key in GAME_TITLES:
        ART_Y = PANEL_Y
        title_lines = GAME_TITLES[title_key]
        for i, line in enumerate(title_lines):
            if ART_Y + i < H - 4:
                trimmed = line[:DET_W-2] if len(line) > DET_W-2 else line
                # Center within the detail panel (DET_X to DET_X+DET_W).
                tx = DET_X + max(1, (DET_W - len(trimmed)) // 2)
                _p(scr, H, W, ART_Y+i, tx, trimmed, P(gcp)|curses.A_BOLD)
        ART_Y += len(title_lines)
    else:
        ART_Y = PANEL_Y
        gt   = f'★  {g["name"]}  —  {g["subtitle"]}  ★'
        _p(scr, H, W, ART_Y, DET_X+1, gt[:DET_W-2], P(gcp)|curses.A_BOLD)
        ART_Y += 1

    _p(scr, H, W, ART_Y, DET_X+1, '═'*(DET_W-2), P(gcp)|curses.A_DIM)

    # Game sprite — animated preview using frames[(tick // 6) % len(frames)]
    ART_Y = ART_Y + 2
    ART_X = DET_X + 3
    frames = g.get('frames') or [g.get('art', [])]
    art    = frames[(tick // 6) % len(frames)] if frames else []
    if art:
        aw    = max(len(l) for l in art) + 2
        ah    = len(art) + 2
        if ART_Y + ah < H - 6:
            _p(scr, H, W, ART_Y,      ART_X-2, '┌'+'─'*aw+'┐', P(5)|curses.A_DIM)
            _p(scr, H, W, ART_Y+ah-1, ART_X-2, '└'+'─'*aw+'┘', P(5)|curses.A_DIM)
            for r in range(1, ah-1):
                _p(scr, H, W, ART_Y+r, ART_X-2, '│', P(5)|curses.A_DIM)
                _p(scr, H, W, ART_Y+r, ART_X-2+aw+1, '│', P(5)|curses.A_DIM)
            for i, line in enumerate(art):
                _p(scr, H, W, ART_Y+1+i, ART_X, line, P(gcp)|curses.A_BOLD)

    # Description
    DESC_X = DET_X + 2
    _p(scr, H, W, ART_Y,   DESC_X, g['subtitle'], P(gcp)|curses.A_BOLD)
    _p(scr, H, W, ART_Y+1, DESC_X, '─'*max(0, DET_W-2), P(5)|curses.A_DIM)
    for i, line in enumerate(g['desc']):
        if ART_Y+2+i < H-5:
            _p(scr, H, W, ART_Y+2+i, DESC_X, f'• {line}', P(5))

    # Controls
    CTRL_Y = ART_Y + len(g['desc']) + 3
    if CTRL_Y < H - 5:
        _p(scr, H, W, CTRL_Y, DET_X+2, 'CONTROLS', P(5)|curses.A_BOLD)
        _p(scr, H, W, CTRL_Y, DET_X+12, '─'*max(0, DET_W-12), P(5)|curses.A_DIM)
        for i, ctrl in enumerate(g['controls']):
            ky, rest = ctrl.split(None, 1) if ' ' in ctrl else (ctrl, '')
            cy = CTRL_Y + 1 + i
            if cy >= H-4: break
            _p(scr, H, W, cy, DET_X+4, ky, P(gcp)|curses.A_BOLD)
            pad = 14 - len(ky)
            _p(scr, H, W, cy, DET_X+4+len(ky)+max(1,pad), rest, P(5))

    # Launch prompt (blinking) — different message for coming-soon games
    if (tick // 15) % 2 == 0:
        if g.get('coming_soon'):
            lp = f'★ COMING SOON ★  {g["name"]}'
            attr = P(5)|curses.A_BOLD|curses.A_REVERSE
        else:
            lp = f'[ ENTER ]  Launch  {g["name"]}'
            attr = P(gcp)|curses.A_BOLD|curses.A_REVERSE
        lx = DET_X + (DET_W - len(lp)) // 2
        _p(scr, H, W, H-4, lx, lp, attr)

    # ── Footer ──────────────────────────────────────────────────────────────
    _p(scr, H, W, H-3, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)
    foot = f'  ↑↓  Select     ENTER  Launch     Q  Quit              {len(GAMES)} GAMES  ·  Claudcade v1.0'
    _p(scr, H, W, H-2, 2, foot, P(5))

    scr.refresh()

# ── ARCADE MAIN ────────────────────────────────────────────────────────────────
_launch_script = None

def arcade_main(scr):
    global _launch_script
    curses.cbreak(); curses.noecho(); scr.keypad(True)
    scr.nodelay(True); curses.curs_set(0)
    setup_colors()
    try: curses.mousemask(0)  # disable mouse for the launcher
    except curses.error: pass

    cursor = 0
    nxt    = time.perf_counter()
    tick   = 0

    while True:
        now = time.perf_counter()
        if now < nxt: time.sleep(max(0, nxt-now-0.001)); continue
        nxt += 1/60; tick += 1

        H, W = scr.getmaxyx()
        keys = set()
        while True:
            k = scr.getch()
            if k == -1: break
            keys.add(k)

        UP   = curses.KEY_UP   in keys or ord('w') in keys
        DOWN = curses.KEY_DOWN in keys or ord('s') in keys
        OK   = any(k in keys for k in (ord('\n'), 10, 13, ord(' ')))
        QUIT = ord('q') in keys or ord('Q') in keys or 27 in keys

        if UP:   cursor = (cursor-1) % len(GAMES)
        if DOWN: cursor = (cursor+1) % len(GAMES)
        if QUIT: _launch_script = None; break
        if OK:
            if GAMES[cursor].get('coming_soon'):
                # Don't launch; just buzz visually next loop
                continue
            _launch_script = GAMES[cursor]['script']
            break

        draw_main(scr, H, W, tick, cursor)

def run():
    global _launch_script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    while True:
        try:
            curses.wrapper(arcade_main)
        except curses.error as e:
            print('\n  ERROR: Curses terminal support failed')
            print('  This usually means you\'re not in a proper interactive terminal.\n')
            print('  To play Claudcade, run it in a tmux session:')
            print('    $ tmux')
            print('    $ python3 claudcade.py\n')
            break
        except KeyboardInterrupt:
            print('\n  Thanks for playing — Claudcade\n')
            break

        if _launch_script is None:
            print('\n  Thanks for playing — Claudcade\n')
            break
        script = os.path.join(script_dir, _launch_script)
        subprocess.run([sys.executable, script], cwd=script_dir)

if __name__ == '__main__':
    run()
