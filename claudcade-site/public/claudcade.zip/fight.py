#!/usr/bin/env python3
"""CLAUDE FIGHTER — ESC to quit back to Claude"""
import curses, time, random
from claudcade_engine import Renderer, setup_colors
try:
    from claudcade_scores import submit_async
except ImportError:
    def submit_async(*a, **kw): pass

# ── GAME STATES ───────────────────────────────────────────────────────────────
INTRO, SELECT, COUNTDOWN, FIGHT, PAUSE, HOW_TO_PLAY = range(6)

CONTROLS = [
    'A / D           Move left / right',
    'SPACE           Jump',
    'S               Crouch',
    'J / Click       Punch',
    'K               Kick',
    'L               Block',
    'ESC             Pause / Resume',
    'Q               Quit to Claudcade',
]

def draw_pause(scr, H, W):
    Renderer(scr, H, W).pause_overlay('CLAUDE FIGHTER', CONTROLS)

def _fight_put(scr, H, W, r, c, s, a=0):
    try:
        if 0 <= r < H-1 and 0 <= c < W: scr.addstr(r, c, s[:W-c], a)
    except: pass

def draw_how_to_play(scr, H, W, tick):
    P = curses.color_pair
    scr.erase()
    BW = min(70, W-4)
    lm = (W - BW) // 2
    fp = lambda r,c,s,a=0: _fight_put(scr,H,W,r,c,s,a)

    fp(0, lm, '╔' + '═'*(BW-2) + '╗', P(5)|curses.A_BOLD)
    fp(H-1, lm, '╚' + '═'*(BW-2) + '╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        fp(r, lm, '║', P(5)|curses.A_BOLD)
        fp(r, lm+BW-1, '║', P(5)|curses.A_BOLD)

    title = 'H O W   T O   P L A Y'
    hdr = '▓▒░' + title.center(BW-8) + '░▒▓'
    fp(1, lm+1, hdr, P(4)|curses.A_BOLD)
    fp(2, lm, '╠' + '═'*(BW-2) + '╣', P(5)|curses.A_BOLD)

    row = 4
    def ln(text='', color=5, bold=False):
        nonlocal row
        attr = P(color) | (curses.A_BOLD if bold else 0)
        fp(row, lm+2, text[:BW-4], attr)
        row += 1

    ln('GOAL', 4, True)
    ln('────', 5)
    ln('Defeat the AI opponent in a best of 3 rounds. Each round ends when', 5)
    ln('one fighter reaches 0 HP.', 5)
    ln()
    ln('CONTROLS', 4, True)
    ln('────────', 5)
    ln('A / D            Move left / right', 5)
    ln('SPACE            Jump', 5)
    ln('J                Punch', 5)
    ln('K                Kick', 5)
    ln('L                Block', 5)
    ln('ESC              Pause', 5)
    ln()
    ln('TIPS', 4, True)
    ln('────', 5)
    ln('• Block reduces damage', 5)
    ln('• A landed punch or kick stuns the opponent', 5)
    ln('• Stay mobile', 5)

    if (tick//15)%2==0:
        msg = 'PRESS SPACE TO START'
        fp(H-3, lm + (BW-len(msg))//2, msg, P(4)|curses.A_BOLD)
    scr.refresh()

# ── CONSTANTS ─────────────────────────────────────────────────────────────────
FPS      = 30
ARENA_W  = 68
SW, SH   = 9, 6
WALK     = 1.4          # was 1.8 — slightly slower for readability
JV0      = 6.0          # was 9.0 — slower, arc-ier jump
GRAV     = 0.8          # was 1.4 — floatier so jump is readable
MINSEP   = SW + 1
PR, KR   = 13, 16
PD, KD   = 6, 8         # was 10, 13 — lower damage so rounds last 20-30 s
BM       = 0.08
MHP      = 100
STUN_DUR = 18           # was 6 — 0.6 s of visible stun makes hits feel weighty
NEED     = 2
ADUR     = {'idle':14,'walk':7,'punch':11,'kick':11,'block':1,
            'hurt':8,'crouch':1,'jump':1,'ko':1,'victory':16}

# ── TITLE ART ─────────────────────────────────────────────────────────────────
TITLE_ART = [
    r" ___  _      _   _   _  ___  ___ ",
    r"/ __|| |    /_\ | | | ||   \| __|",
    r"| (__ | |_ / _ \| |_| || |) | _| ",
    r" \___||___/_/ \_|\___/ |___/|___|",
    r"",
    r" ___ _  ___ _  _ _____ ___ ___ ",
    r"| __|| ||_ _|| || |_   _| __| _ \ ",
    r"| _| |_|| || __ | | | | _||   /",
    r"|_|   \__|_||_||_| |_| |___|_|_\ ",
]

# ── CHARACTER ROSTER ──────────────────────────────────────────────────────────
CHARS = [
    {
        'name': 'WARRIOR', 'title': 'Iron Fist',
        'desc': 'Heavy power, tough defense',
        'cp': 1, 'power': 1.3, 'speed': 0.85, 'defense': 1.2,
        'portrait': [
            "  _/O\\_  ",
            " /|X X|\\ ",
            " \\|   |/ ",
            "  _|||_  ",
            " / ||| \\ ",
            "/  |||  \\",
            "   | |   ",
            "  _| |_  ",
        ],
        'stats': [('PWR','████████  '),('SPD','█████     '),('DEF','████████  ')],
    },
    {
        'name': 'NINJA', 'title': 'Shadow Step',
        'desc': 'Lightning fast, elusive',
        'cp': 2, 'power': 0.85, 'speed': 1.5, 'defense': 0.8,
        'portrait': [
            "  /-*-\\  ",
            " | o_o | ",
            "  \\___/  ",
            "  _|=|_  ",
            " /  |  \\ ",
            "/   |   \\",
            "  __|__  ",
            " /  |  \\ ",
        ],
        'stats': [('PWR','█████     '),('SPD','██████████'),('DEF','████      ')],
    },
    {
        'name': 'SAMURAI', 'title': 'Steel Blade',
        'desc': 'Long reach, disciplined',
        'cp': 4, 'power': 1.1, 'speed': 0.95, 'defense': 1.05,
        'portrait': [
            "  (===)  ",
            " [[^_^]] ",
            "  [[ ]]  ",
            "   \\|/   ",
            "   =|===>",
            "  / |    ",
            " /  |    ",
            "/   |    ",
        ],
        'stats': [('PWR','███████   '),('SPD','██████    '),('DEF','███████   ')],
    },
    {
        'name': 'MONK', 'title': 'Stone Palm',
        'desc': 'Balanced, deadly counters',
        'cp': 3, 'power': 1.0, 'speed': 1.1, 'defense': 1.1,
        'portrait': [
            "   ~~~   ",
            "  (^_^)  ",
            "  )| |(  ",
            "  _\\_/_  ",
            " (_(_)_) ",
            "  / | \\  ",
            " /  |  \\ ",
            "/   |   \\",
        ],
        'stats': [('PWR','██████    '),('SPD','███████   '),('DEF','███████   ')],
    },
]

# ── SPRITES ───────────────────────────────────────────────────────────────────
def frm(*rows, w=SW, h=SH):
    out = [(r + ' '*w)[:w] for r in rows]
    while len(out) < h: out.append(' '*w)
    return out[:h]

SP1 = {
    'idle':   [frm('   O   ','  /|\\  ','   |   ','  /|\\  ','  / \\  ','       '),
               frm('   O   ','  \\|/  ','   |   ','  /|\\  ','  / \\  ','       ')],
    'walk':   [frm('   O   ','  /|\\  ','  _|   ','   /\\  ',' /     ','       '),
               frm('   O   ','  \\|/  ','   |_  ','   /\\  ','     \\ ','       ')],
    'punch':  [frm('   O   ',' -(|   ','   |   ','  /|\\  ','  / \\  ','       '),
               frm('   O   ','  (|->>','   |   ','  /|\\  ','  / \\  ','       '),
               frm('   O   ','  \\|/  ','   |   ','  /|\\  ','  / \\  ','       ')],
    'kick':   [frm('   O   ','  /|\\  ','   |   ','  /|   ','  /\\   ','       '),
               frm('   O   ','  \\|   ','   |   ','   |->>','  /    ','       '),
               frm('   O   ','  /|\\  ','   |   ','  /|\\  ','  / \\  ','       ')],
    'block':  [frm('   O   ','[/|\\]  ',' [_|_] ','  / \\  ','  / \\  ','       ')],
    'hurt':   [frm('  >O<  ',' ~/|\\ ~','   |   ','  /|\\  ','  \\ /  ','       '),
               frm('  *O*  ','  /|\\  ','   |   ','  /|\\  ','  \\ /  ','       ')],
    'crouch': [frm('       ','   O   ','  /|\\  ',' /(_)\\ ','       ','       ')],
    'jump':   [frm(' \\\\O// ','   |   ','  /|\\  ','  | |  ','       ','       ')],
    'ko':     [frm('       ','       ',' (x.x) ','~~-O-~~',' \\___/ ','       ')],
    'victory':[frm('  \\O/  ','   |   ','  /|   ','  / \\  ','       ','       '),
               frm('   O/  ','  /|   ','  /|   ','  / \\  ','       ','       ')],
}

def _mirror(frames):
    t={'(':')',')':'(','/':'\\','\\':'/','>':'<','<':'>','[':']',']':'['}
    return [[''.join(t.get(c,c) for c in reversed(row)) for row in fr] for fr in frames]

SP2 = {k: _mirror(v) for k,v in SP1.items()}

# ── FIGHTER ───────────────────────────────────────────────────────────────────
class Fighter:
    def __init__(self, name, x, cp, char_def, is_p2=False, is_ai=False):
        self.name=name; self.x=float(x); self.y=0.0; self.vy=0.0
        self.cp=cp; self.is_p2=is_p2; self.is_ai=is_ai
        self.sp=SP2 if is_p2 else SP1
        self.power=char_def['power']; self.speed=char_def['speed']
        self.defense=char_def['defense']
        self.hp=MHP; self.velx=0.0; self.grounded=True
        self.state='idle'; self.af=0; self.at=0
        self.stun=0; self.hit_dealt=False; self.ai_cd=0

    def set(self,s):
        if self.state==s: return
        self.state=s; self.af=0; self.at=0; self.hit_dealt=False

    def tick_anim(self):
        spd=ADUR.get(self.state,6)
        self.at+=1
        if self.at>=spd:
            self.at=0
            frames=self.sp.get(self.state,self.sp['idle'])
            self.af=(self.af+1)%len(frames)
            if self.state in ('punch','kick') and self.af==0: return True
        return False

    def frame(self):
        frames=self.sp.get(self.state,self.sp['idle'])
        return frames[self.af%len(frames)]

    def hit_active(self): return self.state in ('punch','kick') and self.af==1
    def alive(self): return self.hp>0

    def can_be_hit_by(self, atk_state):
        """Crouch dodges punches. Jump (high enough) dodges kicks."""
        if atk_state=='punch' and self.state=='crouch':
            return False
        if atk_state=='kick' and self.y>3.5:
            return False
        return True

    def take_hit(self, dmg):
        if not self.alive() or self.state=='ko': return 0
        m=BM if self.state=='block' else 1.0
        actual=max(1,int(dmg*m*self.defense))
        self.hp=max(0,self.hp-actual)
        if self.hp==0:            self.set('ko');   self.stun=9999
        elif self.state!='block': self.set('hurt'); self.stun=STUN_DUR
        return actual

    def physics(self, other):
        if not self.grounded:
            self.vy-=GRAV; self.y+=self.vy
            if self.y<=0:
                self.y=0.0; self.vy=0.0; self.grounded=True
                if self.state=='jump': self.set('idle')
        self.x+=self.velx
        self.x=max(0.0,min(ARENA_W,self.x))
        dx=other.x-self.x
        if abs(dx)<MINSEP:
            push=(MINSEP-abs(dx))/2
            if dx>=0: self.x-=push; other.x+=push
            else:     self.x+=push; other.x-=push
        self.x=max(0.0,min(ARENA_W,self.x))
        other.x=max(0.0,min(ARENA_W,other.x))

    def player_input(self, keys, mouse_punch=False, mouse_kick=False):
        if self.state in ('punch','kick'): return
        ws=WALK*self.speed
        self.velx=0.0; moving=False
        if ord('a') in keys: self.velx=-ws; moving=True
        if ord('d') in keys: self.velx= ws; moving=True
        jump=ord('w') in keys or ord(' ') in keys
        if jump and self.grounded:
            self.vy=JV0; self.grounded=False; self.set('jump')
        if ord('s') in keys and self.grounded: self.set('crouch'); moving=True
        if   ord('j') in keys or mouse_punch: self.set('punch')
        elif ord('k') in keys or mouse_kick:  self.set('kick')
        elif ord('l') in keys: self.set('block')
        elif moving and self.grounded and self.state not in ('crouch',): self.set('walk')
        elif not moving and self.grounded and self.state not in \
             ('punch','kick','block','jump','crouch','hurt','ko'): self.set('idle')

    def ai_input(self, opp):
        self.ai_cd-=1
        dx=opp.x-self.x; dist=abs(dx)
        ws=WALK*self.speed; self.velx=0.0
        if self.state not in ('punch','kick','block'):
            if   dist>KR+4: self.velx=ws*0.65*(1 if dx>0 else -1); self.set('walk') if self.grounded else None
            elif dist>PR+3: self.velx=ws*0.3*(1 if dx>0 else -1)
        if self.ai_cd<=0:
            # Slower reaction: 18-32 frames (0.6–1.1 s) between decisions
            self.ai_cd=random.randint(18,32)
            if self.state in ('punch','kick'): return
            r=random.random()
            if dist<=PR:
                # Attack 40% of the time (was ~60%), block 15%, idle the rest
                if   r<0.22: self.set('punch'); self.velx=0
                elif r<0.40: self.set('kick');  self.velx=0
                elif r<0.55: self.set('block')
                else:        self.set('idle')
            elif dist<=KR+3:
                # Only kick or jump 25% of the time at medium range
                if r<0.18: self.set('kick'); self.velx=0
                elif r<0.25 and self.grounded:
                    self.vy=JV0; self.grounded=False; self.set('jump')

    def update(self, other, keys=None, mp=False, mk=False):
        if self.stun>0:
            self.stun-=1
            if self.stun==0 and self.state=='hurt': self.set('idle')
        self.velx=0.0
        frozen=self.state in ('ko','hurt') and self.stun>0
        if not frozen:
            if self.is_ai:         self.ai_input(other)
            elif keys is not None: self.player_input(keys,mp,mk)
        if self.state in ('punch','kick'):
            if self.tick_anim(): self.set('idle')
        else: self.tick_anim()
        self.physics(other)

# ── GAME ──────────────────────────────────────────────────────────────────────
class Game:
    def __init__(self, p1_char, p2_char):
        self.p1_char=p1_char; self.p2_char=p2_char
        self.p1w=0; self.p2w=0; self.rnd=1
        self.msg=''; self.msg_t=0; self.flash=0; self.sparks=[]
        self.over=False
        self._new()

    def _new(self):
        c1=CHARS[self.p1_char]; c2=CHARS[self.p2_char]
        self.p1=Fighter(c1['name'],14,c1['cp'],c1,is_p2=False,is_ai=False)
        self.p2=Fighter(c2['name'],54,c2['cp'],c2,is_p2=True, is_ai=True)
        self.over=False; self.sparks=[]

    def show(self,m,d=120): self.msg=m; self.msg_t=d

    def _hits(self):
        for a,d in [(self.p1,self.p2),(self.p2,self.p1)]:
            if a.hit_active() and not a.hit_dealt:
                rng=KR if a.state=='kick' else PR
                if abs(d.x-a.x)<=rng and d.can_be_hit_by(a.state):
                    dmg=KD if a.state=='kick' else PD
                    actual=d.take_hit(int(dmg*a.power))
                    a.hit_dealt=True; self.flash=5
                    if actual:
                        cx=1+int(d.x/ARENA_W*60); cy=8
                        for _ in range(6):
                            self.sparks.append([cx+(random.random()-.5)*6,
                                                cy+(random.random()-.5)*3,
                                                (random.random()-.5)*1.5,
                                                -(random.random()*1.2),
                                                random.choice('*·×+★'),7])

    def update(self, keys, mp=False, mk=False):
        if self.over: return
        self.p1.update(self.p2,keys,mp,mk)
        self.p2.update(self.p1)
        self._hits()
        self.sparks=[s for s in self.sparks if s[5]>0]
        for s in self.sparks: s[0]+=s[2]; s[1]+=s[3]; s[3]+=.15; s[5]-=1
        if self.msg_t>0: self.msg_t-=1
        if self.flash>0: self.flash-=1
        p1_ko = not self.p1.alive()
        p2_ko = not self.p2.alive()
        if (p1_ko or p2_ko) and not self.over:
            self.over = True
            if p1_ko and p2_ko:
                # Simultaneous KO: tiebreak in favour of p2
                self.p2w += 1; self.p2.set('victory')
                self.show(f'  {self.p2.name} WINS!  ')
            elif p1_ko:
                self.p2w += 1; self.p2.set('victory')
                self.show(f'  {self.p2.name} WINS!  ')
            else:
                self.p1w += 1; self.p1.set('victory')
                self.show(f'  {self.p1.name} WINS!  ')

    def next_round(self):
        if self.p1w>=NEED or self.p2w>=NEED: return False
        self.rnd+=1; self._new(); self.show(f'  ROUND {self.rnd}  ',90); return True

# ── RENDERER HELPERS ──────────────────────────────────────────────────────────
def make_put(scr, H, W):
    def put(r,c,s,a=0):
        try:
            if 0<=r<H-1 and 0<=c<W: scr.addstr(r,c,s[:W-c],a)
        except: pass
    return put

# ── INTRO SCREEN ──────────────────────────────────────────────────────────────
def draw_intro(scr, H, W, tick):
    put=make_put(scr,H,W)
    scr.erase()
    P=curses.color_pair

    put(0,0,'╔'+'═'*(W-2)+'╗',P(5))
    put(H-1,0,'╚'+'═'*(W-2)+'╝',P(5))
    for r in range(1,H-1):
        put(r,0,'║',P(5)); put(r,W-1,'║',P(5))

    start_row=max(1,(H-len(TITLE_ART))//2-1)
    for i,line in enumerate(TITLE_ART):
        col=max(1,(W-len(line))//2)
        attr=P(1)|curses.A_BOLD if i<4 else P(4)|curses.A_BOLD
        put(start_row+i,col,line,attr)

    # flanking fighters (idle animation)
    fr_idx=(tick//14)%2
    p1fr=SP1['idle'][fr_idx]; p2fr=SP2['idle'][fr_idx]
    fy=H-7
    for i,row in enumerate(p1fr):
        put(fy+i,2,row,P(1)|curses.A_BOLD)
    for i,row in enumerate(p2fr):
        put(fy+i,W-SW-2,row,P(2)|curses.A_BOLD)

    # flashing prompt
    if (tick//15)%2==0:
        msg='★  PRESS SPACE TO START  ★'
        put(H-3,(W-len(msg))//2,msg,P(4)|curses.A_BOLD)

    put(H-2,(W-28)//2,'A Claude Code Production · 2025',P(5))
    scr.refresh()

# ── CHARACTER SELECT ──────────────────────────────────────────────────────────
def draw_select(scr, H, W, sel, tick):
    put=make_put(scr,H,W)
    P=curses.color_pair
    scr.erase()

    put(0,0,'╔'+'═'*(W-2)+'╗',P(5))
    put(H-1,0,'╚'+'═'*(W-2)+'╝',P(5))
    for r in range(1,H-1):
        put(r,0,'║',P(5)); put(r,W-1,'║',P(5))

    title='★  CHOOSE YOUR FIGHTER  ★'
    put(1,(W-len(title))//2,title,P(4)|curses.A_BOLD)
    put(2,0,'╠'+'═'*(W-2)+'╣',P(5))

    PW=12  # portrait box width
    GAP=3
    total=len(CHARS)*(PW+GAP)-GAP
    start_col=(W-total)//2

    for i,ch in enumerate(CHARS):
        cx=start_col+i*(PW+GAP)
        selected=(i==sel)
        bc=P(ch['cp'])|curses.A_BOLD if selected else P(5)
        box_top=4

        put(box_top,cx,'┌'+'─'*(PW)+'┐' if not selected else '╔'+'═'*(PW)+'╗',bc)
        for r in range(8):
            row_str=ch['portrait'][r] if r<len(ch['portrait']) else ' '*9
            padded=('│' if not selected else '║')+row_str.center(PW)+('│' if not selected else '║')
            put(box_top+1+r,cx,padded,bc)
        put(box_top+9,cx,'└'+'─'*(PW)+'┘' if not selected else '╚'+'═'*(PW)+'╝',bc)

        name_attr=P(ch['cp'])|curses.A_BOLD if selected else P(5)
        put(box_top+11,cx+1,ch['name'].center(PW),name_attr)
        put(box_top+12,cx+1,ch['title'].center(PW),P(5))

        for si,(stat,bar) in enumerate(ch['stats']):
            put(box_top+14+si,cx+1,f"{stat} {bar[:10]}",P(3) if selected else P(5))

    ctrl='◀ ▶  select     SPACE  confirm'
    put(H-2,(W-len(ctrl))//2,ctrl,P(5))
    scr.refresh()

# ── COUNTDOWN ─────────────────────────────────────────────────────────────────
def draw_countdown(scr, H, W, phase):
    # phase: 3=show 3, 2=show 2, 1=show 1, 0=FIGHT!
    put=make_put(scr,H,W)
    P=curses.color_pair
    scr.erase()
    put(0,0,'╔'+'═'*(W-2)+'╗',P(5))
    put(H-1,0,'╚'+'═'*(W-2)+'╝',P(5))
    for r in range(1,H-1): put(r,0,'║',P(5)); put(r,W-1,'║',P(5))

    if phase>0:
        text=str(phase)
        color=[P(2),P(4),P(3)][phase-1]|curses.A_BOLD
    else:
        text='FIGHT!'
        color=P(1)|curses.A_BOLD

    mr=H//2; mc=(W-len(text))//2
    put(mr-2,(W-len(text)-4)//2,'╔'+'═'*(len(text)+2)+'╗',P(5))
    put(mr-1,(W-len(text)-4)//2,'║ '+' '*(len(text))+'  ║',P(5))
    put(mr,  (W-len(text)-4)//2,'║  '+text+'  ║',color)
    put(mr+1,(W-len(text)-4)//2,'║ '+' '*(len(text))+'  ║',P(5))
    put(mr+2,(W-len(text)-4)//2,'╚'+'═'*(len(text)+2)+'╝',P(5))
    scr.refresh()

# ── FIGHT SCREEN ──────────────────────────────────────────────────────────────
AT=4
def draw_fight(scr, g, W, H):
    put=make_put(scr,H,W)
    P=curses.color_pair
    GR=H-5; AH=GR-AT
    scr.erase()

    put(0,0,'╔'+'═'*(W-2)+'╗',P(5)|curses.A_BOLD)
    put(3,0,'╠'+'═'*(W-2)+'╣',P(5)|curses.A_BOLD)
    for r in range(AT,GR): put(r,0,'║',P(5)); put(r,W-1,'║',P(5))
    put(GR,0,'╠'+'─'*(W-2)+'╣',P(5)|curses.A_BOLD)

    BW=W//2-16
    cp1=3 if g.p1.hp/MHP>0.3 else 4; cp2=3 if g.p2.hp/MHP>0.3 else 4
    p1n=f' {g.p1.name:<8}'; p2n=f'{g.p2.name:>8} '
    # ── HUD row 1: HP bars with shading ──
    put(1,0,'║',P(5)|curses.A_BOLD)
    put(1,1,'▓▒░',P(5)|curses.A_DIM)
    put(1,4,p1n,P(g.p1.cp)|curses.A_BOLD)
    f1=max(0,round(BW*g.p1.hp/MHP))
    put(1,4+len(p1n),'█'*f1,P(cp1)|curses.A_BOLD)
    put(1,4+len(p1n)+f1,'░'*(BW-f1),P(5))
    vc=W//2-2; put(1,vc,' VS ',P(7)|curses.A_BOLD)
    f2=max(0,round(BW*g.p2.hp/MHP))
    put(1,vc+4,'█'*f2,P(cp2)|curses.A_BOLD)
    put(1,vc+4+f2,'░'*(BW-f2),P(5))
    put(1,vc+4+BW,p2n,P(g.p2.cp)|curses.A_BOLD)
    put(1,W-4,'░▒▓',P(5)|curses.A_DIM)
    put(1,W-1,'║',P(5)|curses.A_BOLD)
    # ── HUD row 2: round info with shading ──
    put(2,0,'║',P(5)|curses.A_BOLD); put(2,W-1,'║',P(5)|curses.A_BOLD)
    put(2,1,'▓▒░',P(5)|curses.A_DIM); put(2,W-4,'░▒▓',P(5)|curses.A_DIM)
    put(2,5,'★ CLAUDE FIGHTER ★',P(2)|curses.A_BOLD)
    put(2,21,f'HP {g.p1.hp:3d}',P(cp1))
    wins=f'[ Rnd {g.rnd}  {"★"*g.p1w} P1 · P2 {"★"*g.p2w} ]'
    put(2,W//2-len(wins)//2,wins,P(5)|curses.A_BOLD)
    put(2,W-14,f'HP {g.p2.hp:3d}',P(cp2))

    peak=JV0*JV0/(2*GRAV)
    for f in (g.p1,g.p2):
        fr=f.frame()
        col=1+round(f.x/ARENA_W*max(1,W-2-SW)); col=max(1,min(W-1-SW,col))
        joff=0 if f.grounded else min(round(f.y/peak*(AH-SH-1)),AH-SH-1)
        top=GR-1-SH+1-joff
        cp=P(f.cp)|curses.A_BOLD
        if f.state=='ko': cp=P(5)
        if g.flash>0 and f.state=='hurt': cp=P(6)|curses.A_BOLD|curses.A_REVERSE
        for i,row in enumerate(fr):
            r=top+i
            if AT<=r<GR: put(r,col,row,cp)

    for s in g.sparks:
        r,c=round(s[1]),round(s[0])
        if AT<=r<GR and 0<c<W-1: put(r,c,s[4],P(4)|curses.A_BOLD)

    if g.msg_t>0:
        m=g.msg; mw=len(m)+4; mc=W//2-mw//2; mr=AT+AH//2
        put(mr-1,mc,'╔'+'═'*(mw-2)+'╗',P(7))
        put(mr,  mc,'║ '+m+' ║',P(7)|curses.A_BOLD)
        put(mr+1,mc,'╚'+'═'*(mw-2)+'╝',P(7))
        if g.over: put(mr+3,W//2-15,'[ ENTER=next round   ESC=quit ]',P(5))

    put(H-4,0,'╠'+'═'*(W-2)+'╣',P(5))
    put(H-3,0,'║',P(5)); put(H-3,W-1,'║',P(5))
    ctrl='A/D:Move  SPC:Jump  S:Crouch  J:Punch  K:Kick  L:Block  ESC:Pause  Q:Quit'
    put(H-3,1,ctrl[:W-2].center(W-2),P(5))
    put(H-2,0,'╚'+'═'*(W-2)+'╝',P(5))
    scr.refresh()

# ── MAIN ──────────────────────────────────────────────────────────────────────
def main(scr):
    curses.cbreak(); curses.noecho(); scr.keypad(True)
    scr.nodelay(True); curses.curs_set(0)
    setup_colors()

    try: curses.mousemask(curses.ALL_MOUSE_EVENTS|curses.REPORT_MOUSE_POSITION)
    except: pass

    state=INTRO; sel=0; p1_char=0; _sub=[None]
    countdown_phase=3; countdown_timer=0
    game=None; tick=0
    nxt=time.perf_counter()

    while True:
        now=time.perf_counter()
        if now<nxt: time.sleep(max(0,nxt-now-.001)); continue
        nxt+=1/FPS; tick+=1

        H,W=scr.getmaxyx()
        keys=set(); mp=False; mk=False
        while True:
            k=scr.getch()
            if k==-1: break
            if k==curses.KEY_MOUSE:
                try:
                    _,_,_,_,bst=curses.getmouse()
                    if bst&curses.BUTTON1_PRESSED: mp=True
                    if bst&curses.BUTTON3_PRESSED: mk=True
                except: pass
            else: keys.add(k)

        if 27 in keys:
            if   state==FIGHT: state=PAUSE
            elif state==PAUSE: state=FIGHT
            else: break

        if state==INTRO:
            draw_intro(scr,H,W,tick)
            if ord(' ') in keys: state=SELECT

        elif state==SELECT:
            draw_select(scr,H,W,sel,tick)
            if curses.KEY_LEFT  in keys: sel=(sel-1)%len(CHARS)
            if curses.KEY_RIGHT in keys: sel=(sel+1)%len(CHARS)
            if ord(' ') in keys:
                p1_char=sel
                # AI picks random different character
                p2_choices=[i for i in range(len(CHARS)) if i!=p1_char]
                p2_char=random.choice(p2_choices)
                state=HOW_TO_PLAY; tick=0

        elif state==HOW_TO_PLAY:
            draw_how_to_play(scr,H,W,tick)
            if ord(' ') in keys:
                countdown_phase=3; countdown_timer=FPS
                state=COUNTDOWN

        elif state==COUNTDOWN:
            draw_countdown(scr,H,W,countdown_phase)
            countdown_timer-=1
            if countdown_timer<=0:
                if countdown_phase>0:
                    countdown_phase-=1
                    countdown_timer=FPS if countdown_phase>0 else FPS
                else:
                    game=Game(p1_char,p2_char)
                    game.show(f'  ROUND {game.rnd}  ',75)
                    state=FIGHT

        elif state==FIGHT:
            if game:
                game.update(keys,mp,mk)
                draw_fight(scr,game,W,H)
                if game.over and (10 in keys or 13 in keys):
                    if not game.next_round():
                        # Match over — submit score (rounds won as score)
                        _sub=[None]
                        extra=f'{"Win" if game.p1w>=NEED else "Loss"} {game.p1w}-{game.p2w}'
                        submit_async('fight', game.p1w*100, extra, _sub)
                        state=SELECT; sel=p1_char
                    else:
                        countdown_phase=3; countdown_timer=FPS
                        state=COUNTDOWN

        elif state==PAUSE:
            if game: draw_fight(scr,game,W,H)
            draw_pause(scr,H,W)
            if ord('r') in keys or ord('R') in keys: state=FIGHT
            if ord('q') in keys or ord('Q') in keys: break

def _run():
    import sys
    try:
        curses.wrapper(main)
    except Exception as e:
        try: curses.endwin()
        except: pass
        print(f'\n[Claude Fighter crashed] {e}', file=sys.stderr)
        import traceback; traceback.print_exc(file=sys.stderr)

_run()
print('\n  [ back in Claude — type anything to chat ]\n')
