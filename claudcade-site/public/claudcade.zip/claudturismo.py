#!/usr/bin/env python3
"""Claude Turismo — Pseudo-3D Terminal Racing · ESC to pause"""
import curses, time, random, math, sys

# ── STATES ─────────────────────────────────────────────────────────────────────
INTRO, HOW_TO_PLAY, PLAY, PAUSE, FINISH = range(5)

# ── CONFIG ─────────────────────────────────────────────────────────────────────
FPS          = 30
LAPS         = 3
MAX_SPEED    = 260.0    # world units / second at full throttle
ACCEL        = 130.0    # units/s² when holding accelerate
BRAKE_RATE   = 260.0    # units/s² when braking
FRICTION     = 65.0     # natural deceleration per second
OFFROAD_SLOW = 140.0    # extra drag off-road
STEER_SPEED  = 1800.0   # lateral units/s at full steer
CENTRIFUGAL  = 0.0035   # fraction of speed pushed outward per curve unit
SEG_LEN      = 180      # world units per track segment
ROAD_HALF_W  = 1600     # half-width of road in world units
LAP_SEGS     = 160      # track segments per lap

# ── TITLE ──────────────────────────────────────────────────────────────────────
TITLE = [
    r" ___  _      _   _  ___  ___   _____ _   _ ____  ___ ____  __  __  ___",
    r"/ __|| |    /_\ | ||   \| __| |_   _| | | |  _ \|_ _/ __||  \/  ||_ _|",
    r"\__ \| |__ / _ \| || |) | _|    | | | |_| | |_) || |\__ \| |\/| | | | ",
    r"|___/|____/_/ \_\_||___/|___|   |_|  \___/ |_|__/|___|___/|_|  |_||___|",
]

# ── TRACK ──────────────────────────────────────────────────────────────────────
# (curve, length)  curve: negative=left  positive=right  abs max ≈ 1.5
LAYOUT = [
    ( 0.00, 22),  # start straight
    ( 0.70, 18),  # gentle right
    ( 0.00, 12),  # straight
    (-0.90, 16),  # left hairpin
    ( 0.00, 10),  # straight
    ( 1.20, 12),  # right sweeper
    (-1.20, 12),  # left sweeper (chicane)
    ( 0.00, 18),  # back straight
    (-0.60, 14),  # gentle left
    ( 1.40, 10),  # sharp right
    ( 0.00, 16),  # finish straight
]

def _build_track():
    segs = []
    for curve, length in LAYOUT:
        segs.extend([float(curve)] * length)
    while len(segs) < LAP_SEGS:
        segs.append(0.0)
    return segs[:LAP_SEGS]

TRACK = _build_track()

# ── PLAYER CAR SPRITES ─────────────────────────────────────────────────────────
_CAR_C = ["  ▄███▄  ", " ╔═════╗ ", " ║◉   ◉║ ", " ╚══╦══╝ ", "▐▬▬▬▬▬▬▬▌"]
_CAR_L = [" ▄███▄   ", "╔═════╗  ", "║◉   ◉║  ", "╚══╦══╝  ", "▐▬▬▬▬▬▬▬▌"]
_CAR_R = ["   ▄███▄ ", "  ╔═════╗", "  ║◉   ◉║", "  ╚══╦══╝", "▐▬▬▬▬▬▬▬▌"]

# ── OPPONENT CARS (by apparent size / distance) ────────────────────────────────
_OPP_XL  = [" /▀▀▀\\ ", "║◎   ◎║", " \\▄▄▄/ "]
_OPP_LG  = [" /===\\ ", "[◎   ◎]", " \\___/ "]
_OPP_MD  = ["/=\\", "|◎|", "\\=/"]
_OPP_SM  = ["▬▬", "◉◉"]
_OPP_XS  = ["▪"]

def _opp_sprite(dist):
    if dist < 800:   return _OPP_XL, 1   # color: RED
    if dist < 1600:  return _OPP_LG, 4   # YELLOW
    if dist < 3000:  return _OPP_MD, 4
    if dist < 6000:  return _OPP_SM, 5
    return _OPP_XS, 5

# ── HELPERS ────────────────────────────────────────────────────────────────────
def _p(scr, H, W, r, c, s, a=0):
    try:
        if 0 <= r < H-1 and 0 <= c < W:
            scr.addstr(r, c, s[:max(0, W-c)], a)
    except curses.error:
        pass

def _fmt_time(secs):
    m = int(secs) // 60
    s = secs % 60
    return f"{m}:{s:05.2f}"

# ── RACE STATE ─────────────────────────────────────────────────────────────────
class Racer:
    def __init__(self, z, x, speed, is_player=False):
        self.z       = float(z)   # position along track (world units)
        self.x       = float(x)   # lateral offset from road center
        self.speed   = float(speed)
        self.lap     = 0
        self.lap_times = []
        self.lap_start = 0.0
        self.finished  = False
        self.is_player = is_player
        self.steer_dir = 0  # -1/0/1 for sprite selection

class Race:
    def __init__(self):
        self.player = Racer(0, 0, 0, is_player=True)
        lap_offset  = LAP_SEGS * SEG_LEN
        self.opps   = [
            Racer(-SEG_LEN * 3,          random.uniform(-400, 400),  90),
            Racer(-SEG_LEN * 7 + lap_offset // 4,  random.uniform(-600, 600), 110),
            Racer(-SEG_LEN * 12 + lap_offset // 3, random.uniform(-200, 200),  80),
        ]
        self.racers       = [self.player] + self.opps
        self.start_time   = time.time()
        self.race_time    = 0.0
        self.finished     = False
        self.finish_place = 0
        self.best_lap     = None

    def seg_at(self, z):
        idx = int(z / SEG_LEN) % LAP_SEGS
        return TRACK[idx]

    def update(self, keys, mouse_click, dt):
        p = self.player
        if p.finished:
            return

        # ── Player input ──────────────────────────────────────────────────────
        accel  = curses.KEY_UP   in keys or ord('w') in keys
        decel  = curses.KEY_DOWN in keys or ord('s') in keys
        left   = curses.KEY_LEFT in keys or ord('a') in keys
        right  = curses.KEY_RIGHT in keys or ord('d') in keys

        if accel:
            p.speed = min(MAX_SPEED, p.speed + ACCEL * dt)
        elif decel:
            p.speed = max(0.0, p.speed - BRAKE_RATE * dt)
        else:
            p.speed = max(0.0, p.speed - FRICTION * dt)

        steer = (-1 if left else 0) + (1 if right else 0)
        p.steer_dir = steer
        p.x += steer * STEER_SPEED * dt

        # Centrifugal push from curve
        curve = self.seg_at(p.z)
        p.x += curve * p.speed * CENTRIFUGAL * dt * SEG_LEN

        # Off-road slowdown
        if abs(p.x) > ROAD_HALF_W:
            p.speed = max(0.0, p.speed - OFFROAD_SLOW * dt)
            p.x = max(-ROAD_HALF_W * 1.8, min(ROAD_HALF_W * 1.8, p.x))

        # Advance position
        p.z += p.speed * dt

        # Lap counting
        lap_len = LAP_SEGS * SEG_LEN
        while p.z >= lap_len * (p.lap + 1):
            now = time.time() - self.start_time
            lt  = now - (p.lap_start if p.lap > 0 else 0) - sum(p.lap_times)
            p.lap_times.append(lt)
            if self.best_lap is None or lt < self.best_lap:
                self.best_lap = lt
            p.lap += 1
            if p.lap >= LAPS:
                p.finished = True
                self.finished = True
                self.finish_place = 1 + sum(1 for o in self.opps if o.finished)

        # ── AI opponents ──────────────────────────────────────────────────────
        for opp in self.opps:
            if opp.finished: continue
            # Simple rubber-band AI: chase player loosely
            gap    = p.z - opp.z
            target = min(MAX_SPEED * 0.85, MAX_SPEED * 0.6 + gap * 0.02)
            if opp.speed < target:
                opp.speed = min(target, opp.speed + ACCEL * 0.6 * dt)
            else:
                opp.speed = max(target, opp.speed - FRICTION * dt)
            opp.z += opp.speed * dt
            # Drift back to center
            opp.x *= (1 - dt * 0.8)
            # Steer with track curve
            opp.x += self.seg_at(opp.z) * opp.speed * CENTRIFUGAL * 0.5 * dt * SEG_LEN
            while opp.z >= LAP_SEGS * SEG_LEN * (opp.lap + 1):
                opp.lap += 1
                if opp.lap >= LAPS: opp.finished = True

        self.race_time = time.time() - self.start_time

# ── DRAWING ────────────────────────────────────────────────────────────────────
def draw_road(scr, H, W, race, tick):
    P = curses.color_pair
    p = race.player

    ROAD_TOP    = 3       # first road row (after HUD)
    CAR_H       = 5       # player car sprite height
    ROAD_BOTTOM = H - CAR_H - 3
    ROAD_ROWS   = max(2, ROAD_BOTTOM - ROAD_TOP)

    # Accumulate curve looking ahead
    curve_acc = 0.0
    curve_per_row = []
    for i in range(ROAD_ROWS):
        depth_factor = (ROAD_ROWS - i) / ROAD_ROWS   # 1=far, 0=near
        look_ahead   = depth_factor * (p.speed / MAX_SPEED) * 20
        seg_idx      = int((p.z / SEG_LEN) + look_ahead) % LAP_SEGS
        curve_acc   += TRACK[seg_idx] * depth_factor * 0.8
        curve_per_row.append(curve_acc)

    # ── Sky (gradient with hills suggestion) ──────────────────────────────────
    for y in range(ROAD_TOP):
        if y >= 3: break
        _p(scr, H, W, y, 1, ' ' * (W-2), P(8) | curses.A_DIM)

    # ── Road rows ─────────────────────────────────────────────────────────────
    player_x_offset = int(p.x / ROAD_HALF_W * (W // 4))
    max_hw = W // 2 - 3

    for i in range(ROAD_ROWS):
        screen_y = ROAD_TOP + i
        # Perspective: row 0 = horizon (tiny), row ROAD_ROWS-1 = near (wide)
        scale    = (i + 1) / ROAD_ROWS            # 0→1
        half_w   = max(1, int(scale * max_hw))
        road_cx  = W // 2 - int(curve_per_row[i] * scale * 12) - player_x_offset

        # Alternating stripes for depth / speed feel
        stripe_speed = max(1, int(p.speed / 6))
        alt = (i + (tick * stripe_speed // FPS)) % 8 < 4

        grass_attr = P(3) | (curses.A_BOLD if alt else curses.A_DIM)
        road_attr  = P(5) | curses.A_DIM
        edge_attr  = P(5) | curses.A_BOLD
        dash_attr  = P(4) | curses.A_BOLD

        g = '▒' if alt else '░'

        rl = road_cx - half_w
        rr = road_cx + half_w

        try:
            if rl > 1:
                scr.addstr(screen_y, 1, g * min(rl - 1, W-2), grass_attr)
            if rl >= 1:
                scr.addstr(screen_y, max(1, rl), '▌', edge_attr)
            if half_w > 1 and rl + 1 < rr and rr < W - 1:
                scr.addstr(screen_y, rl + 1, ' ' * (rr - rl - 1), road_attr)
            # Dashed center line (scrolling)
            if 0 < road_cx < W - 1:
                dash_phase = int(p.z / 25 + i) % 8
                if dash_phase < 4:
                    scr.addstr(screen_y, road_cx, '│', dash_attr)
            if rr >= 1 and rr < W - 1:
                scr.addstr(screen_y, min(rr, W-2), '▐', edge_attr)
            if rr + 1 < W - 1:
                scr.addstr(screen_y, rr + 1, g * min(W - rr - 3, W-2), grass_attr)
        except curses.error:
            pass

        # ── Draw opponent cars at this depth ──────────────────────────────────
        for opp in race.opps:
            rel_z = opp.z - p.z
            # Only draw opponents in front within render range
            if 50 < rel_z < 18000:
                # Map relative distance to a specific row
                row_frac = 1.0 - min(1.0, rel_z / 18000)
                opp_row  = int(row_frac * ROAD_ROWS)
                if opp_row != i: continue

                sprite, col = _opp_sprite(rel_z)
                half_sp_w   = max(1, len(sprite[0]) // 2)
                opp_lateral = opp.x - p.x
                opp_screen_x = road_cx + int(opp_lateral / ROAD_HALF_W * half_w) - half_sp_w
                for si, srow in enumerate(sprite):
                    _p(scr, H, W, screen_y - len(sprite) + si + 1,
                       opp_screen_x, srow, P(col) | curses.A_BOLD)

    # ── Player car ────────────────────────────────────────────────────────────
    car_row = ROAD_BOTTOM + 1
    sprite  = _CAR_L if p.steer_dir < 0 else (_CAR_R if p.steer_dir > 0 else _CAR_C)
    car_col = (W - len(sprite[0])) // 2
    off_road = abs(p.x) > ROAD_HALF_W
    car_attr = P(2) | curses.A_BOLD if off_road else P(1) | curses.A_BOLD
    for si, srow in enumerate(sprite):
        _p(scr, H, W, car_row + si, car_col, srow, car_attr)

def draw_hud(scr, H, W, race, tick):
    P   = curses.color_pair
    p   = race.player
    DIM = P(5) | curses.A_DIM
    BLD = P(5) | curses.A_BOLD
    PNK = P(6) | curses.A_BOLD

    # ── Top border / HUD ──────────────────────────────────────────────────────
    _p(scr, H, W, 0, 0, '╔' + '═'*(W-2) + '╗', BLD)
    _p(scr, H, W, H-1, 0, '╚' + '═'*(W-2) + '╝', BLD)
    for r in range(1, H-1):
        _p(scr, H, W, r, 0, '║', P(5))
        _p(scr, H, W, r, W-1, '║', P(5))

    _p(scr, H, W, 1, 1, '▓▒░', DIM)
    _p(scr, H, W, 1, W-4, '░▒▓', DIM)
    _p(scr, H, W, 1, 5, '★ CLAUDE TURISMO ★', PNK)

    # Speed bar
    spd_frac = p.speed / MAX_SPEED
    bar_w    = 16
    filled   = int(bar_w * spd_frac)
    spd_cp   = P(3) if spd_frac < 0.6 else (P(4) if spd_frac < 0.85 else P(2))
    _p(scr, H, W, 1, 26, f'SPEED', DIM)
    _p(scr, H, W, 1, 32, '█' * filled + '░' * (bar_w - filled), spd_cp | curses.A_BOLD)
    _p(scr, H, W, 1, 32 + bar_w + 1, f'{int(p.speed):3d}', BLD)

    # Lap info
    lap_str = f'LAP {min(p.lap+1, LAPS)}/{LAPS}'
    _p(scr, H, W, 1, W - len(lap_str) - len(_fmt_time(race.race_time)) - 8,
       lap_str, BLD)
    _p(scr, H, W, 1, W - len(_fmt_time(race.race_time)) - 4,
       _fmt_time(race.race_time), P(4) | curses.A_BOLD)

    _p(scr, H, W, 2, 0, '╠' + '═'*(W-2) + '╣', BLD)

    # ── Bottom bar ────────────────────────────────────────────────────────────
    bot = H - 2
    _p(scr, H, W, bot - 1, 0, '╠' + '═'*(W-2) + '╣', BLD)
    _p(scr, H, W, bot, 2,
       '↑/W Accelerate   ↓/S Brake   ←/A Left   →/D Right   ESC Pause', DIM)

    # Best lap
    if race.best_lap:
        bl = f'BEST LAP {_fmt_time(race.best_lap)}'
        _p(scr, H, W, bot, W - len(bl) - 3, bl, P(4) | curses.A_BOLD)

    # Off-road warning
    if abs(p.x) > ROAD_HALF_W:
        if (tick // 5) % 2 == 0:
            warn = '  ⚠  OFF ROAD  ⚠  '
            _p(scr, H, W, H//2, (W-len(warn))//2, warn, P(2) | curses.A_BOLD)

def draw_intro(scr, H, W, tick):
    P = curses.color_pair
    scr.erase()
    _p(scr, H, W, 0, 0, '╔'+'═'*(W-2)+'╗', P(5)|curses.A_BOLD)
    _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        _p(scr, H, W, r, 0, '║', P(5))
        _p(scr, H, W, r, W-1, '║', P(5))

    attrs = [P(4)|curses.A_BOLD, P(1)|curses.A_BOLD, P(6)|curses.A_BOLD, P(4)|curses.A_BOLD]
    for i, (line, attr) in enumerate(zip(TITLE, attrs)):
        tx = max(1, (W - len(line)) // 2)
        _p(scr, H, W, 2+i, tx, line, attr)

    _p(scr, H, W, 6, 1, '░'*(W-2), P(5)|curses.A_DIM)

    sub = '◈   P S E U D O - 3 D   T E R M I N A L   R A C I N G   ◈'
    _p(scr, H, W, 7, max(1,(W-len(sub))//2), sub, P(6)|curses.A_BOLD)

    # Animated preview road
    mid = H // 2 + 2
    for i in range(8):
        scale  = (i + 1) / 8
        hw     = int(scale * (W // 2 - 6))
        cx     = W // 2 + int(math.sin(tick * 0.04) * 6 * (1 - scale))
        alt    = (i + tick // 3) % 8 < 4
        g      = '▒' if alt else '░'
        scr.addstr(mid + i, 1, g * max(0, cx - hw - 2), P(3)|(curses.A_BOLD if alt else curses.A_DIM)) if cx-hw-2>0 else None
        scr.addstr(mid + i, max(1, cx-hw), ' '* (hw*2), P(5)|curses.A_DIM) if hw>0 else None
        if cx+hw < W-2:
            scr.addstr(mid + i, cx+hw, g * (W - cx - hw - 3), P(3)|(curses.A_BOLD if alt else curses.A_DIM))

    if (tick // 18) % 2 == 0:
        msg = '[ SPACE ]  START RACE'
        _p(scr, H, W, H-4, (W-len(msg))//2, msg, P(4)|curses.A_BOLD)
    _p(scr, H, W, H-3, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)
    _p(scr, H, W, H-2, 2, '3 LAPS  ·  CLAUDE TURISMO  ·  BEAT THE AI', P(5)|curses.A_DIM)
    scr.refresh()

def draw_how_to_play(scr, H, W, tick):
    P = curses.color_pair
    scr.erase()
    _p(scr, H, W, 0, 0, '╔'+'═'*(W-2)+'╗', P(5)|curses.A_BOLD)
    _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        _p(scr, H, W, r, 0, '║', P(5))
        _p(scr, H, W, r, W-1, '║', P(5))
    _p(scr, H, W, 1, 1, '▓▒░'+'░'*(W-8)+'░▒▓', P(5)|curses.A_DIM)
    t = '  H O W   T O   R A C E  '
    _p(scr, H, W, 1, (W-len(t))//2, t, P(4)|curses.A_BOLD)
    _p(scr, H, W, 2, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)

    lines = [
        ('GOAL', None),
        ('', None),
        ('  Complete 3 laps faster than the AI opponents.', P(5)),
        ('  Stay on the road — grass slows you down.', P(5)),
        ('  Brake before tight corners or you\'ll spin wide.', P(5)),
        ('', None),
        ('CONTROLS', None),
        ('', None),
        ('  ↑ / W      Accelerate', P(6)|curses.A_BOLD),
        ('  ↓ / S      Brake', P(6)|curses.A_BOLD),
        ('  ← / A      Steer left', P(6)|curses.A_BOLD),
        ('  → / D      Steer right', P(6)|curses.A_BOLD),
        ('  ESC        Pause', P(5)|curses.A_DIM),
        ('', None),
        ('TIPS', None),
        ('', None),
        ('  • Lift off the gas before corners, accelerate out', P(5)|curses.A_DIM),
        ('  • The road curves — you can see it building at the horizon', P(5)|curses.A_DIM),
        ('  • Opponents use rubber-band AI — stay ahead!', P(5)|curses.A_DIM),
    ]

    for i, (text, attr) in enumerate(lines):
        y = 4 + i
        if y >= H - 4: break
        if attr is None:
            _p(scr, H, W, y, 4, text, P(4)|curses.A_BOLD)
        else:
            _p(scr, H, W, y, 2, text, attr)

    if (tick // 18) % 2 == 0:
        msg = '[ SPACE ]  GO!'
        _p(scr, H, W, H-3, (W-len(msg))//2, msg, P(2)|curses.A_BOLD)
    _p(scr, H, W, H-2, 0, '╠'+'═'*(W-2)+'╣', P(5)|curses.A_BOLD)
    scr.refresh()

def draw_pause(scr, H, W):
    P = curses.color_pair
    bw = 40; bh = 10
    by = (H-bh)//2; bx = (W-bw)//2
    try:
        for r in range(bh+1):
            scr.addstr(by+r+1, bx+2, '▒'*bw, P(5)|curses.A_DIM)
        scr.addstr(by,      bx, '╔'+'═'*(bw-2)+'╗', P(7)|curses.A_BOLD)
        for r in range(1, bh-1): scr.addstr(by+r, bx, '║'+' '*(bw-2)+'║', P(7))
        scr.addstr(by+bh-1, bx, '╚'+'═'*(bw-2)+'╝', P(7)|curses.A_BOLD)
        scr.addstr(by+1, bx+1, '▓▒░'+'░'*(bw-6)+'░▒▓', P(7)|curses.A_DIM)
        scr.addstr(by+2, bx+(bw-24)//2, '  ⏸  CLAUDE TURISMO  ⏸  ', P(7)|curses.A_BOLD)
        scr.addstr(by+3, bx+1, '─'*(bw-2), P(7))
        scr.addstr(by+5, bx+5, '[ R ]  Resume race', P(3)|curses.A_BOLD)
        scr.addstr(by+6, bx+5, '[ Q ]  Quit to Claudcade', P(2)|curses.A_BOLD)
    except curses.error:
        pass
    scr.refresh()

def draw_finish(scr, H, W, race, tick):
    P = curses.color_pair
    scr.erase()
    _p(scr, H, W, 0, 0, '╔'+'═'*(W-2)+'╗', P(5)|curses.A_BOLD)
    _p(scr, H, W, H-1, 0, '╚'+'═'*(W-2)+'╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        _p(scr, H, W, r, 0, '║', P(5))
        _p(scr, H, W, r, W-1, '║', P(5))

    mr = H // 2 - 3
    medals = {1:'🥇  1st  🥇', 2:'🥈  2nd  🥈', 3:'🥉  3rd  🥉', 4:'  4th  '}
    pos_str = medals.get(race.finish_place, f'  P{race.finish_place}  ')
    cp  = P(4)|curses.A_BOLD if race.finish_place == 1 else P(6)|curses.A_BOLD
    _p(scr, H, W, mr,   (W-25)//2, '  C H E C K E R E D   F L A G  ', cp)
    _p(scr, H, W, mr+1, (W-len(pos_str)-4)//2, f'  {pos_str}  ', cp)
    _p(scr, H, W, mr+2, (W-28)//2, f'  RACE TIME  {_fmt_time(race.race_time)}  ', P(5)|curses.A_BOLD)
    if race.best_lap:
        bl = f'  BEST LAP   {_fmt_time(race.best_lap)}  '
        _p(scr, H, W, mr+3, (W-len(bl))//2, bl, P(3)|curses.A_BOLD)

    _p(scr, H, W, mr+5, 3, 'LAP TIMES:', P(5)|curses.A_BOLD)
    for i, lt in enumerate(race.player.lap_times[:LAPS]):
        _p(scr, H, W, mr+6+i, 5, f'Lap {i+1}:  {_fmt_time(lt)}', P(5))

    if (tick // 18) % 2 == 0:
        msg = '[ SPACE ] Race Again     [ Q ] Quit'
        _p(scr, H, W, H-3, (W-len(msg))//2, msg, P(5))
    scr.refresh()

# ── MAIN ───────────────────────────────────────────────────────────────────────
CONTROLS = [
    '↑ / W        Accelerate',
    '↓ / S        Brake',
    '← / A        Steer left',
    '→ / D        Steer right',
    'ESC          Pause / Resume',
    'Q            Quit to Claudcade',
]

def main(scr):
    curses.cbreak(); curses.noecho(); scr.keypad(True)
    scr.nodelay(True); curses.curs_set(0)
    curses.start_color(); curses.use_default_colors()
    curses.init_pair(1, curses.COLOR_CYAN,    -1)  # player car
    curses.init_pair(2, curses.COLOR_RED,     -1)  # danger / off-road
    curses.init_pair(3, curses.COLOR_GREEN,   -1)  # grass
    curses.init_pair(4, curses.COLOR_YELLOW,  -1)  # gold / speed
    curses.init_pair(5, curses.COLOR_WHITE,   -1)  # neutral
    curses.init_pair(6, curses.COLOR_MAGENTA, -1)  # pink / special
    curses.init_pair(7, curses.COLOR_BLACK, curses.COLOR_WHITE)
    curses.init_pair(8, curses.COLOR_BLUE,    -1)  # sky
    try: curses.mousemask(0)
    except Exception: pass

    state = INTRO
    race  = None
    tick  = 0
    nxt   = time.perf_counter()

    while True:
        now = time.perf_counter()
        if now < nxt:
            time.sleep(max(0.0, nxt - now - 0.001))
            continue
        dt  = min(1/FPS * 2, now - (nxt - 1/FPS))
        nxt += 1/FPS
        tick += 1

        H, W = scr.getmaxyx()
        keys = set()
        while True:
            k = scr.getch()
            if k == -1: break
            keys.add(k)

        if 27 in keys:
            if   state == PLAY:  state = PAUSE
            elif state == PAUSE: state = PLAY
            else: break

        if state == INTRO:
            draw_intro(scr, H, W, tick)
            if ord(' ') in keys:
                state = HOW_TO_PLAY; tick = 0

        elif state == HOW_TO_PLAY:
            draw_how_to_play(scr, H, W, tick)
            if ord(' ') in keys:
                race  = Race(); state = PLAY; tick = 0

        elif state == PLAY:
            race.update(keys, False, dt)
            scr.erase()
            draw_road(scr, H, W, race, tick)
            draw_hud(scr, H, W, race, tick)
            scr.refresh()
            if race.finished:
                state = FINISH; tick = 0

        elif state == PAUSE:
            draw_road(scr, H, W, race, tick)
            draw_hud(scr, H, W, race, tick)
            draw_pause(scr, H, W)
            if ord('r') in keys or ord('R') in keys: state = PLAY
            if ord('q') in keys or ord('Q') in keys: break

        elif state == FINISH:
            draw_finish(scr, H, W, race, tick)
            if ord(' ') in keys:
                race = Race(); state = HOW_TO_PLAY; tick = 0
            if ord('q') in keys or ord('Q') in keys: break

def _run():
    try:
        curses.wrapper(main)
    except Exception:
        import traceback
        curses.endwin()
        traceback.print_exc()
        sys.exit(1)
    print('\n  [ back in Claudcade ]\n')

if __name__ == '__main__':
    _run()
