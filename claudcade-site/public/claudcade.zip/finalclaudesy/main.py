"""Main game loop and state machine for Final Claudesy."""
import curses, time, json, os, random

from .data     import STORY
from .entities import Party
from .battle   import Battle
from .explore  import WorldMap, TownScreen, DungeonScreen, PartyMenu
from .ui       import safe_add, box, center, setup_colors
try:
    from claudcade_scores import submit_async as _submit_async
except ImportError:
    def _submit_async(*a, **kw): pass

FPS      = 30
SAVE_PATH = os.path.expanduser('~/finalclaudesy_save.json')

# ── Title screen ───────────────────────────────────────────────────────────────
TITLE_ART = [
    r"  _____ ___ _   _   _   _      ___ _      _   _   _ ___  ___ _____   __",
    r" |  ___|_ _| \ | | / \ | |    / __| |    / \ | | | |   \| __/ __\ \ / /",
    r" | |_   | ||  \| |/ _ \| |   | (__| |   / _ \| |_| | |) | _|\__ \\ V / ",
    r" |  _|  | || |\  / ___ \ |___ \__ \ |__/ ___ \  _  | __/|___|___/ | |  ",
    r" |_|   |___|_| \_/_/   \_\____|___/____/_/   \_\_| |_|_|  |___\__/ |_|  ",
]

def draw_title(scr, H, W, tick, has_save):
    P = curses.color_pair
    scr.erase()
    box(scr, 0, 0, H, W, '', 5)

    # Starfield
    random.seed(42)
    for _ in range(60):
        r = random.randint(1, H-2)
        c = random.randint(1, W-2)
        ch = random.choice(['·', '+', '*'])
        if (tick // 10 + r + c) % 5 == 0:
            safe_add(scr, r, c, ch, P(5)|curses.A_DIM)
    random.seed()

    # Title art
    tr = max(2, H//2 - 6)
    for i, line in enumerate(TITLE_ART):
        col = max(1, (W - len(line)) // 2)
        attr = P(4 if i%2==0 else 1)|curses.A_BOLD
        safe_add(scr, tr+i, col, line, attr)

    sub = 'A TERMINAL JRPG'
    center(scr, tr+6, sub, W, P(6)|curses.A_BOLD)

    if (tick // 20) % 2 == 0:
        center(scr, H//2+3, '[ SPACE ] New Game', W, P(4)|curses.A_BOLD)
        if has_save:
            center(scr, H//2+5, '[ L ] Load Game', W, P(3)|curses.A_BOLD)
    center(scr, H-3, 'WASD/Arrows: Move   J/Space: Confirm   Q/ESC: Back   M: Menu', W, P(5))
    scr.refresh()


def draw_how_to_play(scr, H, W, tick):
    P = curses.color_pair
    scr.erase()
    BW = min(70, W-4)
    lm = (W - BW) // 2

    def fp(r, c, s, a=0):
        try:
            if 0 <= r < H-1 and 0 <= c < W: scr.addstr(r, c, s[:W-c], a)
        except: pass

    fp(0, lm, '╔' + '═'*(BW-2) + '╗', P(5)|curses.A_BOLD)
    fp(H-1, lm, '╚' + '═'*(BW-2) + '╝', P(5)|curses.A_BOLD)
    for r in range(1, H-1):
        fp(r, lm, '║', P(5)|curses.A_BOLD)
        fp(r, lm+BW-1, '║', P(5)|curses.A_BOLD)

    title = 'H O W   T O   P L A Y'
    hdr = '▓▒░' + title.center(BW-8) + '░▒▓'
    fp(1, lm+1, hdr, P(4)|curses.A_BOLD)
    fp(2, lm, '╠' + '═'*(BW-2) + '╣', P(5)|curses.A_BOLD)

    row = 4
    def ln(text='', color=5, bold=False):
        nonlocal row
        attr = P(color) | (curses.A_BOLD if bold else 0)
        fp(row, lm+2, text[:BW-4], attr)
        row += 1

    ln('GOAL', 4, True)
    ln('────', 5)
    ln('Lead Claude, Haiku, and Opus across three regions to defeat SYNTHOS.', 5)
    ln('Explore towns, conquer dungeons, defeat bosses.', 5)
    ln()
    ln('CONTROLS', 4, True)
    ln('────────', 5)
    ln('WASD / Arrows    Move', 5)
    ln('SPACE / Enter    Confirm', 5)
    ln('Q / ESC          Back', 5)
    ln('M                Party menu', 5)
    ln()
    ln('TIPS', 4, True)
    ln('────', 5)
    ln('• Rest at inns to restore HP/MP', 5)
    ln('• Save often', 5)
    ln("• Haiku's magic exploits enemy weaknesses · Opus heals", 5)

    if (tick//15)%2==0:
        msg = 'PRESS SPACE TO START'
        fp(H-3, lm + (BW-len(msg))//2, msg, P(4)|curses.A_BOLD)
    scr.refresh()


def draw_story(scr, H, W, lines, tick):
    P = curses.color_pair
    scr.erase()
    box(scr, 0, 0, H, W, '', 5)
    start = max(0, H//2 - len(lines)//2 - 1)
    for i, line in enumerate(lines):
        if line == '[ Press SPACE ]':
            if (tick // 15) % 2 == 0:
                center(scr, H-4, line, W, P(5)|curses.A_BOLD)
        else:
            center(scr, start+i, line, W, P(5))
    scr.refresh()


# ── Main ───────────────────────────────────────────────────────────────────────
def main(scr):
    curses.cbreak(); curses.noecho(); scr.keypad(True)
    scr.nodelay(True); curses.curs_set(0)
    setup_colors()

    state      = 'TITLE'
    prev_state = 'WORLD'   # tracks state before entering MENU
    party      = None
    world      = None
    town       = None
    dungeon    = None
    battle     = None
    menu       = None
    story_key  = None
    story_lines= []
    after_story= None
    battle_msgs= []
    result_timer = 0
    tick       = 0
    nxt        = time.perf_counter()

    has_save = os.path.exists(SAVE_PATH)

    while True:
        now = time.perf_counter()
        if now < nxt:
            time.sleep(max(0, nxt - now - 0.001))
            continue
        nxt += 1 / FPS
        tick += 1

        H, W = scr.getmaxyx()
        keys = set()
        while True:
            k = scr.getch()
            if k == -1: break
            keys.add(k)

        if 27 in keys and state not in ('BATTLE','BATTLE_RESULT','STORY','TITLE'):
            if state in ('TOWN','DUNGEON','WORLD'):
                menu       = PartyMenu(party)
                prev_state = state
                state      = 'MENU'

        # ── State logic ────────────────────────────────────────────────────────
        if state == 'TITLE':
            draw_title(scr, H, W, tick, has_save)
            if ord(' ') in keys:
                state = 'HOW_TO_PLAY'
                tick  = 0
            elif ord('l') in keys and has_save:
                with open(SAVE_PATH) as f:
                    party = Party.from_dict(json.load(f))
                world = WorldMap(party)
                state = 'WORLD'

        elif state == 'HOW_TO_PLAY':
            draw_how_to_play(scr, H, W, tick)
            if ord(' ') in keys:
                party       = Party()
                world       = WorldMap(party)
                story_lines = STORY['intro']
                after_story = 'WORLD'
                state       = 'STORY'
                tick        = 0

        elif state == 'STORY':
            draw_story(scr, H, W, story_lines, tick)
            if ord(' ') in keys or ord('\n') in keys:
                state = after_story

        elif state == 'WORLD':
            if world is None: world = WorldMap(party)
            world.draw(scr, H, W, tick)

            for k in keys:
                world.handle_key(k)
            if ord('m') in keys:
                menu       = PartyMenu(party)
                prev_state = 'WORLD'
                state      = 'MENU'
                continue

            res = world.result
            world.result = None
            if res:
                if res[0] == 'town':
                    town  = TownScreen(party, res[1])
                    state = 'TOWN'
                elif res[0] == 'dungeon':
                    name, region = res[1], res[2]
                    dungeon = DungeonScreen(party, name)
                    state   = 'DUNGEON'
                elif res[0] == 'battle':
                    _, group, region = res
                    battle = Battle(party, group)
                    state  = 'BATTLE'

        elif state == 'TOWN':
            town.draw(scr, H, W, tick)
            for k in keys: town.handle_key(k)
            if town.result == 'leave':
                town   = None
                state  = 'WORLD'
            elif town.result and town.result[0] == 'battle':
                _, group, region = town.result
                battle = Battle(party, group)
                town.result = None
                state  = 'BATTLE'

        elif state == 'DUNGEON':
            dungeon.draw(scr, H, W, tick)
            for k in keys: dungeon.handle_key(k)
            res = dungeon.result
            dungeon.result = None
            if res:
                if res == 'exit':
                    dungeon = None; state = 'WORLD'
                elif res[0] == 'battle':
                    _, group, region = res
                    battle = Battle(party, group)
                    state  = 'BATTLE'
                elif res[0] == 'boss':
                    boss_name = res[1]
                    # story before final boss
                    if boss_name == 'SYNTHOS' and 'before_final' not in party.story_flags:
                        party.story_flags.add('before_final')
                        story_lines = STORY['before_final']
                        after_story = '_BOSS_' + boss_name
                        state = 'STORY'
                    else:
                        battle = Battle(party, [boss_name], is_boss=True)
                        state  = 'BATTLE'

        elif state.startswith('_BOSS_'):
            boss_name = state[6:]
            battle    = Battle(party, [boss_name], is_boss=True)
            state     = 'BATTLE'

        elif state == 'BATTLE':
            battle.draw(scr, H, W, tick)
            for k in keys: battle.handle_key(k)

            if battle.result:
                if battle.result == 'win':
                    battle_msgs = battle.battle_end_rewards()
                    total_lv = sum(m.level for m in party.members)
                    _submit_async('finalclaudesy', total_lv * 1000 + party.gold,
                        f'Lv {max(m.level for m in party.members)}', [None])
                    boss = next((e for e in battle.enemies if e.boss), None)
                    if boss:
                        bname = boss.name
                        party.dungeon_done.add(dungeon.dname if dungeon else '')
                        if bname == 'Vine Colossus' and 'boss1' not in party.story_flags:
                            party.story_flags.add('boss1')
                            battle_msgs.append('')
                            battle_msgs += STORY['after_boss1']
                        elif bname == 'Pyralith' and 'boss2' not in party.story_flags:
                            party.story_flags.add('boss2')
                            battle_msgs.append('')
                            battle_msgs += STORY['after_boss2']
                        elif bname == 'SYNTHOS':
                            battle_msgs.append('')
                            battle_msgs += STORY['victory']
                            state = 'BATTLE_RESULT'
                    state = 'BATTLE_RESULT'
                elif battle.result == 'lose':
                    battle_msgs = ['The party was defeated...', '', 'GAME OVER']
                    state = 'BATTLE_RESULT'
                elif battle.result == 'escaped':
                    battle_msgs = ['You escaped!']
                    state = 'BATTLE_RESULT'
                result_timer = 0

        elif state == 'BATTLE_RESULT':
            battle.draw_result(scr, H, W, battle_msgs, 0)
            result_timer += 1
            if ord(' ') in keys and result_timer > 30:
                if battle.result == 'lose':
                    # Survive wipe: leader revives at 25% HP, rest at 1
                    party.members[0].hp = max(1, party.members[0].max_hp // 4)
                    for m in party.members[1:]: m.hp = 1
                    state = 'WORLD'
                elif 'SYNTHOS' in [e.name for e in battle.enemies]:
                    state = 'TITLE'
                else:
                    if dungeon:
                        state = 'DUNGEON'
                    elif town:
                        state = 'TOWN'
                    else:
                        state = 'WORLD'
                battle_msgs = []

        elif state == 'MENU':
            menu.draw(scr, H, W, tick)
            for k in keys: menu.handle_key(k)
            if menu.result == 'close':
                menu  = None
                state = prev_state

        # ESC from anywhere goes to title only if on title
        if 27 in keys and state == 'TITLE':
            break


def run():
    import sys
    try:
        curses.wrapper(main)
    except Exception as e:
        try: curses.endwin()
        except: pass
        print(f'\n[Final Claudesy crashed] {e}', file=sys.stderr)
        import traceback; traceback.print_exc(file=sys.stderr)
    print('\n  [ Final Claudesy — thanks for playing! ]\n')


if __name__ == '__main__':
    run()
